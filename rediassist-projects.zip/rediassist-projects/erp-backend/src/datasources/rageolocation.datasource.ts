import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

const config = {
  name: 'sms',
  debug: false,
  connector: 'rest',
  options: {
    headers: {
      accept: 'application/json',
      'content-type': 'application/json'
    },
    strictSSL: true,
  },
  operations: [{
    "template": {
      "method": "GET",
      "url": "http://localhost:9200/{url}",
      "options": {
        "strictSSL": true,
        "useQuerystring": true
      },
      "responsePath": ""
    },
    "functions": {
      "get": [
        "url"
      ]
    }
  },
  {
    "template": {
      "method": "POST",
      "url": "http://localhost:9200/{url}",
      "body": "{body}",
      "options": {
        "strictSSL": true,
        "useQuerystring": true
      },
      "responsePath": ""
    },
    "functions": {
      "post": [
        "url",
        "body"
      ]
    }
  }, {
    "template": {
      "method": "GET",
      "url": "http://localhost:9200/{url}",
      "body": "{body}",
      "options": {
        "strictSSL": true,
        "useQuerystring": true
      },
      "responsePath": ""
    },
    "functions": {
      "getWithBody": [
        "url",
        "body"
      ]
    }
  },
  ],
  crud: false
};

// Observe application's life cycle to disconnect the datasource when
// application is stopped. This allows the application to be shut down
// gracefully. The `stop()` method is inherited from `juggler.DataSource`.
// Learn more at https://loopback.io/doc/en/lb4/Life-cycle.html
@lifeCycleObserver('datasource')
export class RaGeoLocationDataSource extends juggler.DataSource
  implements LifeCycleObserver {
  static dataSourceName = 'rageolocation';
  static readonly defaultConfig = config;

  constructor(
    @inject('datasources.config.sms', {optional: true})
    dsConfig: object = config,
  ) {
    super(dsConfig);
  }
}
