import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

const config = {
  name: 'sms',
  debug: true,
  connector: 'rest',
  baseURL: 'https://api.msg91.com/',
  options: {
    headers: {
      accept: 'application/json',
      'content-type': 'application/json',
    },
    strictSSL: true,
  },
  operations: [
    {
      template: {
        method: 'GET',
        url: 'https://api.msg91.com/api/v5/otp',
        query: {
          authkey: '93703ArFUOGiSSxY5ed37d31P1',
          template_id: '5ed33dbbd6fc0562f3561790',
          extra_param: '{"OTP": "{otp}","COMPANY_NAME":"READYASSIST"}',
          mobile: '{mobile}',
        },
      },
      functions: {
        sendOTP: ['mobile', 'otp'],
      },
    },
    {
      template: {
        method: 'POST',
        url: 'https://api.msg91.com/api/v5/otp/retry',
        query: {
          authkey: '93703ArFUOGiSSxY5ed37d31P1',
          mobile: '{mobile}',
        },
      },
      functions: {
        resendOTP: ['mobile'],
      },
    },
    {
      template: {
        method: 'POST',
        url: 'https://api.msg91.com/api/v5/otp/verify',
        query: {
          authkey: '93703ArFUOGiSSxY5ed37d31P1',
          mobile: '{mobile}',
          otp: '{otp}',
        },
      },
      functions: {
        verifyOTP: ['mobile', 'otp'],
      },
    },
    {
      template: {
        method: 'POST',
        url: 'https://api.msg91.com/api/v5/flow/',
        query: {
          flow_id: '5feb57e144ef40731c6140e0',
          authkey: '93703ArFUOGiSSxY5ed37d31P1',
        },
        body: {
          mobiles: '{mobiles :number}',
          name: '{name :string}',
          url: '{url:string}',
          ordernum: '{ordernum :string}',
          mechname: '{mechname :string}',
          arrivaltime:'{arrivaltime :string}',
          vechiclemodel :'{vechiclemodel :string}',
          b: '{b=true}',
        },
      },
      functions: {
        sendSms: [
          'mobiles',
          'name',
          'url',
          'ordernum',
          'mechname',
          'arrivaltime',
          'vechiclemodel',
          {
            name: 'b',
            source: 'header',
          },
        ],
      },
    },
  ],
  crud: false,
};

// Observe application's life cycle to disconnect the datasource when
// application is stopped. This allows the application to be shut down
// gracefully. The `stop()` method is inherited from `juggler.DataSource`.
// Learn more at https://loopback.io/doc/en/lb4/Life-cycle.html
@lifeCycleObserver('datasource')
export class SmsDataSource extends juggler.DataSource
  implements LifeCycleObserver {
  static dataSourceName = 'sms';
  static readonly defaultConfig = config;

  constructor(
    @inject('datasources.config.sms', {optional: true})
    dsConfig: object = config,
  ) {
    super(dsConfig);
  }
}
