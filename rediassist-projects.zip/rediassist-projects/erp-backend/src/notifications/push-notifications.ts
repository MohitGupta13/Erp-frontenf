import * as firebase from 'firebase';
import * as firebaseAdmin from 'firebase-admin';
// const serviceAccount = require('../../ra-dev-mechapp-9226f801c92c.json');
// import * as serviceAccount from '../ra-prod-mechapp.json';
import * as serviceAccount from '../ra-vendor-app-dev.json';


// const config = {
//   type: "service_account",
//   projectId: "ra-vendor-app-dev",
//   privateKeyId: "62295439b2fd7093e85e005c37433b48edc82d9f",
//   privateKey: "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCR8juMR69FmGic\n97GpKIKtCxSBYIWxoJfr+xhcSoFDF/K9xFVmBQGGv8enQsQNJ67mHbkLOCUmxkj8\n9qJar0jvrLKUmU2vrRsM0cn6G3t4lCDUTGxPH0XgBzd+221KUSBHqcAWXLMr8iZt\nFUK6I8u+9RuETHQHQXDjS4CZal48OaiDQUNrmdxfGIr4hdMroJNxU5VUXBT5PNIE\nCZZl6nMpOjMTI+q9ZtXe5BJf0KgMgHHsb2biPBBTLwaKZx30WfsNjOuVVBKlvzIx\nriOZhzIs5Yxg/yeXqXmz4wJ1kHu3EP0GkBPZmqkL040I3YHB031Fcnyjj4r3KC1G\nRa2HOvkdAgMBAAECggEAFyj5iilWBxVIhKBJ8S4cjplTh7RpguaZNTmDhCHOoXcL\nblHZu3bP5zJH3KMbuXqyppHQ65bdTmno6zu4R+vJBz/AlxQ838P4pvAjvSzfSyM2\nknoONgAgdoyuodLwZPq6xKSLdwD+7dpffrABBsjnbEY5N6VqRDx+TZONtMrMaYH/\nbsjMtgIHqR9TQN9Zb51W3FqUrCkhtvKWCU6jyNXbY5N7LPsECfMAtuogE/8ji722\nydeOhswtUBORCT8MDHd2j1JBhJaWR05FL1tPIW708XyDJ1OyaPlxitrcyRFDJmRp\n/BzF9thvsVf2zKiccm9Up/qFIJkxIdPGuNSALgfUAQKBgQDLStZxWI3j6eEzlS4b\nARLxgNleG1HzUEzKJYABYmt+gxbYpsUp4BaNeJGAjvDUl8N2HRO/tPmHG3UL1m0C\nI0BsEdRykO/YRxvPBArqOgdgJgioBQnV4tNbZpVZJa1m3Jtz2tHKyyI6qbh5x7tD\nvZzSfrz9AZT+FTs4lDwzfhP3FQKBgQC3ySZm+kP0PrGF22bTXfr2YLAlukZxNwKd\nocUf23rpyG429z7TpZujhyOHn0Tb2lHLkyPqK9CdAJD97qhzwUJxq/JY8ngL8pzH\nRgs8mp+Qoy8XdvcMeK4Uvmz7IqSNk2FwvUzOezYapaiozVuFB9yyFFEjl8ezmh/y\nBaZmR/h76QKBgFCXeY3zukR5SpMFeAKymUzudL3O/N0Fn3ugBDAIUW8VDvCSpKUm\nNiqdeqlJgYX2KEHh4xtj5mw+YVdxCUQIr5hoNR26Aatu/UJDawRSPuxKB7J8VNrb\nEkkw0NJHkoetu17hh7vqbcZt1DlLCh0fxVTZc5ilkOhtiE20zmzndYjFAoGBAIRX\n9DBpfW+vibRjhsskPOkYPSAd4EX8oASVDldffEZHD57DMlnEQqxiTyKFfVd4Aji/\nTzh8rq+wTbieGG2quEcU0+JbUDkCTwVsmgDdM5Q6/lk+UK6JZIoJin7ZtndArwU5\nO8rgjNhpfGd54bKNM86EtN0Vmjfp/6EPkoDKyNOpAoGBALeiivGviYQ4zSoopZEf\nqOJzZPpNt64VpGZH3frwPBrwzUDF2Qmh2DXjfi7adZak7yLIRQzWJ6TGWt4fVWbh\nN3RReKsrQQclr0h3I3+oswm/3r4Uit+dcMYcCVHmACG11Cc01InTC42nR/b1Ov5/\n6v4+1KOniIaHKR71nJWi+B7/",
//   clientEmail: "firebase-adminsdk-9lrvp@ra-vendor-app-dev.iam.gserviceaccount.com",
//   clientId: "105108010927011102915",
//   authUri: "https://accounts.google.com/o/oauth2/auth",
//   tokenUri: "https://oauth2.googleapis.com/token",
//   auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
//   client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-9lrvp%40ra-vendor-app-dev.iam.gserviceaccount.com"
// }

const config = {
  type: serviceAccount.type,
  projectId: serviceAccount.project_id,
  privateKeyId: serviceAccount.private_key_id,
  privateKey: serviceAccount.private_key,
  clientEmail: serviceAccount.client_email,
  clientId: serviceAccount.client_id,
  authUri: serviceAccount.auth_uri,
  tokenUri: serviceAccount.token_uri,
  authProviderX509CertUrl: serviceAccount.auth_provider_x509_cert_url,
  clientC509CertUrl: serviceAccount.client_x509_cert_url,
};

const options = {
  // credentials: firebaseAdmin.credential.applicationDefault(),
  // credentials: firebaseAdmin.credential.cert(serviceAccount),
  databaseURL: process.env.FIREBASE_DATABASE,
};

const mechapp = firebaseAdmin.initializeApp(options);
firebase.initializeApp(config);

export async function sendPushNotificationToMechanic(
  fcmToken: string,
  msg: Object,
  options: Object,
): Promise<number> {
  let retval = 0;
  await mechapp
    .messaging()
    .sendToDevice(fcmToken, msg, options)
    .then(res => {
      // actual message format is going to be {msgId: xxxxxx}
      retval = 1;
    })
    .catch(err => {
      console.log('Error sending notification');
      console.log(err);
      retval = 0;
    });

  return retval;
}
