export const NUM_CHARACTERS_IN_OTP = 5;
export const OTP_CHARACTERS = '123456789';

// trailing slash is very very imporotant
export const tmpFileDir = '/home/ubuntu/tmp/';

export const AUTH_STRATEGY = 'jwt';
export const OrderTransactionTimeInms = 30000;
export const VendorRadialDistance = 1000;

export enum serviceCodes {
	ACC_CABLE_REPLACEMENT = 'ACC_CABLE_REPLACEMENT',
	ACC_CABLE_REPLACEMENT_ADDON = 'ACC_CABLE_REPLACEMENT_ADDON',
	BAT_JUMP = 'BAT_JUMP',
	BAT_RECHARGE = 'BAT_RECHARGE',
	BAT_RECHARGE_ADDON = 'BAT_RECHARGE_ADDON',
	CARBURETOR_CLEANING = 'CARBURETOR_CLEANING',
	CHAIN_LINK_LOCK = 'CHAIN_LINK_LOCK',
	EXTRA_PUN = 'EXTRA_PUN',
	FLAT_BED_TOWING = 'FLAT_BED_TOWING',
	FT_TL = 'FT_TL',
	FT_TUBE = 'FT_TUBE',
	FUEL_DELI = 'FUEL_DELI',
	FUEL_PIPE_CHANGE = 'FUEL_PIPE_CHANGE',
	KEY_LOCK = 'KEY_LOCK',
	LIFT_TOWING = 'LIFT_TOWING',
	MINOR_REPAIR = 'MINOR_REPAIR',
	MISCELLANEOUS = 'MISCELLANEOUS',
	QUICK_SERVICE = 'QUICK_SERVICE',
	RIM_BEND_FIX = 'RIM_BEND_FIX',
	START_PROB = 'START_PROB',
	VALVE_NECK_CHANGE = 'VALVE_NECK_CHANGE',
	VALVE_PIN_CHANGE = 'VALVE_PIN_CHANGE',
	FLAT_TYRE = 'FLAT_TYRE',
	ZERO_DEGREE_TOWING = 'ZERO_DEGREE_TOWING',
	FTE_TUBE = 'FTE_TUBE',
	FTE_TUBELESS = 'FTE_TUBELESS'
}

export enum serviceCategoryTypes {
	RSA = 'RSA',
	TOWING = 'TOWING',
	ON_SPOT_REPAIRS = 'ON_SPOT_REPAIRS',
	GS = 'GS',
	INSPECTION = 'INSPECTION'
}


// this will be used later
export enum serviceSubCategoryTypes {
	TYRE_WORK = 'TYRE_WORK',
	BREAKDOWN_SUPPORT = 'BREAKDOWN_SUPPORT',
	BATTERY_JUMPSTART = 'BATTERY_JUMPSTART',
	FUEL_DELIVERY = 'FUEL_DELIVERY',
	KEY_LOCK_ASSISTANCE = 'KEY_LOCK_ASSISTANCE',
	TOWING = 'TOWING',
	CUSTODY_SERVICE = 'CUSTODY_SERVICE',
}


// all are in minutes
export enum serviceCategoryLeadTime {
	RSA = 30,
	TOWING = 30,
	ON_SPOT_REPAIRS = 30,
	GS = 30,
	INSPECTION = 30
}

// all are in minutes
export enum serviceCategoryIntervalTime {
	RSA = 30,
	TOWING = 30,
	ON_SPOT_REPAIRS = 30,
	GS = 30,
	INSPECTION = 30
}

// export enum serviceShift {
//     DAY = 'DAY',
//     NIGHT = 'NIGHT',
// }

export enum paymentFrequency {
	DAILY = 'DAILY',
	WEEKLY = 'WEEKLY',
	BIWEEKLY = 'BIWEEKLY',
	MONTHLY = 'MONTHLY'
}

export enum allowanceType {
	PERKM = 'PERKM',
	DAILYFIXED = 'DAILYFIXED'
}

export enum VendorStatus {
	IDLE = 0,
	IN_TRANSIT = 1,
	BUSY = 2,
	ON_BREAK = 3,
	OFF_DUTY = 4
};

export interface fileDownload {
	AcceptRanges?: string;
	LastModified?: string;
	ContentLength: number;
	ETag: string;
	ContentType: string;
	Body?: unknown;
}

export interface InvoiceServiceId {
	[key: string]: any;
}

export enum mechanicStatus {
	Idle = 0,
	InTransit = 1,
	Busy = 2,
	OnBreak = 3,
	NotOnDuty = 4,
}

export interface serviceQuantityPatch {
	serviceId: number;
	quantity: number;
}

export interface AdhocServiceQuantityPatch {
	serviceName: string;
	quantity: number;
	tax: number;
	rate: number;
}

export enum vehicleTypes {
	BIKE = 'BIKE',
	CAR = 'CAR',
	TRUCK = 'TRUCK'
}

// this is for front end and for easy reference for backend
// THIS SHOULD NOT BE USED IN BACKEND CODE INSTEAD USE ENUMs
// ==========================================================
export const taskStatus = {
	1: 'New Order',
	2: 'Mechanic Assigned',
	3: 'Mechanic Acknowledged',
	4: 'Mechanic Started',
	5: 'Mechanic Reached',
	6: 'Work Started',
	7: 'Work Completed',
	8: 'Payment Pending',
	9: 'Order Closed',
	10: 'Successful',
	11: 'Failed',
	12: 'Cancelled',
};


export enum TowingTypes {
	LIFTING = 0,
	FLATBED = 1,
	ZERO_DEGREE = 2,
	ALL = 3,
};

export enum TowingVehicleTypes {
	BIKE = 0,
	CAR = 1,
	ALL = 2,
};


// by default the teams will be of GENERAL type so it's type will be 0 in database.
export const TeamType = {
	0: 'GENERAL',
	1: 'AGG',
	'GENERAL': 0,
	'AGG': 1,
};
