export const enum PermissionKeys {

  // admin
  CreateJob = 'CreateJob',
  UpdateJob = 'UpdateJob',
  DeleteJob = 'DeleteJob',

  // normal authenticated user
  AccessAuthFeature = 'AccessAuthFeature',

  Admin = 'Admin',
  User = 'User',
  Mechanic = 'Mechanic',
  SuperAdmin = 'SuperAdmin',
  Customer = 'Customer',
  QualityUser = 'QualityUser',
  AreaManager = 'AreaManager'
}
