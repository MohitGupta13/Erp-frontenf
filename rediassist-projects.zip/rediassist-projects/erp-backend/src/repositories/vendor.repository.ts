import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {LocationRepository, ShiftRepository, TeamRepository} from '.';
import {MysqlDataSource} from '../datasources';
import {Location, Shift, Team, Vendor, VendorRelations} from '../models';

// export type Credentials = {
//   mobile: string;
// }


export class VendorRepository extends DefaultCrudRepository<
  Vendor,
  typeof Vendor.prototype.id,
  VendorRelations
  > {

  public readonly team: BelongsToAccessor<Team, typeof Vendor.prototype.id>;
  public readonly shift: BelongsToAccessor<Shift, typeof Vendor.prototype.id>;
  public readonly location: BelongsToAccessor<Location, typeof Vendor.prototype.id>;

  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource, @repository.getter('TeamRepository') protected teamRepositoryGetter: Getter<TeamRepository>, @repository.getter('ShiftRepository') protected shiftRepositoryGetter: Getter<ShiftRepository>, @repository.getter('LocationRepository') protected locationRepositoryGetter: Getter<LocationRepository>,
  ) {
    super(Vendor, dataSource);
    this.location = this.createBelongsToAccessorFor('location', locationRepositoryGetter,);
    this.registerInclusionResolver('location', this.location.inclusionResolver);
    this.shift = this.createBelongsToAccessorFor('shift', shiftRepositoryGetter,);
    this.registerInclusionResolver('shift', this.shift.inclusionResolver);
    this.team = this.createBelongsToAccessorFor('team', teamRepositoryGetter,);
    this.registerInclusionResolver('team', this.team.inclusionResolver);
  }
}
