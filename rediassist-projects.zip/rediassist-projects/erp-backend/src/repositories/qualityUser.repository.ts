import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {QualityUser, QualityUserRelations} from '../models';

export class QualityUserRepository extends DefaultCrudRepository<
  QualityUser,
  typeof QualityUser.prototype.id,
  QualityUserRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(QualityUser, dataSource);
  }
}
