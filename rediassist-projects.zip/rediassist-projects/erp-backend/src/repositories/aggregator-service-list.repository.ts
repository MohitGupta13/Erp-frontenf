import {DefaultCrudRepository} from '@loopback/repository';
import {AggregatorServiceList, AggregatorServiceListRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class AggregatorServiceListRepository extends DefaultCrudRepository<
  AggregatorServiceList,
  typeof AggregatorServiceList.prototype.id,
  AggregatorServiceListRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(AggregatorServiceList, dataSource);
  }
}
