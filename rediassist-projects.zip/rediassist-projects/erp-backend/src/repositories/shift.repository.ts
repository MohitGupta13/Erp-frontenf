import {DefaultCrudRepository} from '@loopback/repository';
import {Shift, ShiftRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ShiftRepository extends DefaultCrudRepository<
  Shift,
  typeof Shift.prototype.id,
  ShiftRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(Shift, dataSource);
  }
}
