import {inject} from '@loopback/core';
import {DefaultTransactionalRepository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {VendorSelfServeMapping, VendorSelfServeMappingRelations} from '../models';

export class VendorSelfServeMappingRepository extends DefaultTransactionalRepository<
  VendorSelfServeMapping,
  typeof VendorSelfServeMapping.prototype.cid,
  VendorSelfServeMappingRelations
  > {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(VendorSelfServeMapping, dataSource);
  }
}
