import {DefaultCrudRepository} from '@loopback/repository';
import {PaymentTypes, PaymentTypesRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class PaymentTypesRepository extends DefaultCrudRepository<
  PaymentTypes,
  typeof PaymentTypes.prototype.id,
  PaymentTypesRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(PaymentTypes, dataSource);
  }
}
