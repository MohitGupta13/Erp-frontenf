import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultTransactionalRepository, repository} from '@loopback/repository';
import {OrderRepository, VendorRepository} from '.';
import {MysqlDataSource} from '../datasources';
import {Order, OrderDetails, OrderDetailsRelations, Vendor} from '../models';

export class OrderDetailsRepository extends DefaultTransactionalRepository<
  OrderDetails,
  typeof OrderDetails.prototype.id,
  OrderDetailsRelations
  > {
  public readonly order: BelongsToAccessor<Order, typeof Order.prototype.id>;
  public readonly vendor: BelongsToAccessor<Vendor, typeof Order.prototype.id>;

  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
    @repository.getter('OrderRepository') protected orderRepositoryGetter: Getter<OrderRepository>,
    @repository.getter('VendorRepository') protected vendorRepositoryGetter: Getter<VendorRepository>,
  ) {
    super(OrderDetails, dataSource);
    this.order = this.createBelongsToAccessorFor('order', orderRepositoryGetter);
    this.registerInclusionResolver('order', this.order.inclusionResolver);
    this.vendor = this.createBelongsToAccessorFor('vendor', vendorRepositoryGetter);
    this.registerInclusionResolver('vendor', this.vendor.inclusionResolver);
  }
}
