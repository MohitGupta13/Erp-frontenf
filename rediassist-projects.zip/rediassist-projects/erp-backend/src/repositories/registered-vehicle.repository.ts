import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultCrudRepository, repository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {RegisteredVehicle, RegisteredVehicleRelations, VehicleMaster} from '../models';
import {VehicleMasterRepository} from './vehicle-master.repository';

export class RegisteredVehicleRepository extends DefaultCrudRepository<
  RegisteredVehicle,
  typeof RegisteredVehicle.prototype.id,
  RegisteredVehicleRelations
  > {

  public readonly vehicle: BelongsToAccessor<VehicleMaster, typeof RegisteredVehicle.prototype.id>;

  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource, @repository.getter('VehicleMasterRepository') protected vehicleMasterRepositoryGetter: Getter<VehicleMasterRepository>,
  ) {
    super(RegisteredVehicle, dataSource);
    this.vehicle = this.createBelongsToAccessorFor('vehicle', vehicleMasterRepositoryGetter);
    this.registerInclusionResolver('vehicle', this.vehicle.inclusionResolver);
  }
}
