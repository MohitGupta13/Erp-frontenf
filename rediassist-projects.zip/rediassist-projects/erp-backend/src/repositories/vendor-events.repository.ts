import {DefaultCrudRepository} from '@loopback/repository';
import {VendorEvents, VendorEventsRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class VendorEventsRepository extends DefaultCrudRepository<
  VendorEvents,
  typeof VendorEvents.prototype.id,
  VendorEventsRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(VendorEvents, dataSource);
  }
}
