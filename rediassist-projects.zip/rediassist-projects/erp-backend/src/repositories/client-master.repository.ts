import {DefaultCrudRepository} from '@loopback/repository';
import {ClientMaster, ClientMasterRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ClientMasterRepository extends DefaultCrudRepository<
  ClientMaster,
  typeof ClientMaster.prototype.id,
  ClientMasterRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(ClientMaster, dataSource);
  }
}
