import {DefaultCrudRepository} from '@loopback/repository';
import {UserClientMapping, UserClientMappingRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class UserClientMappingRepository extends DefaultCrudRepository<
  UserClientMapping,
  typeof UserClientMapping.prototype.id,
  UserClientMappingRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(UserClientMapping, dataSource);
  }
}
