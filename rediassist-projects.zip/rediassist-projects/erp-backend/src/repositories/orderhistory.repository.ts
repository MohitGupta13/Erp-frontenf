import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {Orderhistory, OrderhistoryRelations} from '../models';

export class OrderhistoryRepository extends DefaultCrudRepository<
  Orderhistory,
  typeof Orderhistory.prototype.id,
  OrderhistoryRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(Orderhistory, dataSource);
  }
}
