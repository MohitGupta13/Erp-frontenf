import {DefaultCrudRepository, repository, BelongsToAccessor} from '@loopback/repository';
import {VendorLead, VendorLeadRelations, Team, Shift, Location} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject, Getter} from '@loopback/core';
import {TeamRepository} from './team.repository';
import {ShiftRepository} from './shift.repository';
import {LocationRepository} from './location.repository';

export class VendorLeadRepository extends DefaultCrudRepository<
  VendorLead,
  typeof VendorLead.prototype.id,
  VendorLeadRelations
> {

  public readonly team: BelongsToAccessor<Team, typeof VendorLead.prototype.id>;

  public readonly shift: BelongsToAccessor<Shift, typeof VendorLead.prototype.id>;

  public readonly location: BelongsToAccessor<Location, typeof VendorLead.prototype.id>;

  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource, @repository.getter('TeamRepository') protected teamRepositoryGetter: Getter<TeamRepository>, @repository.getter('ShiftRepository') protected shiftRepositoryGetter: Getter<ShiftRepository>, @repository.getter('LocationRepository') protected locationRepositoryGetter: Getter<LocationRepository>,
  ) {
    super(VendorLead, dataSource);
    this.location = this.createBelongsToAccessorFor('location', locationRepositoryGetter,);
    this.registerInclusionResolver('location', this.location.inclusionResolver);
    this.shift = this.createBelongsToAccessorFor('shift', shiftRepositoryGetter,);
    this.registerInclusionResolver('shift', this.shift.inclusionResolver);
    this.team = this.createBelongsToAccessorFor('team', teamRepositoryGetter,);
    this.registerInclusionResolver('team', this.team.inclusionResolver);
  }
}
