import {Getter, inject} from '@loopback/core';
import {BelongsToAccessor, DefaultTransactionalRepository, repository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {Location, Order, OrderRelations, ServiceMaster, VehicleMaster} from '../models';
import {LocationRepository} from './location.repository';
import {ServiceMasterRepository} from './service-master.repository';
import {VehicleMasterRepository} from './vehicle-master.repository';

export class OrderRepository extends DefaultTransactionalRepository<
  Order,
  typeof Order.prototype.id,
  OrderRelations
  > {

  public readonly vehicle: BelongsToAccessor<VehicleMaster, typeof Order.prototype.id>;
  public readonly service: BelongsToAccessor<ServiceMaster, typeof Order.prototype.id>;
  public readonly location: BelongsToAccessor<Location, typeof Order.prototype.id>;

  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
    @repository.getter('VehicleMasterRepository') protected vehicleMasterRepositoryGetter: Getter<VehicleMasterRepository>,
    @repository.getter('LocationRepository') protected locationRepositoryGetter: Getter<LocationRepository>,
    @repository.getter('ServiceMasterRepository') protected serviceMasterRepositoryGetter: Getter<ServiceMasterRepository>,
  ) {
    super(Order, dataSource);
    this.vehicle = this.createBelongsToAccessorFor('vehicle', vehicleMasterRepositoryGetter);
    this.registerInclusionResolver('vehicle', this.vehicle.inclusionResolver);
    this.service = this.createBelongsToAccessorFor('service', serviceMasterRepositoryGetter);
    this.registerInclusionResolver('service', this.service.inclusionResolver);
    this.location = this.createBelongsToAccessorFor('location', locationRepositoryGetter);
    this.registerInclusionResolver('location', this.location.inclusionResolver);
  }
}
