import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {VendorHistory, VendorHistoryRelations} from '../models';

export class VendorHistoryRepository extends DefaultCrudRepository<
  VendorHistory,
  typeof VendorHistory.prototype.id,
  VendorHistoryRelations
  > {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(VendorHistory, dataSource);
  }
}
