export * from './address.repository';
export * from './aggregator-service-list.repository';
export * from './aggregator-service.repository';
export * from './area-manager.repository'; //added by deval
export * from './client-master.repository';
export * from './coupon-trans.repository';
export * from './coupon.repository';
export * from './customer.repository';
export * from './file.repository';
export * from './invoice.repository';
export * from './location.repository';
export * from './order-details.repository';
export * from './order.repository';
export * from './orderhistory.repository';
export * from './payment-types.repository';
export * from './qualityUser.repository'; //added by deval
export * from './registered-vehicle.repository';
export * from './role.repository';
export * from './service-master.repository';
export * from './shift.repository';
export * from './sms-log.repository';
export * from './team.repository';
export * from './transaction.repository';
export * from './user.repository';
export * from './vehicle-master.repository';
export * from './vendor-history.repository';
export * from './vendor-lead.repository';
export * from './vendor.repository';

export * from './payment-types.repository';
export * from './aggregator-service.repository';
export * from './aggregator-service-list.repository';
export * from './vendor-self-serve-mapping.repository';
export * from './user-client-mapping.repository';
export * from './vendor-events.repository';

