import {DefaultCrudRepository} from '@loopback/repository';
import {ServiceMaster, ServiceMasterRelations} from '../models';
import {MysqlDataSource} from '../datasources';
import {inject} from '@loopback/core';

export class ServiceMasterRepository extends DefaultCrudRepository<
  ServiceMaster,
  typeof ServiceMaster.prototype.id,
  ServiceMasterRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(ServiceMaster, dataSource);
  }
}
