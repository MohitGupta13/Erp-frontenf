import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqlDataSource} from '../datasources';
import {AreaManager, AreaManagerRelations} from '../models';

export class AreaManagerRepository extends DefaultCrudRepository<
AreaManager,
  typeof AreaManager.prototype.id,
  AreaManagerRelations
> {
  constructor(
    @inject('datasources.mysql') dataSource: MysqlDataSource,
  ) {
    super(AreaManager, dataSource);
  }
}
