import {inject, Provider} from '@loopback/core';
import {getService} from '@loopback/service-proxy';
import {RaGeoLocationDataSource} from '../datasources';

/*
 * Fix the service type. Possible options can be:
 * - import {Elasticqueries} from 'your-module';
 * - export type Elasticqueries = string;
 * - export interface Elasticqueries {}
 */
// export type Elasticqueries = unknown;

export interface Elasticqueries {
  // this is where we define the nodejs methods defined in the data sources
  get(url: string): Promise<any>;
  post(url: string, body: object): Promise<any>;
  getWithBody(url: string, body: object): Promise<any>;
}


export class ElasticqueriesProvider implements Provider<Elasticqueries> {
  constructor(
    @inject('datasources.rageolocation')
    protected dataSource: RaGeoLocationDataSource = new RaGeoLocationDataSource(),
  ) {}

  value(): Promise<Elasticqueries> {
    return getService(this.dataSource);
  }
}
