import {inject, Provider} from '@loopback/core';
import {getService} from '@loopback/service-proxy';
import {SmsDataSource} from '../datasources';

export interface Smsotp {
  // this is where you define the Node.js methods that will be
  // mapped to REST/SOAP/gRPC operations as stated in the datasource
  // json file.
  sendOTP(mobile: string, otp: number): Promise<any>;
  resendOTP(mobile: string): Promise<any>;
  verifyOTP(mobile: string, otp: number): Promise<any>;
  sendSms(mobiles: string, name: string,url:string,ordernum:string,mechname:string,arrivaltime:string,vechiclemodel :string): Promise<any>;
}

export class SmsotpProvider implements Provider<Smsotp> {
  constructor(
    // sms must match the name property in the datasource json file
    @inject('datasources.sms')
    protected dataSource: SmsDataSource = new SmsDataSource(),
  ) {}

  value(): Promise<Smsotp> {
    return getService(this.dataSource);
  }
}
