import {HttpErrors} from '@loopback/rest';
import {Credentials} from '../repositories/index';


export function validateCredentials(credentials: Credentials) {
  // var phonereg = /^\d{10}$/;

  // if (!credentials.mobileNo.match(phonereg)) {
  //   throw new HttpErrors.UnprocessableEntity('invalid Phone No');
  // }

  if (credentials.password.length < 8) {
    throw new HttpErrors.UnprocessableEntity('password length should be greater than 8')
  }
}

export async function makeProperPhoneNumber(phoneNumber:string):Promise<string>{

  if(phoneNumber!.length == 11) //'09876543210
    return '91'+phoneNumber.slice(1,11);

  if(phoneNumber!.length == 13)  //'+919876543210'
    return  phoneNumber.slice(1,13);

  return '91'+phoneNumber;

}
