import {ApplicationConfig} from '@loopback/core';
import {ErpBackendApplication, socketApplication} from './application';

export * from './application';
export {ErpBackendApplication};
export {socketApplication};



export async function main(options: ApplicationConfig = {}) {
  const app = new ErpBackendApplication(options);
  await app.boot();
  await app.migrateSchema();
  await app.start();

  const url = app.restServer.url;
  console.log(`🚀 Readyassist Server is running at ${url}`);


  const apps = new socketApplication(options);
  await apps.start();
  console.log('🚀 Readyassist Socket Server is listening to %s', apps.socketServer.url)

  return app;
}
