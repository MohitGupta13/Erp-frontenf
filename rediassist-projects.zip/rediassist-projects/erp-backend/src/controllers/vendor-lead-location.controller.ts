import {authenticate} from '@loopback/authentication';
import {repository} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Location, VendorLead} from '../models';
import {VendorLeadRepository} from '../repositories';

export class VendorLeadLocationController {
  constructor(
    @repository(VendorLeadRepository)
    public vendorLeadRepository: VendorLeadRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads/{id}/location', {
    responses: {
      '200': {
        description: 'Location belonging to VendorLead',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Location)},
          },
        },
      },
    },
  })
  async getLocation(
    @param.path.number('id') id: typeof VendorLead.prototype.id,
  ): Promise<Location> {
    return this.vendorLeadRepository.location(id);
  }
}
