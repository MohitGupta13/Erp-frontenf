import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {Count, CountSchema, Filter, FilterExcludingWhere, IsolationLevel, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, Request, requestBody, RestBindings} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, OrderTransactionTimeInms, VendorStatus} from '../constants';
import {TokenServiceBindings} from '../keys';
import {Order, OrderDetails, Vendor} from '../models';
import {sendPushNotificationToMechanic} from '../notifications';
import {OrderDetailsRepository, OrderhistoryRepository, OrderRepository, VendorRepository} from '../repositories';
import {JWTService} from '../services/jwt-service';

export class OrderDetailController {
  constructor(
    @repository(OrderDetailsRepository)
    public orderDetailsRepository: OrderDetailsRepository,

    @inject('repositories.OrderRepository')
    public orderRepository: OrderRepository,

    @inject('repositories.VendorRepository')
    public vendorRepository: VendorRepository,

    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService,

    @inject(RestBindings.Http.REQUEST)
    private req: Request,

    @inject('repositories.OrderhistoryRepository')
    public orderHistoryRepository: OrderhistoryRepository,

  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/order-details', {
    responses: {
      '200': {
        description: 'OrderDetails model instance',
        content: {'application/json': {schema: getModelSchemaRef(OrderDetails)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OrderDetails, {
            title: 'NewOrderDetails',
            exclude: ['id'],
          }),
        },
      },
    })
    orderDetails: Omit<OrderDetails, 'id'>,
  ): Promise<any> {
    try {
      const tx = await this.orderDetailsRepository.dataSource.beginTransaction({
        isolationLevel: IsolationLevel.READ_COMMITTED,
        timeout: OrderTransactionTimeInms,
      });

      // first check if the mechanic is not blocked or if actually on duty
      const mechanicDetails: Vendor = await this.vendorRepository.findById(orderDetails.vendorId);

      if (!mechanicDetails.isActive) {
        return {
          statusCode: 500,
          message: "Vendor is Blocked!"
        }
      }

      if (mechanicDetails.status === VendorStatus.OFF_DUTY) {
        return {
          statusCode: 500,
          message: "Vendor is not on duty"
        }
      }

      const ordDetails: OrderDetails = await this.orderDetailsRepository.create(orderDetails, {tx});
      const originalOrder: Order = await this.orderRepository.findById(orderDetails.orderId);
      const token = this.req.headers.authorization?.split(' ')[1];
      const userProfile = await this.jwtService.verifyToken(token!);
      await this.orderHistoryRepository.create({
        orderId: originalOrder.id,
        orderJson: originalOrder,
        actionPerformed: 'ASSIGNED',
        location: '',                   // as of now the system is not capable of capturing order assignment location
        changedBy: userProfile,
      }, {tx});
      await this.orderRepository.updateById(ordDetails.orderId, {status: 2}, {tx});
      const msg: Object = {
        notification: {
          title: "Readyassist NEW ORDER!",
          body: "#" + ordDetails.orderId + " assigned to you!",
          sound: 'default'
        }
      };
      const options: Object = {
        priority: 'high',
      };
      await tx.commit();
      if (mechanicDetails.fcmToken) {
        await sendPushNotificationToMechanic(mechanicDetails.fcmToken, msg, options);
      }
      return ordDetails;
    } catch (e) {
      return {
        statusCode: 500,
        message: "Internal Server Error"
      }
    }
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/order-details/count', {
    responses: {
      '200': {
        description: 'OrderDetails model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(OrderDetails) where?: Where<OrderDetails>,
  ): Promise<Count> {
    return this.orderDetailsRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @get('/mobile/order-details', {
    responses: {
      '200': {
        description: 'Array of OrderDetails model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(OrderDetails, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async findMobile(
    @param.filter(OrderDetails) filter?: Filter<OrderDetails>,
  ): Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const orderDetails = await this.orderDetailsRepository.find({where: {vendorId: userProfile.vendorId, isActive: true}, include: [{relation: 'order', scope: {include: [{relation: 'service'}, {relation: 'vehicle'}]}}]});


    // let orderDetailsRes = {...orderDetails, order: {}};
    // for (let i = 0; i < orderDetails.length; i++) {
    //   orderDetails[i].order = await this.orderRepository.findOne({where: {id: orderDetails[i].orderId}});
    // }

    return {
      statusCode: 200,
      message: "Order with order details",
      orderDetails: orderDetails
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/order-details', {
    responses: {
      '200': {
        description: 'Array of OrderDetails model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(OrderDetails, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(OrderDetails) filter?: Filter<OrderDetails>,
  ): Promise<OrderDetails[]> {
    return this.orderDetailsRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/order-details', {
    responses: {
      '200': {
        description: 'OrderDetails PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OrderDetails, {partial: true}),
        },
      },
    })
    orderDetails: OrderDetails,
    @param.where(OrderDetails) where?: Where<OrderDetails>,
  ): Promise<Count> {
    return this.orderDetailsRepository.updateAll(orderDetails, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/order-details/{id}', {
    responses: {
      '200': {
        description: 'OrderDetails model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(OrderDetails, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(OrderDetails, {exclude: 'where'}) filter?: FilterExcludingWhere<OrderDetails>
  ): Promise<OrderDetails> {
    return this.orderDetailsRepository.findById(id, filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/mobile/order-details/{id}', {
    responses: {
      '204': {
        description: 'OrderDetails PATCH success',
      },
    },
  })
  async updateByIdPatchMobile(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OrderDetails, {partial: true}),
        },
      },
    })
    orderDetails: OrderDetails,
  ): Promise<void> {
    await this.orderDetailsRepository.updateById(id, orderDetails);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/order-details/{id}', {
    responses: {
      '204': {
        description: 'OrderDetails PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OrderDetails, {partial: true}),
        },
      },
    })
    orderDetails: OrderDetails,
  ): Promise<void> {
    await this.orderDetailsRepository.updateById(id, orderDetails);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/mobile/order-details/{id}', {
    responses: {
      '204': {
        description: 'OrderDetails PATCH success',
      },
    },
  })
  async updateByIdMobile(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(OrderDetails, {partial: true}),
        },
      },
    })
    orderDetails: OrderDetails,
  ): Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const orderDetailsData = await this.orderDetailsRepository.findById(id);
    if (orderDetailsData.vendorId !== userProfile.vendorId)
      return {
        statusCode: 400,
        message: "Unauthorized Error This order is not for you"
      }

    await this.orderDetailsRepository.updateById(id, orderDetails);
    return {
      statusCode: 200,
      message: "Order Details Update Successfully"
    }
  }



  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/order-details/{id}', {
    responses: {
      '204': {
        description: 'OrderDetails PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() orderDetails: OrderDetails,
  ): Promise<void> {
    await this.orderDetailsRepository.replaceById(id, orderDetails);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/order-details/{id}', {
    responses: {
      '204': {
        description: 'OrderDetails DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.orderDetailsRepository.deleteById(id);
  }
}
