import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {ClientMaster} from '../models';
import {ClientMasterRepository} from '../repositories';

export class ClientMasterController {
  constructor(
    @repository(ClientMasterRepository)
    public clientMasterRepository: ClientMasterRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
  @post('/client-masters', {
    responses: {
      '200': {
        description: 'ClientMaster model instance',
        content: {'application/json': {schema: getModelSchemaRef(ClientMaster)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ClientMaster, {
            title: 'NewClientMaster',
            exclude: ['id'],
          }),
        },
      },
    })
    clientMaster: Omit<ClientMaster, 'id'>,
  ): Promise<ClientMaster> {
    return this.clientMasterRepository.create(clientMaster);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/client-masters/count', {
    responses: {
      '200': {
        description: 'ClientMaster model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(ClientMaster) where?: Where<ClientMaster>,
  ): Promise<Count> {
    return this.clientMasterRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Customer, PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
  @get('/client-masters', {
    responses: {
      '200': {
        description: 'Array of ClientMaster model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ClientMaster, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(ClientMaster) filter?: Filter<ClientMaster>,
  ): Promise<ClientMaster[]> {
    return this.clientMasterRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/client-masters', {
    responses: {
      '200': {
        description: 'ClientMaster PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ClientMaster, {partial: true}),
        },
      },
    })
    clientMaster: ClientMaster,
    @param.where(ClientMaster) where?: Where<ClientMaster>,
  ): Promise<Count> {
    return this.clientMasterRepository.updateAll(clientMaster, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/client-masters/{id}', {
    responses: {
      '200': {
        description: 'ClientMaster model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(ClientMaster, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(ClientMaster, {exclude: 'where'}) filter?: FilterExcludingWhere<ClientMaster>
  ): Promise<ClientMaster> {
    return this.clientMasterRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/client-masters/{id}', {
    responses: {
      '204': {
        description: 'ClientMaster PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ClientMaster, {partial: true}),
        },
      },
    })
    clientMaster: ClientMaster,
  ): Promise<void> {
    await this.clientMasterRepository.updateById(id, clientMaster);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/client-masters/{id}', {
    responses: {
      '204': {
        description: 'ClientMaster PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() clientMaster: ClientMaster,
  ): Promise<void> {
    await this.clientMasterRepository.replaceById(id, clientMaster);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/client-masters/{id}', {
    responses: {
      '204': {
        description: 'ClientMaster DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.clientMasterRepository.deleteById(id);
  }
}
