import '@firebase/firestore';
import {authenticate} from '@loopback/authentication';
import {UserRepository} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {Count, CountSchema, Filter, FilterExcludingWhere, IsolationLevel, repository, Transaction, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, Request, requestBody, RestBindings} from '@loopback/rest';
import * as turf from '@turf/turf';
import * as firebase from 'firebase';
import * as admin from 'firebase-admin';
import * as geofirestore from 'geofirestore';
import _ from 'lodash';
import moment from 'moment';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, InvoiceServiceId, mechanicStatus, NUM_CHARACTERS_IN_OTP, OrderTransactionTimeInms, OTP_CHARACTERS} from '../constants';
import {PasswordHasherBindings, TokenServiceBindings, UserServiceBindings} from '../keys';
import {Order, OrderDetails, Vendor} from '../models';
import {sendPushNotificationToMechanic} from '../notifications';
import {ClientMasterRepository, CustomerRepository, InvoiceRepository, OrderDetailsRepository, OrderhistoryRepository, OrderRepository, RegisteredVehicleRepository, ServiceMasterRepository, SmsLogRepository, VendorHistoryRepository, VendorRepository, VendorSelfServeMappingRepository} from '../repositories';
// import * as moment from 'moment'
import {VendorEventsRepository} from '../repositories/vendor-events.repository';
import {Smsotp} from '../services';
import {BcryptHasher} from '../services/hash.password';
import {JWTService} from '../services/jwt-service';
import {MyUserService} from '../services/user-service';
import {ElasticqueriesController} from './elasticqueries.controller';

// console.log("Here")
// const serviceAccount = require('../../ra-vendor-app-dev-62295439b2fd.json');
// console.log("app length---",admin.apps.length)

// if(!admin.apps.length){
//   admin.initializeApp({
//     credential: admin.credential.cert(serviceAccount),
//     // databaseURL: "https://prefab-mountain-509.firebaseio.com"
//   });
// }


const db = admin.firestore();



interface verifyOtpInterface {
  mobile: string;
  otp: number;
  deviceId: string;
  fcmToken: string;
}

interface mobileExists {
  mobile: string;
}

interface ItaskGeoPoint {
  lon: number;
  lat: number;
}


interface vendorStatusBody {
  status: number;
}

export class VendorController {
  constructor(
    @repository(VendorRepository)
    public vendorRepository: VendorRepository,


    @inject('repositories.VendorHistoryRepository') public vendorHistoryRepository: VendorHistoryRepository,
    @inject('repositories.SmsLogRepository') public smsLogRepository: SmsLogRepository,
    @inject('repositories.UserRepository') public userRepository: UserRepository,
    @inject('repositories.OrderRepository') public orderRepository: OrderRepository,
    @inject('repositories.VendorSelfServeMappingRepository') public vendorSelfServeMappingRepository: VendorSelfServeMappingRepository,
    @inject('repositories.ClientMasterRepository') public clientMasterRepository: ClientMasterRepository,
    @inject('controllers.ElasticqueriesController') public elasticQueries: ElasticqueriesController,
    @inject('services.Smsotp') protected smsService: Smsotp,
    @inject('repositories.CustomerRepository') public customerRepository: CustomerRepository,
    @inject('repositories.OrderhistoryRepository') public orderHistoryRepository: OrderhistoryRepository,
    @inject('repositories.ServiceMasterRepository') public serviceMasterRepository: ServiceMasterRepository,
    @inject('repositories.InvoiceRepository') public invoiceRepository: InvoiceRepository,
    @inject('repositories.RegisteredVehicleRepository') public registeredVehicleRepository: RegisteredVehicleRepository,
    @inject('repositories.OrderDetailsRepository') public orderDetailsRepository: OrderDetailsRepository,
    @inject('repositories.VendorEventsRepository') public vendorEventsRepository: VendorEventsRepository,


    // @inject('service.hasher')
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public hasher: BcryptHasher,


    @inject(UserServiceBindings.USER_SERVICE)
    public userService: MyUserService,

    // @inject('service.jwt.service')
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService,


    @inject(RestBindings.Http.REQUEST)
    private req: Request
  ) {
    this.vendorHistoryRepository = vendorHistoryRepository;
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/vendors', {
    responses: {
      '200': {
        description: 'Vendor model instance',
        content: {'application/json': {schema: getModelSchemaRef(Vendor)}},
      },
    },
  })
  //here
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Vendor, {
            title: 'NewVendor',
            exclude: ['id'],
          }),
        },
      },
    })
    vendor: Omit<Vendor, 'id'>,
  ): Promise<Vendor> {
    vendor.isActive = false;
    const vendorCreated = await this.vendorRepository.create(vendor);

    await this.vendorHistoryRepository.create({
      vendorId: vendorCreated.getId(),
      vendorJson: vendor,
      actionPerformed: 'CREATE',
    });

    return this.vendorRepository.findById(vendorCreated.getId());
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/mobile/vendors', {
    responses: {
      '200': {
        description: 'Vendor model instance',
        content: {'application/json': {schema: getModelSchemaRef(Vendor)}},
      },
    },
  })
  async createMobile(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Vendor, {
            title: 'NewVendor',
            exclude: ['id'],
          }),
        },
      },
    })
    vendor: Omit<Vendor, 'id'>,
  ): Promise<any> {

    try {
      const tx = await this.vendorRepository.dataSource.beginTransaction({
        isolationLevel: IsolationLevel.READ_COMMITTED,
      });

      const vendorCreated = await this.vendorRepository.create(vendor, {tx});
      await this.vendorHistoryRepository.create({
        vendorId: vendorCreated.getId(),
        vendorJson: vendor,
        actionPerformed: 'CREATE',
      }, {tx});
      // const v = await this.vendorRepository.findById(vendorCreated.getId(), {}, {tx});
      await tx.commit();
      return {
        statusCode: 200,
        message: "Vendor Created!",
        vendor: vendorCreated
      }
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      }
    }
  }



  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @post('/mobile/vendors_status', {
    responses: {
      '200': {
        description: 'Vendor Status',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                mechanicStatus: {
                  type: 'number'
                }
              }
            }
          },
        },
      },
    },
  })
  async vendorStatus(@requestBody() body: {
    mechanicStatus: number
  }):
    Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const id = userProfile.vendorId;
    const vendor = await this.vendorRepository.findById(id);

    const possibleValues: any[] = Object.values(mechanicStatus);
    const status = possibleValues.includes(body.mechanicStatus);
    if (status === false)
      return {
        statusCode: 400,
        message: "Unsuccessful request"
      }

    vendor.status = body.mechanicStatus;
    await this.vendorRepository.updateById(id, vendor);
    await this.vendorEventsRepository.create({vid: vendor.id, state: body.mechanicStatus});
    return {
      statusCode: 200,
      vendorStatus: vendor.status
    }
  }



  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @get('/mobile/vendors_status', {
    responses: {
      '200': {
        description: 'Vendor Status',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                mechanicStatus: {
                  type: 'number'
                }
              }
            }
          },
        },
      },
    },
  })
  async getVendorStatus():
    Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const id = userProfile.vendorId;
    const vendor = await this.vendorRepository.findById(id);

    return {
      statusCode: 200,
      vendorId: vendor.id,
      vendorStatus: vendor.status
    }
  }



  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.QualityUser]})
  @get('/vendors/count', {
    responses: {
      '200': {
        description: 'Vendor model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(Vendor) where?: Where<Vendor>,
  ): Promise<Count> {
    return this.vendorRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.QualityUser]})
  @get('/mobile/vendors/count', {
    responses: {
      '200': {
        description: 'Vendor model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async mobileCount(
    @param.where(Vendor) where?: Where<Vendor>,
  ): Promise<Count> {
    return this.vendorRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
  @get('/vendors', {
    responses: {
      '200': {
        description: 'Array of Vendor model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Vendor, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(Vendor) filter?: Filter<Vendor>,
  ): Promise<Vendor[]> {
    return this.vendorRepository.find(filter, {include: [{relation: 'location'}, {relation: 'team'}, {relation: 'shift'}]});
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/mobile/vendorlist', {
    responses: {
      '200': {
        description: 'Array of Vendor model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Vendor, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async mobileFind(
    @param.filter(Vendor) filter?: Filter<Vendor>,
  ): Promise<any> {
    try {
      const vendorList = await this.vendorRepository.find(filter, {include: [{relation: 'location'}, {relation: 'team'}, {relation: 'shift'}]});
      return {
        statusCode: 200,
        message: "Get Vendor List Successfully",
        VendorList: vendorList
      }
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      }
    }
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendors', {
    responses: {
      '200': {
        description: 'Vendor PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Vendor, {partial: true}),
        },
      },
    })
    vendor: Vendor,
    @param.where(Vendor) where?: Where<Vendor>,
  ): Promise<Count> {
    vendor.updatedAt = new Date().toString();
    return this.vendorRepository.updateAll(vendor, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendors/{id}', {
    responses: {
      '200': {
        description: 'Vendor model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Vendor, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Vendor, {exclude: 'where'}) filter?: FilterExcludingWhere<Vendor>
  ): Promise<Vendor> {
    return this.vendorRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @get('/mobile/vendors/', {
    responses: {
      '200': {
        description: 'Vendor model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Vendor, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findByIdMobile(): Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const vendor = await this.vendorRepository.findById(userProfile.vendorId, {include: [{relation: 'location'}, {relation: 'team'}, {relation: 'shift'}]});
    return {
      statusCode: 200,
      message: "Get Vendor Successfully",
      vendorDetails: vendor
    }
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendors/{id}', {
    responses: {
      '204': {
        description: 'Vendor PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Vendor, {partial: true}),
        },
      },
    })
    vendor: Vendor,
  ): Promise<void> {
    // create the data in vendor history and then make
    // the same entry in the vendor repository directly.
    await this.vendorHistoryRepository.create({
      vendorId: id,
      vendorJson: vendor,
      actionPerformed: 'UPDATE',
    });
    await this.vendorRepository.updateById(id, vendor);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/mobile/vendors/{id}', {
    responses: {
      '204': {
        description: 'Vendor PATCH success',
      },
    },
  })
  async updateByIdMobile(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Vendor, {partial: true}),
        },
      },
    })
    vendor: Vendor,
  ): Promise<void> {
    // create the data in vendor history and then make
    // the same entry in the vendor repository directly.
    const tx = await this.vendorRepository.dataSource.beginTransaction({
      isolationLevel: IsolationLevel.READ_COMMITTED,
    });
    await this.vendorHistoryRepository.create({
      vendorId: id,
      vendorJson: vendor,
      actionPerformed: 'UPDATE',
    }, {tx});
    await this.vendorRepository.updateById(id, vendor, {tx});
    await tx.commit();
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/vendors/{id}', {
    responses: {
      '204': {
        description: 'Vendor PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() vendor: Vendor,
  ): Promise<void> {
    await this.vendorHistoryRepository.create({
      vendorId: id,
      vendorJson: vendor,
      actionPerformed: 'REPLACE',
    })
    await this.vendorRepository.replaceById(id, vendor);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/vendors/{id}', {
    responses: {
      '204': {
        description: 'Vendor DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.vendorHistoryRepository.create({
      vendorId: id,
      vendorJson: await this.vendorRepository.findById(id),
      actionPerformed: 'DELETE',
    })
    await this.vendorRepository.deleteById(id);
  }

  @post('/mobile/vendorMobileExist/{mobile}', {
    responses: {
      '204': {
        description: 'Mobile Number verification',
      },
    },
  })
  async findVendorByMobile(@param.path.string('mobile') mobile: string
  ): Promise<any> {
    const response = await this.vendorRepository.find({where: {mobile: mobile}});
    if (response.length > 0) {
      return {
        statusCode: 200,
        exists: true
      }
    }

    return {
      statusCode: 200,
      exists: false
    }
  }


  @post('/mobile/existence/{mobile}', {
    responses: {
      '204': {
        description: 'Mobile Number verification',
      },
    },
  })
  async findBymobile(@param.path.string('mobile') mobile: string
  ): Promise<any> {
    return this.vendorMobileExistenceHelper(mobile);
  }


  @post('/mobile/existence/', {
    responses: {
      '204': {
        description: 'Mobile Number verification',
      },
      '200': {
        description: 'Mobile Number found!',
      },
      '404': {
        description: 'Mobile number not found',
      }
    },
  })
  async findByMobileBody(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'Vendor phone exists?',
                properties: {
                  "mobile": {
                    "type": "string"
                  }
                },
                required: ["mobile"],
                additionalProperties: false
              }
            },
            "example": {
              "mobile": "919988776655"
            }
          }
        }
      }
    }) data: mobileExists,
  ) {
    const mobile = data.mobile;
    return this.vendorMobileExistenceHelper(mobile);
  }

  async vendorMobileExistenceHelper(mobile: string) {
    const userExistence = await this.userRepository.find({where: {mobileNo: mobile}});
    const response = await this.vendorRepository.find({where: {mobile: mobile}});

    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: "User/vendor mobile no not found!",
        success: false
      }
    }

    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "Vendor is blocked!",
        success: false
      }
    }

    if (userExistence[0] === undefined) {
      const userData = {mobileNo: mobile, password: "ra@123456", RoleName: PermissionKeys.Mechanic, vendorId: response[0].id, firstName: response[0].name};
      userData.password = await this.hasher.hashPassword(userData.password);
      await this.userRepository.create(userData);
    } else {
      if (userExistence[0].isActive === false) {
        return {
          statusCode: 403,
          message: "Inactive user!",
          success: false
        }
      }
    }

    let OTP = '';
    for (let i = 0; i < NUM_CHARACTERS_IN_OTP; i++) {
      OTP += OTP_CHARACTERS[Math.floor(Math.random() * OTP_CHARACTERS.length)];
    }
    await this.smsLogRepository.create({
      mobile: mobile,
      otp: parseInt(OTP)
    });

    response[0].otp = parseInt(OTP);
    await this.vendorRepository.updateById(response[0].id, response[0]);

    return {
      statusCode: 200,
      message: "User/vendor found!",
      success: true,
      ...this.callSmsOTPAPI(mobile, parseInt(OTP))
    };
  }

  async callSmsOTPAPI(mobile: string, otp: number): Promise<any> {
    return this.smsService.sendOTP(mobile, otp);
  }


  @post('/mobile/vendor/login', {
    responses: {
      '200': {
        description: 'On successful verification',
        content: {
          'application/json': {
            schema: {
              "example": {
                "message": "OTP verified success",
                "type": "success",
                "deviceId": "some_device_id",
                "fcmToken": "fcmToken"
              }
            }
          }
        }
      }
    }
  })
  async verifyOTP(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'Vendor Login',
                properties: {
                  "mobile": {
                    "type": "string"
                  },
                  "otp": {
                    "type": "number"
                  },
                  "deviceId": {
                    "type": "string"
                  },
                  "fcmToken": {
                    "type": "string"
                  }
                },
                required: ["mobile", "otp", "deviceId", "fcmToken"],
                additiletlProperties: false
              }
            },
            "example": {
              "mobile": "919988776655",
              "otp": 12345,
              "deviceId": "some_device_id",
              "fcmToken": "fcmToken"
            }
          }
        }
      }
    }) data: verifyOtpInterface,
  ): Promise<any> {

    const tx = this.vendorRepository.dataSource.beginTransaction({
      isolationLevel: IsolationLevel.READ_COMMITTED,
    });

    // apply check for mobile number existence in vendor table first
    const userExistence = await this.userRepository.find({where: {mobileNo: data.mobile}}, {tx});
    const response = await this.vendorRepository.find({where: {mobile: data.mobile}}, {tx});

    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: "User/vendor mobile no not found!",
        success: false
      }
    }

    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "Vendor is blocked!",
        success: false
      }
    }

    if (userExistence[0] === undefined) {
      const userData = {mobileNo: data.mobile, password: "ra@123456", RoleName: PermissionKeys.Mechanic, vendorId: response[0].id, firstName: response[0].name};
      userData.password = await this.hasher.hashPassword(userData.password);
      await this.userRepository.create(userData);
    } else {
      if (userExistence[0].isActive === false) {
        return {
          statusCode: 403,
          message: "Inactive user!",
          success: false
        }
      }
    }

    const res = this.serviceOTPVerify(data.mobile, data.otp);
    const credentials = {mobileNo: data.mobile, password: 'ra@123456'};

    const returnRes: {success: Boolean, message: string, token: string} =
      {success: false, message: '', token: ''};

    await res.then(logRes => {
      if (!logRes) {
        returnRes.success = false;
        returnRes.message = "Sorry your OTP is wrong!";
        return returnRes;
      } else {
        returnRes.success = true
        returnRes.message = "You are Authorized!"

      }
    })

    if (returnRes.success) {
      const user = await this.userService.verifyCredentials(credentials);
      const userProfile = this.userService.convertToUserProfile(user);
      const token = await this.jwtService.generateToken(userProfile);
      returnRes.token = token;
    }

    if (data.deviceId !== response[0].deviceId || data.fcmToken !== response[0].fcmToken) {
      await this.vendorRepository.updateById(response[0].id, {deviceId: data.deviceId, fcmToken: data.fcmToken}, {tx});
    }

    await (await tx).commit();

    return returnRes;
  }

  async serviceOTPVerify(mobile: string, otp: number): Promise<boolean> {
    const smsLog = await this.smsLogRepository.find({where: {mobile: mobile}});
    const logOtp = smsLog[smsLog.length - 1].otp;
    if (logOtp === otp)
      return Promise.resolve(true);
    else
      return Promise.resolve(false);
  }

  // ToDo: create endpoint here after TTT
  async findMechcanicsNearOrderID(id: number): Promise<any> {
    if (!id) {
      return Promise.reject('Order not found');
    }
    const orderObject = await this.orderRepository.findById(id);
    // retrieve taskGeoPoint from the task itself, if it doesn't exist
    // then reject the promise else return proper resposne
    if (!orderObject.taskGeopoint) {
      return Promise.reject('Task location not found');
    }

    const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;
    const eligiblePolygons = await this.elasticQueries.findPolygonsWithPointInIt(tasklocation.lon, tasklocation.lat);
    const firstPolygon = eligiblePolygons[0];
    const polygon = turf.polygon(firstPolygon.coordinates);

    // ToDo: refactor this
    const config = {
      // firebase configuration
    };

    firebase.initializeApp(config);
    const firestore = firebase.firestore();
    const GeoFireStore = geofirestore.initializeApp(firestore);
    const geocollection = GeoFireStore.collection('vendor');
    return geocollection.get().then(async (values) => {
      let allRequiredMechancis = values.docs.map(doc => ({id: doc.id, lon: doc.data().gp.longitude, lat: doc.data().gp.latitude}))
        .filter(doc => turf.booleanPointInPolygon(turf.point([doc.lon, doc.lat]), polygon))
        .map(doc => ({id: doc.id, lon: doc.lon, lat: doc.lat, dist: turf.distance(turf.point([doc.lon, doc.lat]), turf.point([tasklocation.lon, tasklocation.lat]), {units: 'kilometers'})}));

      allRequiredMechancis = _.sortBy(allRequiredMechancis, 'dist',).reverse().slice(0, 5);
      const mechanicArray = allRequiredMechancis.map(ele => {
        return parseInt(ele.id);
      })
      const vendors = await this.vendorRepository.find({where: {id: {inq: mechanicArray}}})

      const response = [{}];
      function search(nameKey: any, myArray: any[]) {
        for (let i = 0; i < myArray.length; i++) {
          if (myArray[i].name === nameKey) {
            return myArray[i];
          }
        }
      }
      for (let i = 0; i < allRequiredMechancis.length; i++) {
        const res1 = await search(allRequiredMechancis[i].id, vendors)
        const res2 = {...allRequiredMechancis[i], ...res1}
        response.push(res2);
      }

      return Promise.resolve(response);
    }).catch((err) => {
      return Promise.reject(err);
    });
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @post('/mobile/vendor/logout', {
    responses: {
      '200': {
        description: 'This api is for logging out the mechanic and logging the time in the backend!',
      },
    },
  })
  async vendorLogOut(@requestBody() body: {}):
    Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const id = userProfile.vendorId;
    const vendor = await this.vendorRepository.findById(id);

    if (vendor) {
      await this.vendorRepository.updateById(id, {status: 4});
      return {
        statusCode: 200,
        vendorStatus: 4
      }
    }
    return {
      statusCode: 500,
      message: "Vendor Not found!"
    }
  }


  // body should be empty at the time of we calling this API
  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Mechanic]})
  @post('/vendor/findmyselfserveclients', {
    responses: {
      '200': {
        description: 'This API is for finding the self serve clients for which vendor is authorized to create orders',
      },
    },
  })
  async findMySelfServeClients(@requestBody() body: {}):
    Promise<any> {
    try {
      // const tx = await this.vendorSelfServeMappingRepository.beginTransaction({
      //   isolationLevel: IsolationLevel.READ_COMMITTED,
      // });
      const token = this.req.headers.authorization?.split(' ')[1];
      const userProfile = await this.jwtService.verifyToken(token!);
      const id = userProfile.vendorId;
      const vendor = await this.vendorRepository.findById(id);

      if (vendor && vendor.selfserve === true) {
        // await this.vendorRepository.updateById(id, {status: 4});
        const myClients = await this.vendorSelfServeMappingRepository.find({where: {vid: id, isActive: true}, fields: {cid: true}});
        const myClientsIdList: number[] = [];
        myClients.forEach((obj) => {
          myClientsIdList.push(obj.cid);
        });
        const clients = await this.clientMasterRepository.find({where: {id: {inq: myClientsIdList}}, fields: {id: true, name: true}});
        return {
          statusCode: 200,
          body: clients
        };
      }
      return {
        statusCode: 500,
        message: "Self serve not available!"
      };
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      };
    }
  }

  // body should be empty at the time of we calling this API
  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Mechanic]})
  @post('/mobile/vendor/findmyselfserveclients', {
    responses: {
      '200': {
        description: 'This API is for finding the self serve clients for which vendor is authorized to create orders',
      },
    },
  })
  async mobileFindMySelfServeClients(@requestBody() body: {}):
    Promise<any> {
    try {
      // const tx = await this.vendorSelfServeMappingRepository.beginTransaction({
      //   isolationLevel: IsolationLevel.READ_COMMITTED,
      // });
      const token = this.req.headers.authorization?.split(' ')[1];
      const userProfile = await this.jwtService.verifyToken(token!);
      const id = userProfile.vendorId;
      const vendor = await this.vendorRepository.findById(id);

      if (vendor && vendor.selfserve === true) {
        // await this.vendorRepository.updateById(id, {status: 4});
        const myClients = await this.vendorSelfServeMappingRepository.find({where: {vid: id, isActive: true}, fields: {cid: true}});
        const myClientsIdList: number[] = [];
        myClients.forEach((obj) => {
          myClientsIdList.push(obj.cid);
        });
        const clients = await this.clientMasterRepository.find({where: {id: {inq: myClientsIdList}}, fields: {id: true, name: true}});
        return {
          statusCode: 200,
          body: clients
        };
      }
      return {
        statusCode: 500,
        message: "Self serve not available!"
      };
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      };
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Mechanic]})
  @post('/mobile/vendor/createmyorder', {
    responses: {
      '200': {
        description: 'Order model instance',
        content: {'application/json': {schema: getModelSchemaRef(Order)}}
      }
    }
  })
  async mobileCreateMyOrderSelfServe(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Order, {
            title: 'NewOrder',
            exclude: ['id']
          })
        }
      }
    })
    order: Omit<Order, 'id'>
  ): Promise<Order> {
    const tx: Transaction = await this.orderRepository.beginTransaction({
      isolationLevel: IsolationLevel.READ_COMMITTED,
      timeout: OrderTransactionTimeInms,
    });

    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const vid = userProfile.vendorId;
    const vendorObject = await this.vendorRepository.findById(vid);

    order.vehicleIdentificationNumber = order.vehicleIdentificationNumber.split(" ").join("");
    order.createdAt = new Date().toString();
    order.updatedAt = new Date().toString();
    const orderCreated = await this.orderRepository.create(order, {transaction: tx});
    const existingCustomer = await this.customerRepository.findOne({where: {mobileNo: order.custPhoneNumber}}, {transaction: tx});
    if (!existingCustomer) {
      await this.customerRepository.create({name: order.custName, mobileNo: order.custPhoneNumber, email: order.custEmail}, {transaction: tx});
    }

    await this.orderHistoryRepository.create({
      orderId: orderCreated.getId(),
      orderJson: order,
      actionPerformed: 'CREATE',
      changedBy: userProfile
    }, {transaction: tx});

    const obj: InvoiceServiceId = {};
    obj[orderCreated.serviceId] = 1;
    const serviceMasterRes = await this.serviceMasterRepository.findById(order.serviceId);

    const dt = moment(order.bookingTime!).utcOffset("+05:30");
    const hr = dt.hour();

    let amountForService = 0;
    if (hr >= 20 || hr < 8) {
      if (serviceMasterRes.nightCharge > 0) {
        amountForService = serviceMasterRes.nightCharge * (1 + serviceMasterRes.tax / 100);
      }
    } else {
      amountForService = serviceMasterRes.dayCharge * (1 + serviceMasterRes.tax / 100);
    }
    // as of now just add entire service object
    const serviceObj = await this.serviceMasterRepository.findById(orderCreated.serviceId);
    obj[orderCreated.serviceId] = {service: serviceObj, quantity: 1};
    // Todo: Modify to check if the invoice already exists then don't create it.
    const invoiceCreated = await this.invoiceRepository.create({
      orderId: orderCreated.getId(),
      services: [obj],
      amount: amountForService,
      due: amountForService,
      paid: 0,
      adhocServices: []
    }, {transaction: tx});
    orderCreated.invoiceId = invoiceCreated.getId();
    await this.orderRepository.updateById(orderCreated.getId(), orderCreated, {transaction: tx});
    const vehicleExists = await this.registeredVehicleRepository.findOne({where: {registrationNumber: orderCreated.vehicleIdentificationNumber.toUpperCase().trim().split(" ").join("")}}, {transaction: tx});
    if (!vehicleExists) {
      await this.registeredVehicleRepository.create({registrationNumber: orderCreated.vehicleIdentificationNumber.toUpperCase().trim().split(" ").join(""), vehicleId: orderCreated.vehicleId, orderId: orderCreated.id}, {transaction: tx});
    }

    // assign the order to technician that created it.

    let orderDetails: any = {};
    const currentTimeStamp = new Date().toString();
    orderDetails.createdAt = currentTimeStamp;
    orderDetails.updatedAt = currentTimeStamp;
    orderDetails.vendorId = userProfile.vendorId;
    orderDetails.assignmentTime = currentTimeStamp;
    orderDetails.orderId = orderCreated.id;

    const ordDetails: OrderDetails = await this.orderDetailsRepository.create(orderDetails, {transaction: tx});
    // keep it a separate statement only.
    if (ordDetails.vendorId) {
      await this.orderRepository.updateById(ordDetails.orderId, {status: 2}, {transaction: tx});
    }
    await tx.commit();
    const msg: Object = {
      notification: {
        title: "Readyassist NEW ORDER!",
        body: "#" + ordDetails.orderId + " assigned to you!",
        sound: 'default'
      }
    };
    const options: Object = {
      priority: 'high',
    };
    if (vendorObject.fcmToken) {
      await sendPushNotificationToMechanic(vendorObject.fcmToken, msg, options);
    }
    return orderCreated;
  }

  // Get vendor shift time
  @get('/vendor/calculateShiftTime', {
    responses: {
      '200': {
        description: 'This API is for get shift time of venders and calculate working hours',
      },
    },
  })
  async calculateShiftTime():
    Promise<any> {
    try {
      // console.log("Calculating shift time")
      const sql = `select V.id as v_id,S.* from Vendor V JOIN Shift S on V.shiftId = S.id`

      const vendorData: any = await this.vendorRepository.dataSource.execute(sql)

      let data: any = [];
      // vendorData.forEach((dd : any) => {
      //   data.push(dd)
      // })

      for (var s = 0; s < vendorData.length; s++) {
        console.log("dd---", vendorData[s])
        vendorData[s].busy_hour = 0
        vendorData[s].onDuty_hour = 0
        vendorData[s].notOnDuty_hour = 0
        vendorData[s].checkIn = '';
        vendorData[s].checkOut = '';
        data.push(vendorData[s])
      }

      // console.log("Data:-0---", data[0])
      // console.log("id---",data[0].v_id)
      // console.log("Type-of---",typeof(data[0].v_id))
      // db.collection('vendor_history').doc(String(data[0].v_id)).listCollections().then((myList) => {
      //   console.log("My List---",myList)
      // }).catch((error) => {
      //   console.log("Error---",error)
      // })

      // db.collection('vendor_history').get().then(res => {
      //   console.log("Res---",res)
      // })

      for (var i = 0; i < data.length; i++) {
        // console.log("Data:--",data[i].v_id)
        let vendorsHistory: any = []
        vendorsHistory = await this.vendorHistory(String(data[i].v_id))
        // console.log("Vendors-History----",vendorsHistory.length);
        if (vendorsHistory.length == 0) {
          console.log("My List Not Found")
        } else {
          for (var j = 0; j < vendorsHistory.length; j++) {
            let perDayData: any = await this.subVendorHistory(String(data[i].v_id), vendorsHistory[j].id)
            let Busy = 0
            let OnDuty = 0
            let NotOnDuty = 0

            if (perDayData.length == 0) {
              // console.log("Per-Day not Found")
            } else {
              for (var k = 0; k < perDayData.length; k++) {
                if (k !== 0) {
                  let fromDate = moment.utc(perDayData[k - 1].ts.toDate()).local().format()
                  let toDate = moment.utc(perDayData[k].ts.toDate()).local().format()

                  if (perDayData[k].vs.toUpperCase() == 'NOT ON DUTY') {
                    NotOnDuty += moment(toDate).diff(moment(fromDate), 'hours', true)
                  }

                  if (perDayData[k].vs.toUpperCase() == 'BUSY') {
                    Busy += moment(toDate).diff(moment(fromDate), 'hours', true)
                  }

                  if (perDayData[k].vs.toUpperCase() == 'ON DUTY') {
                    OnDuty += moment(toDate).diff(moment(fromDate), 'hours', true)
                  }
                }
              }
            }

            data[i].busy_hour = Busy.toFixed(2);
            data[i].onDuty_hour = OnDuty.toFixed(2);
            if(data[i].startTime){
              // console.log("check in ----",i,moment.utc(data[i].startTime).local().format("hh:mm:ss a"));
              data[i].checkIn = moment(data[i].startTime).format("hh:mm:ss a");
            }
            data[i].notOnDuty_hour = NotOnDuty.toFixed(2);
            if(data[i].endTime){
              // console.log("check out ----",i,moment.utc(data[i].endTime).local().format("hh:mm:ss a"));
              data[i].checkOut = moment(data[i].endTime).format("hh:mm:ss a");
            }
            // console.log("Data--i---",data[i])
          }
        }
      }
      // console.log("Data---",data)
      return data;
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      };
    }
  }

  async vendorHistory(id: any) {
    return new Promise((resolve) => {
      db.collection('vendor_history').doc(id).listCollections().then((myList) => {
        resolve(myList)
      }).catch(null)
    })
  }

  async subVendorHistory(id: any, collection: any) {
    return new Promise((resolve) => {
      db.collection(`vendor_history/${id}/${collection}/`).orderBy('ts').get().then((vh) => {
        let allData: any = []
        vh.forEach(vhdoc => {
          let vhdata = vhdoc.data();
          allData.push(vhdata)
        })
        resolve(allData)
      }).catch(null)
    })
  }
}
