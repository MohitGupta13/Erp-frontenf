import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {
  AggregatorServiceList
} from '../models';
import {
  AggregatorServiceListRepository
} from '../repositories';

export class AggregatorServiceListController {
  constructor(
    @repository(AggregatorServiceListRepository) public aggregatorServiceListRepository: AggregatorServiceListRepository,
  ) {}

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/aggregator-service-lists', {
    responses: {
      '200': {
        description: 'AggregatorServiceList model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(AggregatorServiceList)
          }
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AggregatorServiceList, {
            title: 'NewAggregatorServiceList',
            exclude: ['id'],
          }),
        },
      },
    }) aggregatorServiceList: Omit<AggregatorServiceList, 'id'>,
  ): Promise<AggregatorServiceList> {
    return this.aggregatorServiceListRepository.create(aggregatorServiceList);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/aggregator-service-lists/count', {
    responses: {
      '200': {
        description: 'AggregatorServiceList model count',
        content: {
          'application/json': {
            schema: CountSchema
          }
        },
      },
    },
  })
  async count(
    @param.where(AggregatorServiceList) where?: Where<AggregatorServiceList>,
  ): Promise<Count> {
    return this.aggregatorServiceListRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/aggregator-service-lists', {
    responses: {
      '200': {
        description: 'Array of AggregatorServiceList model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(AggregatorServiceList, {
                includeRelations: true
              }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(AggregatorServiceList) filter?: Filter<AggregatorServiceList>,
  ): Promise<AggregatorServiceList[]> {
    return this.aggregatorServiceListRepository.find(filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/mobile/aggregator-service-lists', {
    responses: {
      '200': {
        description: 'Array of AggregatorServiceList model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(AggregatorServiceList, {
                includeRelations: true
              }),
            },
          },
        },
      },
    },
  })
  async findMobile(
    @param.filter(AggregatorServiceList) filter?: Filter<AggregatorServiceList>,
  ): Promise<unknown> {

    try {
      const aggregatorServiceList = await this.aggregatorServiceListRepository.find(filter);
      return {
        statusCode: 200,
        data: aggregatorServiceList
      }
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      }
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/aggregator-service-lists', {
    responses: {
      '200': {
        description: 'AggregatorServiceList PATCH success count',
        content: {
          'application/json': {
            schema: CountSchema
          }
        },
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AggregatorServiceList, {
            partial: true
          }),
        },
      },
    }) aggregatorServiceList: AggregatorServiceList,
    @param.where(AggregatorServiceList) where?: Where<AggregatorServiceList>,
  ): Promise<Count> {
    return this.aggregatorServiceListRepository.updateAll(aggregatorServiceList, where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/aggregator-service-lists/{id}', {
    responses: {
      '200': {
        description: 'AggregatorServiceList model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(AggregatorServiceList, {
              includeRelations: true
            }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(AggregatorServiceList, {
      exclude: 'where'
    }) filter?: FilterExcludingWhere<AggregatorServiceList>
  ): Promise<AggregatorServiceList> {
    return this.aggregatorServiceListRepository.findById(id, filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/aggregator-service-lists/{id}', {
    responses: {
      '204': {
        description: 'AggregatorServiceList PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(AggregatorServiceList, {
            partial: true
          }),
        },
      },
    }) aggregatorServiceList: AggregatorServiceList,
  ): Promise<void> {
    await this.aggregatorServiceListRepository.updateById(id, aggregatorServiceList);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/aggregator-service-lists/{id}', {
    responses: {
      '204': {
        description: 'AggregatorServiceList PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() aggregatorServiceList: AggregatorServiceList,
  ): Promise<void> {
    await this.aggregatorServiceListRepository.replaceById(id, aggregatorServiceList);
  }
  // @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  // @del('/aggregator-service-lists/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'AggregatorServiceList DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.aggregatorServiceListRepository.deleteById(id);
  // }
}
