// Uncomment these imports to begin using these cool features!

// import {inject} from '@loopback/context';


import {inject} from "@loopback/context";
import {repository} from "@loopback/repository";
import {get, param, post, requestBody} from "@loopback/rest";
import {NUM_CHARACTERS_IN_OTP, OTP_CHARACTERS} from "../constants";
import {SmsLogRepository} from "../repositories";
import {Smsotp} from "../services";


interface verifyOtpInterface {
    mobile: string;
    otp: number;
}

export class SmsOtpController {
    constructor(
        @inject('services.Smsotp') protected smsService: Smsotp,
        @repository(SmsLogRepository) public smsLogRepository: SmsLogRepository,
    ) {
    }


    @get('/sendotp/{mobile}')
    async sendOTP(
        @param.path.string('mobile') mobile: string
    ): Promise<any> {
        let OTP = '';
        for (let i = 0; i < NUM_CHARACTERS_IN_OTP; i++) {
            OTP += OTP_CHARACTERS[Math.floor(Math.random() * OTP_CHARACTERS.length)];
        }
        await this.smsLogRepository.create({
            mobile: mobile,
            otp: parseInt(OTP)
        });
        return this.callSmsOTPAPI(mobile, parseInt(OTP));
    }

    async callSmsOTPAPI(mobile: string, otp: number): Promise<any> {
        return this.smsService.sendOTP(mobile, otp);
    }


    @post('/resendotp/{mobile}')
    async resendOTP(
        @param.path.string('mobile') mobile: string
    ): Promise<any> {
        return this.callSmsResendOTPAPI(mobile);
    }

    async callSmsResendOTPAPI(mobile: string): Promise<any> {
        return this.smsService.resendOTP(mobile);
    }


    @post('/verifyotp', {
        responses: {
            '200': {
                description: 'On successful verification',
                content: {
                    'application/json': {
                        schema: {
                            "example": {
                                "message": "OTP verified success",
                                "type": "success"
                            }
                        }
                    }
                }
            }
        }
    })
    async verifyOTP(
        @requestBody({
            content: {
                'application/json': {
                    schema: {
                        definitions: {
                            VerifyOTP: {
                                title: 'VerifyOTP',
                                properties: {
                                    "mobile": {
                                        "type": "string"
                                    },
                                    "otp": {
                                        "type": "number"
                                    }
                                },
                                required: ["mobile", "otp"],
                                additionalProperties: false
                            }
                        },
                        "example": {
                            "mobile": "919988776655",
                            "otp": 12345
                        }
                    }
                }
            }
        }) data: verifyOtpInterface,
    ): Promise<any> {
        return this.callSmsVerifyOTPAPI(data.mobile, data.otp);
    }

    async callSmsVerifyOTPAPI(mobile: string, otp: number): Promise<any> {
        return this.smsService.verifyOTP(mobile, otp);
    }
}
