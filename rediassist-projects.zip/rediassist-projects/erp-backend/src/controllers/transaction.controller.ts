import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Transaction} from '../models';
import {InvoiceRepository, PaymentTypesRepository, TransactionRepository} from '../repositories';

export class TransactionController {
	constructor(
		@repository(TransactionRepository) public transactionRepository: TransactionRepository,
		@inject('repositories.InvoiceRepository') public invoiceRepository: InvoiceRepository,
		@inject('repositories.PaymentTypesRepository') public paymentRepository: PaymentTypesRepository
	) {}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
	@post('/transactions', {
		responses: {
			'200': {
				description: 'Transaction model instance',
				content: {'application/json': {schema: getModelSchemaRef(Transaction)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Transaction, {
						title: 'NewTransaction',
						exclude: ['id']
					})
				}
			}
		})
		transaction: Omit<Transaction, 'id'>
	){

		const paymentType = await this.paymentRepository.find({where:{method:transaction.mode},fields:{transactionIdReq:true}})

		if((paymentType[0].transactionIdReq) && !transaction.transactionRefNo){

				return {
					statusCode: 412,
					message: "Transaction reference no not found.!",
					success: false
				}

		}

		const invoiceData = await this.invoiceRepository.findById(transaction.invoiceId);
		invoiceData.paid += transaction.paid;
		invoiceData.due = invoiceData.amount - invoiceData.paid;
		await this.invoiceRepository.replaceById(transaction.invoiceId, invoiceData);
		return this.transactionRepository.create(transaction);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/transactions/count', {
		responses: {
			'200': {
				description: 'Transaction model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(Transaction) where?: Where<Transaction>): Promise<Count> {
		return this.transactionRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/transactions', {
		responses: {
			'200': {
				description: 'Array of Transaction model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(Transaction, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(Transaction) filter?: Filter<Transaction>): Promise<Transaction[]> {
		return this.transactionRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/transactions', {
		responses: {
			'200': {
				description: 'Transaction PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Transaction, {partial: true})
				}
			}
		})
		transaction: Transaction,
		@param.where(Transaction) where?: Where<Transaction>
	): Promise<Count> {
		return this.transactionRepository.updateAll(transaction, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/transactions/{id}', {
		responses: {
			'200': {
				description: 'Transaction model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Transaction, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(Transaction, {exclude: 'where'})
		filter?: FilterExcludingWhere<Transaction>
	): Promise<Transaction> {
		return this.transactionRepository.findById(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/transactions/{id}', {
		responses: {
			'204': {
				description: 'Transaction PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Transaction, {partial: true})
				}
			}
		})
		transaction: Transaction
	): Promise<void> {
		await this.transactionRepository.updateById(id, transaction);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/transactions/{id}', {
		responses: {
			'204': {
				description: 'Transaction PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() transaction: Transaction): Promise<void> {
		await this.transactionRepository.replaceById(id, transaction);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@del('/transactions/{id}', {
		responses: {
			'204': {
				description: 'Transaction DELETE success'
			}
		}
	})
	async deleteById(@param.path.number('id') id: number): Promise<void> {
		await this.transactionRepository.deleteById(id);
	}
}
