import {repository} from '@loopback/repository';
import {VendorEventsRepository} from '../repositories';

interface myStatus {
  status: string
};

export class VendorEventController {
  constructor(
    @repository(VendorEventsRepository)
    public vendorEventsRepository: VendorEventsRepository,
  ) { }

  // @post('/vendor-events', {
  //   responses: {
  //     '200': {
  //       description: 'VendorEvents model instance',
  //       content: {'application/json': {schema: getModelSchemaRef(VendorEvents)}},
  //     },
  //   },
  // })
  // async create(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(VendorEvents, {
  //           title: 'NewVendorEvents',
  //           exclude: ['id'],
  //         }),
  //       },
  //     },
  //   })
  //   vendorEvents: Omit<VendorEvents, 'id'>,
  // ): Promise<VendorEvents> {
  //   return this.vendorEventsRepository.create(vendorEvents);
  // }

  // @get('/vendor-events/count', {
  //   responses: {
  //     '200': {
  //       description: 'VendorEvents model count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async count(
  //   @param.where(VendorEvents) where?: Where<VendorEvents>,
  // ): Promise<Count> {
  //   return this.vendorEventsRepository.count(where);
  // }

  // @get('/vendor-events', {
  //   responses: {
  //     '200': {
  //       description: 'Array of VendorEvents model instances',
  //       content: {
  //         'application/json': {
  //           schema: {
  //             type: 'array',
  //             items: getModelSchemaRef(VendorEvents, {includeRelations: true}),
  //           },
  //         },
  //       },
  //     },
  //   },
  // })
  // async find(
  //   @param.filter(VendorEvents) filter?: Filter<VendorEvents>,
  // ): Promise<VendorEvents[]> {
  //   return this.vendorEventsRepository.find(filter);
  // }

  // @patch('/vendor-events', {
  //   responses: {
  //     '200': {
  //       description: 'VendorEvents PATCH success count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(VendorEvents, {partial: true}),
  //       },
  //     },
  //   })
  //   vendorEvents: VendorEvents,
  //   @param.where(VendorEvents) where?: Where<VendorEvents>,
  // ): Promise<Count> {
  //   return this.vendorEventsRepository.updateAll(vendorEvents, where);
  // }

  // @get('/vendor-events/{id}', {
  //   responses: {
  //     '200': {
  //       description: 'VendorEvents model instance',
  //       content: {
  //         'application/json': {
  //           schema: getModelSchemaRef(VendorEvents, {includeRelations: true}),
  //         },
  //       },
  //     },
  //   },
  // })
  // async findById(
  //   @param.path.number('id') id: number,
  //   @param.filter(VendorEvents, {exclude: 'where'}) filter?: FilterExcludingWhere<VendorEvents>
  // ): Promise<VendorEvents> {
  //   return this.vendorEventsRepository.findById(id, filter);
  // }

  // @patch('/vendor-events/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'VendorEvents PATCH success',
  //     },
  //   },
  // })
  // async updateById(
  //   @param.path.number('id') id: number,
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(VendorEvents, {partial: true}),
  //       },
  //     },
  //   })
  //   vendorEvents: VendorEvents,
  // ): Promise<void> {
  //   await this.vendorEventsRepository.updateById(id, vendorEvents);
  // }

  // @put('/vendor-events/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'VendorEvents PUT success',
  //     },
  //   },
  // })
  // async replaceById(
  //   @param.path.number('id') id: number,
  //   @requestBody() vendorEvents: VendorEvents,
  // ): Promise<void> {
  //   await this.vendorEventsRepository.replaceById(id, vendorEvents);
  // }

  // @del('/vendor-events/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'VendorEvents DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.vendorEventsRepository.deleteById(id);
  // }
}
