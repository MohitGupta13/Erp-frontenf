import '@firebase/firestore';
import {authenticate} from '@loopback/authentication';
import {UserRepository} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {IsolationLevel, repository} from '@loopback/repository';
import {
  getModelSchemaRef,
  post,
  requestBody
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, NUM_CHARACTERS_IN_OTP, OTP_CHARACTERS} from '../constants';
import {PasswordHasherBindings, TokenServiceBindings, UserServiceBindings} from '../keys';
import {QualityUser} from '../models';
import {QualityUserRepository, SmsLogRepository} from '../repositories';
import {Smsotp} from '../services';
import {BcryptHasher} from '../services/hash.password';
import {JWTService} from '../services/jwt-service';
import {MyUserService} from '../services/user-service';
import {ElasticqueriesController} from './elasticqueries.controller';

interface mobileExists {
  mobile: string;
}

interface verifyOtpInterface {
  mobile: string;
  otp: number;
}

export class QualityUserController {
  constructor(
    @repository(QualityUserRepository) public QualityUserRepository: QualityUserRepository,
    @inject('repositories.SmsLogRepository') public smsLogRepository: SmsLogRepository,
    @inject('services.Smsotp') protected smsService: Smsotp,
    @inject('repositories.UserRepository') public userRepository: UserRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER) public hasher: BcryptHasher,
    @inject(UserServiceBindings.USER_SERVICE) public userService: MyUserService,
    @inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: JWTService,
    @inject('controllers.ElasticqueriesController') public elasticQueries: ElasticqueriesController,

  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/qualityUser', {
    responses: {
      '200': {
        description: 'quality user model instance',
        content: {'application/json': {schema: getModelSchemaRef(QualityUser)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(QualityUser, {
            title: 'NewQualityUser',
            exclude: ['id'],
          }),
        },
      },
    })
    qualityUser: Omit<QualityUser, 'id'>,
  ): Promise<QualityUser> {
    return this.QualityUserRepository.create(qualityUser);
  }

  // ==== mobile no exist ====
  @post('/mobile/qualityUser/existence/', {
    responses: {
      '204': {
        description: 'Mobile Number verification',
      },
      '200': {
        description: 'Mobile Number found!',
      },
      '404': {
        description: 'Mobile number not found',
      }
    },
  })
  async findByMobileBody(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'quality user phone exists?',
                properties: {
                  "mobile": {
                    "type": "string"
                  }
                },
                required: ["mobile"],
                additionalProperties: false
              }
            },
            "example": {
              "mobile": "919988776655"
            }
          }
        }
      }
    }) data: mobileExists
  ) {
    const mobile = data.mobile
    return this.qualityUserExistenceHelper(mobile);
  }

  async qualityUserExistenceHelper(mobile: string) {

    // apply check for mobile number existence in quality user table first
    const response = await this.QualityUserRepository.find({
      where: {
        mobileNo: mobile
      }
    });

    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: 'User/quality user mobile no not found!',
        success: false
      }
    }
    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "quality user is blocked!",
        success: false
      }
    }

    let OTP = '';
    for (let i = 0; i < NUM_CHARACTERS_IN_OTP; i++) {
      OTP += OTP_CHARACTERS[Math.floor(Math.random() * OTP_CHARACTERS.length)];
    }
    await this.smsLogRepository.create({
      mobile: mobile,
      otp: parseInt(OTP)
    });
    response[0].otp = parseInt(OTP);
    await this.QualityUserRepository.updateById(response[0].id, response[0]);
    return {
      statusCode: 200,
      message: "User/quality user found!",
      success: true,
      ...this.callSmsOTPAPI(mobile, parseInt(OTP))
    };
  }

  async callSmsOTPAPI(mobile: string, otp: number): Promise<any> {
    return this.smsService.sendOTP(mobile, otp);
  }

  // ==== quality user login by otp verify ===

  @post('/mobile/qualityUser/login', {
    responses: {
      '200': {
        description: 'On successful verification',
        content: {
          'application/json': {
            schema: {
              "example": {
                "message": "OTP verified success",
                "type": "success"
              }
            }
          }
        }
      }
    }
  })
  async verifyOTP(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'Quality User Login',
                properties: {
                  "mobile": {
                    "type": "string"
                  },
                  "otp": {
                    "type": "number"
                  }
                },
                required: ["mobile", "otp"],
                additiletlProperties: false
              }
            },
            "example": {
              "mobile": "919988776655",
              "otp": 12345
            }
          }
        }
      }
    }) data: verifyOtpInterface,
  ): Promise<any> {
    const tx = this.QualityUserRepository.dataSource.beginTransaction({
      isolationLevel: IsolationLevel.READ_COMMITTED,
    });

    // apply check for mobile number existence in quality user table first and user table
    const userExistence = await this.userRepository.find({
      where: {
        mobileNo: data.mobile
      }
    }, {
      tx
    });
    const response = await this.QualityUserRepository.find({
      where: {
        mobileNo: data.mobile
      }
    }, {
      tx
    });
    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: "User/quality user mobile no not found!",
        success: false
      }
    }

    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "quality user is blocked!",
        success: false
      }
    }

    if (userExistence[0] === undefined) {
      const userData = {
        mobileNo: data.mobile,
        password: "ra@123456",
        RoleName: PermissionKeys.QualityUser
      };
      userData.password = await this.hasher.hashPassword(userData.password);
      let crt = await this.userRepository.create(userData);
    } else {
      if (userExistence[0].isActive === false) {
        return {
          statusCode: 403,
          message: "Inactive user!",
          success: false
        }
      }
    }

    const res = this.serviceOTPVerify(data.mobile, data.otp);
    const credentials = {
      mobileNo: data.mobile,
      password: 'ra@123456'
    };

    const returnRes: {
      success: Boolean,
      message: string,
      token: string
    } = {
      success: false,
      message: '',
      token: ''
    };

    await res.then(logRes => {
      if (!logRes) {
        returnRes.success = false;
        returnRes.message = "Sorry your OTP is wrong!";
        return returnRes;
      } else {
        returnRes.success = true
        returnRes.message = "You are Authorized!"

      }
    })

    if (returnRes.success) {
      const user = await this.userService.verifyCredentials(credentials);
      const userProfile = this.userService.convertToUserProfile(user);
      const token = await this.jwtService.generateToken(userProfile);
      returnRes.token = token;
    }
    await (await tx).commit();

    return returnRes;
  }

  async serviceOTPVerify(mobile: string, otp: number): Promise<boolean> {
    const smsLog = await this.smsLogRepository.find({
      where: {
        mobile: mobile
      }
    });
    const logOtp = smsLog[smsLog.length - 1].otp;
    if (logOtp === otp)
      return Promise.resolve(true);
    else
      return Promise.resolve(false);
  }
}
