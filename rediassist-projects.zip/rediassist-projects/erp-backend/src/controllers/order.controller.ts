import {authenticate} from '@loopback/authentication';
import {JWTService} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {Count, CountSchema, Filter, FilterExcludingWhere, IsolationLevel, repository, Transaction, Where} from '@loopback/repository';
import {get, getModelSchemaRef, param, patch, post, put, Request, requestBody, RestBindings} from '@loopback/rest';
import {UserProfile} from '@loopback/security';
import * as turf from '@turf/turf';
import * as firebase from 'firebase';
import * as geofirestore from 'geofirestore';
import moment from 'moment';
import _ from 'underscore';
import util from "util";
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, InvoiceServiceId, OrderTransactionTimeInms, VendorRadialDistance} from '../constants';
import {TokenServiceBindings} from '../keys';
import {Order, OrderDetails, User, Vendor} from '../models';
import {sendPushNotificationToMechanic} from '../notifications';
import * as serviceAccount from '../ra-prod-mechapp.json';
import {CustomerRepository, InvoiceRepository, OrderDetailsRepository, OrderhistoryRepository, OrderRepository, RegisteredVehicleRepository, ServiceMasterRepository, UserRepository, VehicleMasterRepository, VendorRepository} from '../repositories';
import {Smsotp} from "../services";
import {makeProperPhoneNumber} from '../services/validator.service';
import {ElasticqueriesController} from './elasticqueries.controller';
const GoogleDistanceApi = require('google-distance-api');
interface ItaskGeoPoint {
	lng: number;
	lat: number;
}

export class OrderController {
	constructor(
		@inject('services.Smsotp') protected smsService: Smsotp,
		@repository(OrderRepository) public orderRepository: OrderRepository,
		@inject('repositories.OrderhistoryRepository') public orderHistoryRepository: OrderhistoryRepository,
		@inject('repositories.InvoiceRepository') public invoiceRepository: InvoiceRepository,
		@inject('repositories.ServiceMasterRepository') public serviceMasterRepository: ServiceMasterRepository,
		@inject('repositories.CustomerRepository') public customerRepository: CustomerRepository,
		@inject('repositories.UserRepository') public userRepository: UserRepository,
		@inject('repositories.OrderDetailsRepository') public orderDetailsRepository: OrderDetailsRepository,
		@inject('repositories.VendorRepository') public vendorRepository: VendorRepository,
		@inject('repositories.RegisteredVehicleRepository') public registeredVehicleRepository: RegisteredVehicleRepository,
		@inject('repositories.VehicleMasterRepository') public vehicleMasterRepository: VehicleMasterRepository,
		@inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: JWTService,
		@inject(RestBindings.Http.REQUEST) private req: Request,
		@inject('controllers.ElasticqueriesController') public elasticQueries: ElasticqueriesController,
	) {
		this.orderHistoryRepository = orderHistoryRepository;
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer, PermissionKeys.Mechanic]})
	@post('/orders', {
		responses: {
			'200': {
				description: 'Order model instance',
				content: {'application/json': {schema: getModelSchemaRef(Order)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Order, {
						title: 'NewOrder',
						exclude: ['id']
					})
				}
			}
		})
		order: Omit<Order, 'id'>
	): Promise<Order> {
		const tx: Transaction = await this.orderRepository.beginTransaction({
			isolationLevel: IsolationLevel.READ_COMMITTED,
			timeout: OrderTransactionTimeInms,
		});
		//remove all the spaces
		order.vehicleIdentificationNumber = order.vehicleIdentificationNumber.split(" ").join("");
		order.createdAt = new Date().toString();
		order.updatedAt = new Date().toString();
		const orderCreated = await this.orderRepository.create(order, {transaction: tx});
		const existingCustomer = await this.customerRepository.findOne({where: {mobileNo: order.custPhoneNumber}}, {transaction: tx});
		if (!existingCustomer) {
			await this.customerRepository.create({name: order.custName, mobileNo: order.custPhoneNumber, email: order.custEmail}, {transaction: tx});
		}
		const token = this.req.headers.authorization?.split(' ')[1];
		const userProfile = await this.jwtService.verifyToken(token!);
		await this.orderHistoryRepository.create({
			orderId: orderCreated.getId(),
			orderJson: order,
			actionPerformed: 'CREATE',
			changedBy: userProfile
		}, {transaction: tx});

		const obj: InvoiceServiceId = {};
		obj[orderCreated.serviceId] = 1;
		const serviceMasterRes = await this.serviceMasterRepository.findById(order.serviceId);

		const dt = moment(order.bookingTime!).utcOffset("+05:30");
		const hr = dt.hour();

		let amountForService = 0;
		if (hr >= 20 || hr < 8) {
			if (serviceMasterRes.nightCharge > 0) {
				amountForService = serviceMasterRes.nightCharge * (1 + serviceMasterRes.tax / 100);
			}
		} else {
			amountForService = serviceMasterRes.dayCharge * (1 + serviceMasterRes.tax / 100);
		}
		// as of now just add entire service object
		const serviceObj = await this.serviceMasterRepository.findById(orderCreated.serviceId);
		obj[orderCreated.serviceId] = {service: serviceObj, quantity: 1};
		// Todo: Modify to check if the invoice already exists then don't create it.
		const invoiceCreated = await this.invoiceRepository.create({
			orderId: orderCreated.getId(),
			services: [obj],
			amount: amountForService,
			due: amountForService,
			paid: 0,
			adhocServices: []
		});
		orderCreated.invoiceId = invoiceCreated.getId();
		await this.orderRepository.updateById(orderCreated.getId(), orderCreated, {transaction: tx});
		const vehicleExists = await this.registeredVehicleRepository.findOne({where: {registrationNumber: orderCreated.vehicleIdentificationNumber.toUpperCase().trim().split(" ").join("")}}, {transaction: tx});
		if (!vehicleExists) {
			await this.registeredVehicleRepository.create({registrationNumber: orderCreated.vehicleIdentificationNumber.toUpperCase().trim().split(" ").join(""), vehicleId: orderCreated.vehicleId, orderId: orderCreated.id}, {transaction: tx});
		}
		await tx.commit();

		if (userProfile.RoleName == 'Mechanic' || userProfile.vendorId) {
			const tx = await this.orderDetailsRepository.dataSource.beginTransaction({
				isolationLevel: IsolationLevel.READ_COMMITTED,
				timeout: OrderTransactionTimeInms,
			});
			// first check if the mechanic is not blocked or if actually on duty
			const mechanicDetails: Vendor = await this.vendorRepository.findById(userProfile.vendorId);
			let ordDetailrequest = {
				orderId: orderCreated.id,
				vendorId: userProfile.vendorId,
				customerRating: 0,
				internalRating: 0,
				isActive: true
			}

			const ordDetails: OrderDetails = await this.orderDetailsRepository.create(ordDetailrequest, {tx});
			const originalOrder: Order = await this.orderRepository.findById(orderCreated.id);
			await this.orderHistoryRepository.create({
				orderId: originalOrder.id,
				orderJson: originalOrder,
				actionPerformed: 'ASSIGNED',
				location: '',                   // as of now the system is not capable of capturing order assignment location
				changedBy: userProfile,
			}, {tx});
			await this.orderRepository.updateById(ordDetails.orderId, {status: 2}, {tx});
			const msg: Object = {
				notification: {
					title: "Readyassist NEW ORDER!",
					body: "#" + ordDetails.orderId + " assigned to you!",
					sound: 'default'
				}
			};
			const options: Object = {
				priority: 'high',
			};
			await tx.commit();
			if (mechanicDetails.fcmToken) {
				await sendPushNotificationToMechanic(mechanicDetails.fcmToken, msg, options);
			}
			return orderCreated;
		}
		else {
			return orderCreated;
		}
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
	@get('/orders/count', {
		responses: {
			'200': {
				description: 'Order model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(Order) where?: Where<Order>): Promise<Count> {
		return this.orderRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/mobile/orders', {
		responses: {
			'200': {
				description: 'Array of Order model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(Order, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async findMobile(@param.filter(Order) filter?: Filter<Order>): Promise<any> {
		return this.gettingOrderHelper(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
	@get('/orders', {
		responses: {
			'200': {
				description: 'Array of Order model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(Order, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(Order) filter?: Filter<Order>): Promise<any> {
		return this.orderRepository.find(filter, {include: [{relation: 'vehicle'}]});
	}

	async gettingOrderHelper(filter?: Filter<Order>) {
		const orders = await this.orderRepository.find(filter);
		return {
			statuscode: 200,
			orders: orders
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/orders', {
		responses: {
			'200': {
				description: 'Order PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Order, {partial: true})
				}
			}
		})
		order: Order,
		@param.where(Order) where?: Where<Order>
	): Promise<Count> {
		order.updatedAt = new Date().toString();		// basically update it with now()
		return this.orderRepository.updateAll(order, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/mobile/orders/{id}', {
		responses: {
			'200': {
				description: 'Order model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Order, {includeRelations: true})
					}
				}
			}
		}
	})
	async findByIdMobile(
		@param.path.number('id') id: number,
		@param.filter(Order, {exclude: 'where'})
		filter?: FilterExcludingWhere<Order>
	): Promise<Order> {
		return this.findByIdOrderHelper(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/orders/{id}', {
		responses: {
			'200': {
				description: 'Order model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Order, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(Order, {exclude: 'where'})
		filter?: FilterExcludingWhere<Order>
	): Promise<Order> {
		return this.findByIdOrderHelper(id, filter);
	}

	async findByIdOrderHelper(id: number, filter: any) {
		return this.orderRepository.findById(id, filter);
		// return this.orderRepository.findById(id, {include: [{relation: 'vehicle'}]});
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
	@patch('/orders/{id}', {
		responses: {
			'204': {
				description: 'Order PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Order, {partial: true})
				}
			}
		})
		order: Order
	): Promise<void> {
		const token = this.req.headers.authorization?.split(' ')[1];
		const userProfile = await this.jwtService.verifyToken(token!);
		//ToDo: put this in task queue
		await this.orderHistoryRepository.create({
			orderId: id,
			orderJson: order,
			actionPerformed: 'UPDATE',
			changedBy: userProfile,
		});


		let requiredStatuses = [4]; // status for tracking order in PWA

		let url: string;
		if (process.env.NODE_ENV === "development") {
			url = "http://track-dev.readyassist.net/";
		} else {
			url = "http://track.readyassist.net/";
		}
		if (requiredStatuses.includes(order.status)) {
			let orderData = await this.orderRepository.findById(id);
			let orderDetails = await this.orderDetailsRepository.findOne({where: {orderId: id, isActive: true}});
			let vechileDetails = await this.vehicleMasterRepository.findById(orderData.vehicleId);
			console.log(vechileDetails);
			let vendorDetails = await this.vendorRepository.findById(orderDetails!.vendorId);
			let phoneNumber = await makeProperPhoneNumber(orderData.custPhoneNumber);
			const tasklocation = orderData.taskGeopoint as ItaskGeoPoint;
			const firestore = firebase.firestore();
            const GeoFireStore = geofirestore.initializeApp(firestore);
            const geocollection = GeoFireStore.collection('vendor').doc(
              orderDetails?.vendorId.toString(),
            );

            // write the code for getting the location of the vendor here
						const doc = await geocollection.get();
						console.log("Docs"+doc.data())
						let duration:any;
            if (doc.exists) {
              let data = doc.data();

              const options = {
                key: process.env.GOOGLE_API_KEY,
                origins: [
                  '"' +
                    data!.Locations._lat +
                    ',' +
                    data!.Locations._long +
                    '"',
                ],
                destinations: [
                  '"' + tasklocation.lat + ',' + tasklocation.lng + '"',
                ],
              };

              const distanceData = util.promisify(GoogleDistanceApi.distance);

              await distanceData(options).then((res: any) => {
                duration=res[0].duration;
							});
							await	this.smsService.sendSms(phoneNumber,orderData.custName,url+ id.toString(36) ,id.toString(10),vendorDetails.name,duration,vechileDetails.make+" "+vechileDetails.model);
						}
		}
		await this.orderRepository.updateById(id, order);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/mobile/orders/{id}', {
		responses: {
			'204': {
				description: 'Order PUT success'
			}
		}
	})
	async replaceByIdMobile(@param.path.number('id') id: number, @requestBody() order: Order): Promise<any> {
		const token = this.req.headers.authorization?.split(' ')[1];
		const userProfile = await this.jwtService.verifyToken(token!);
		return this.orderChangeHelper(id, order, userProfile);
	}


	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
	@patch('/mobile/orders/{id}', {
		responses: {
			'200': {
				description: 'Update Successfully'
			},
			'500': {
				description: 'Internal Server Error'
			}
		}
	})
	async updateByIdMobile(
		@param.path.number('id') id: number,
		@requestBody()
		body: {
			location: string,
			actionPerformed: string,
			orderDetailsId: number,
			orderDetailsData: any,
			status: number,
			recordingUrl: string,
			ExotelCallSid: string
		}
	): Promise<any> {
		try {
			const token = this.req.headers.authorization?.split(' ')[1];
			const userProfile = await this.jwtService.verifyToken(token!);
			const order = await this.orderRepository.findById(id);
			if (body.status <= order.status) {
				return {
					statusCode: 409,
					message: "Order status can not be changed as order is already in status " + order.status,
				}
			}
			await this.orderHistoryRepository.create({
				orderId: id,
				orderJson: order,
				actionPerformed: body.actionPerformed,
				location: body.location,
				changedBy: userProfile,
				recordingUrl: body.recordingUrl ? body.recordingUrl : '',
				ExotelCallSid: body.ExotelCallSid ? body.ExotelCallSid : '',
			});

			// ToDo: orderDetailsId should be actually avoided and instead orderId should be used in future.

			const orderDetailsData = await this.orderDetailsRepository.findById(body.orderDetailsId);
			if (orderDetailsData.vendorId !== userProfile.vendorId)
				return {
					statusCode: 400,
					message: "Unauthorized: Order does not belong to you."
				}

			await this.orderDetailsRepository.updateById(body.orderDetailsId, body.orderDetailsData);
			await this.orderRepository.updateById(id, {status: body.status});

			// whenever mechanic works on the order, show the status to be busy
			if ([3, 4, 5, 6, 7, 8].includes(body.status)) {
				await this.vendorRepository.updateById(orderDetailsData.vendorId, {status: 2});
			}

			// whenever mechanic is done working on the order, make him free.
			if ([9, 10, 11, 12].includes(body.status)) {
				await this.vendorRepository.updateById(orderDetailsData.vendorId, {status: 0});
			}

			return {
				statusCode: 200,
				message: "Update successfully"
			}
		} catch (error) {
			console.error("Order update error ", error);
			return {
				statusCode: 500,
				message: "Internal Server Error!"
			}

		}

	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/orders/{id}', {
		responses: {
			'204': {
				description: 'Order PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() order: Order): Promise<any> {
		const token = this.req.headers.authorization?.split(' ')[1];
		const userProfile = await this.jwtService.verifyToken(token!);
		return this.orderChangeHelper(id, order, userProfile);
	}

	async orderChangeHelper(id: number, order: Order, userProfile: UserProfile) {
		await this.orderHistoryRepository.create({
			orderId: id,
			orderJson: order,
			actionPerformed: 'REPLACE',
			changedBy: userProfile
		});

		order.updatedAt = new Date().toString();		// again updated at should be now()
		await this.orderRepository.replaceById(id, order);
		return {
			statusCode: 200,
			message: 'Update succesfully'
		};
	}

	// @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	// @del('/orders/{id}', {
	// 	responses: {
	// 		'204': {
	// 			description: 'Order DELETE success'
	// 		}
	// 	}
	// })
	// async deleteById(@param.path.number('id') id: number): Promise<void> {
	// 	const token = this.req.headers.authorization?.split(' ')[1];
	// 	const userProfile = await this.jwtService.verifyToken(token!);
	// 	await this.orderHistoryRepository.create({
	// 		orderId: id,
	// 		orderJson: await this.orderRepository.findById(id),
	// 		actionPerformed: 'DELETE',
	// 		changedBy: userProfile
	// 	});
	// 	// do not delete the order, just deactivate it in backend.
	// 	await this.orderRepository.updateById(id, {isActive: false});
	// }

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/orders/{id}/reassign', {
		responses: {
			'200': {
				description: 'Update Successfully'
			},
			'500': {
				description: 'Internal Server Error'
			}
		}
	})
	async reassignOrder(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(OrderDetails, {
						title: 'NewOrderDetails',
						exclude: ['id'],
					}),
				},
			},
		})
		orderDetails: Omit<OrderDetails, 'id'>,
	): Promise<any> {
		try {
			const tx = await this.orderRepository.dataSource.beginTransaction({
				isolationLevel: IsolationLevel.READ_COMMITTED,
				timeout: OrderTransactionTimeInms,
			});
			const mechanicId: number = orderDetails.vendorId;
			const reqMechanic: Vendor = await this.vendorRepository.findById(mechanicId);
			if (!reqMechanic.isActive) {
				return {
					statusCode: 500,
					message: "Mechanic is blocked!"
				}
			}

			if (reqMechanic.status === 4) {
				return {
					statusCode: 500,
					message: "Mechanic is not on duty!"
				}
			}

			const token = this.req.headers.authorization?.split(' ')[1];
			const userProfile = await this.jwtService.verifyToken(token!);
			const order = await this.orderRepository.findById(id);
			await this.orderHistoryRepository.create({
				orderId: id,
				orderJson: order,
				actionPerformed: 'REASSIGN',
				changedBy: userProfile,
			}, {tx});
			// find out which mechanic the order was previously assigned
			const existingOrderDetails = await this.orderDetailsRepository.findOne({where: {isActive: true, orderId: order.id}});
			const previousVendorId = existingOrderDetails?.vendorId;
			if (previousVendorId) {
				// make this vendor free
				await this.vendorRepository.updateById(previousVendorId, {status: 0}, {tx});
			}
			// deactivate previous orders
			await this.orderDetailsRepository.updateAll({isActive: false}, {orderId: order.id}, {tx});
			orderDetails.isActive = true;
			const ordDetails: OrderDetails = await this.orderDetailsRepository.create(orderDetails, {tx});
			if (ordDetails.vendorId) {
				await this.orderRepository.updateById(ordDetails.orderId, {status: 2}, {tx});
			}
			await tx.commit();
			const msg: Object = {
				notification: {
					title: "Readyassist NEW ORDER!",
					body: "#" + ordDetails.orderId + " assigned to you!",
					sound: 'default'
				}
			};
			const options: Object = {
				priority: 'high',
			};
			if (reqMechanic.fcmToken) {
				await sendPushNotificationToMechanic(reqMechanic.fcmToken, msg, options);
			}
			return ordDetails;
		} catch (error) {
			console.error("Order update error ", error);
			return {
				statusCode: 500,
				message: "Internal Server Error!"
			}
		}
	}



	// unassign the order
	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/orders/{id}/unassign', {
		responses: {
			'200': {
				description: 'Update Successfully'
			},
			'500': {
				description: 'Internal Server Error'
			}
		}
	})
	async unassignOrder(
		@param.path.number('id') id: number,
	): Promise<any> {
		try {
			const tx = await this.orderRepository.dataSource.beginTransaction({
				isolationLevel: IsolationLevel.READ_COMMITTED,
				timeout: OrderTransactionTimeInms,
			});
			const token = this.req.headers.authorization?.split(' ')[1];
			const userProfile = await this.jwtService.verifyToken(token!);
			const order = await this.orderRepository.findById(id);
			await this.orderHistoryRepository.create({
				orderId: id,
				orderJson: order,
				actionPerformed: 'UNASSIGN',
				changedBy: userProfile,
			}, {tx});
			// deactivate previous orders
			const ordDetails = await this.orderDetailsRepository.findOne({where: {orderId: id, isActive: true}}, {tx});
			await this.orderDetailsRepository.updateAll({isActive: false}, {orderId: order.id}, {tx});
			await this.orderRepository.updateById(order.id, {status: 1}, {tx});
			await tx.commit();
			if (ordDetails) {
				const reqVendor = await this.vendorRepository.findById(ordDetails.vendorId);
				// make this vendor free
				await this.vendorRepository.updateById(ordDetails.vendorId, {status: 0}, {tx});
				const msg: Object = {
					notification: {
						title: "Readyassist Order Cancelled!",
						body: "#" + id + " Has been cancelled! Please refresh for new orders.",
						sound: 'default'
					}
				};
				const options: Object = {
					priority: 'high',
				};
				if (reqVendor.fcmToken) {
					await sendPushNotificationToMechanic(reqVendor.fcmToken, msg, options);
				}
			}
			return {
				statusCode: 200,
				message: "Order unassigned!"
			}
		} catch (error) {
			console.error("Order update error ", error);
			return {
				statusCode: 500,
				message: "Internal Server Error!"
			}
		}
	}


	// customers my orders
	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Customer]})
	@get('customer/myorders', {
		responses: {
			'200': {
				description: 'Order model instance',
				content: {'application/json': {schema: getModelSchemaRef(Order)}}
			}
		}
	})
	async fetchMyOrders(
		@requestBody({
			content: {
				'application/json': {
					schema: {
						type: 'object',
						properties: {
						}
					}
				}
			}
		})
		order: Omit<Order, 'id'>
	): Promise<any> {
		const token = this.req.headers.authorization?.split(' ')[1];
		const userProfile = await this.jwtService.verifyToken(token!);
		// console.log('user profile ---', userProfile);
		const custId: number = userProfile.id;				// customer ID

		// console.log('custId===', custId);
		// going to do with transaction in mind.

		// const customer: Customer = await this.customerRepository.findById(custId);
		const user: User = await this.userRepository.findById(custId);

		// console.log("customer ---", user);
		const mobile: string = user.mobileNo;
		// ToDo: @deval to fix this!!!
		const activeCustomerOrders: Order[] = await this.orderRepository.find({where: {custPhoneNumber: mobile, isActive: true}})
		// console.log("active cust order----", activeCustomerOrders);
		const refinedActiveCustomerOrders = activeCustomerOrders;

		// refine the json (don't give away all the fields)
		// id, status, customer related information -> remove all and any other metadata and admin related information
		// refined return
		return refinedActiveCustomerOrders;
	}


	// =============find all mechanics near order location =================
	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
	@get('/customer/order/mechanic/{id}', {
		responses: {
			'200': {
				description: 'order model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Order, {includeRelations: true}),
					},
				},
			},
		},
	})
	async getMechanicsNearOrderId(
		@param.path.number('id') id: number,
		@param.filter(Vendor) filter?: Filter<Vendor>,
	): Promise<any> {
		if (!id) {
			return Promise.reject('Order not found');
		}

		const orderObject = await this.orderRepository.findById(id);
		if (orderObject) {
			if (!orderObject.taskGeopoint) {
				return Promise.reject('Task location not found');
			}
			const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;
			// const eligiblePolygons = await this.elasticQueries.findPolygonsWithPointInIt(tasklocation.lng, tasklocation.lat);
			// const firstPolygon = await eligiblePolygons[0];
			// const polygon = await turf.polygon(firstPolygon._source.geofence.coordinates);

			const params = {
				type: serviceAccount.type,
				projectId: serviceAccount.project_id,
				privateKeyId: serviceAccount.private_key_id,
				privateKey: serviceAccount.private_key,
				clientEmail: serviceAccount.client_email,
				clientId: serviceAccount.client_id,
				authUri: serviceAccount.auth_uri,
				tokenUri: serviceAccount.token_uri,
				authProviderX509CertUrl: serviceAccount.auth_provider_x509_cert_url,
				clientC509CertUrl: serviceAccount.client_x509_cert_url
			};

			// firebase.initializeApp(params);
			const firestore = firebase.firestore();
			const GeoFireStore = geofirestore.initializeApp(firestore);
			const geocollection = GeoFireStore.collection('vendor');

			return geocollection.get().then(async (values) => {
				// let allRequiredMechancis = values.docs.map(doc =>({id: doc.id, lon: doc.data().Locations._long, lat: doc.data().Locations._lat}))
				// 	.filter(doc => turf.booleanPointInPolygon(turf.point([doc.lon, doc.lat]), polygon))
				// 	.map(doc => ({id: doc.id, lon: doc.lon, lat: doc.lat, dist: turf.distance(turf.point([doc.lon, doc.lat]), turf.point([tasklocation.lng, tasklocation.lat]), {units: 'kilometers'})}));

				let allRequiredMechancis = values.docs.map(doc =>
					({id: doc.id, lon: doc.data().Locations._long, lat: doc.data().Locations._lat, vs: doc.data().vs, ts: doc.data().ts}))
					.map(doc =>
						({id: doc.id, vs: doc.vs, ts: doc.ts, lon: doc.lon, lat: doc.lat, dist: turf.distance(turf.point([doc.lon, doc.lat]), turf.point([tasklocation.lng, tasklocation.lat]), {units: 'kilometers'})}));

				// console.log("all required mechanics ---",allRequiredMechancis);

				allRequiredMechancis = _.sortBy(allRequiredMechancis, 'dist')
				console.log("sorted allRequiredMechancis ----",allRequiredMechancis);
				const acceptableStatuses = ['ON DUTY', 'Busy', 'On Break', 'Transit'];

				let allMechanics = [];
				for (let i = 0; i < allRequiredMechancis.length; i++) {
					if (allRequiredMechancis[i].dist <= VendorRadialDistance) {
						// filter as per the latest status
						if (acceptableStatuses.includes(allRequiredMechancis[i].vs)) {
							allMechanics.push(allRequiredMechancis[i])
						}
					}
				}
				// assuming that out of 10 at least one will be idle
				allRequiredMechancis = allMechanics.slice(0, 50);
				// const mechanicArray = allRequiredMechancis.map(ele => {
				// 	return parseInt(ele.id);
				// })

				const vendors : any = await this.vendorRepository.find(filter, {include: [{relation: 'location'}, {relation: 'team'}, {relation: 'shift'}]});
				// console.log("vendors ---",vendors);
				let response: any = [];
				for (let i = 0; i < allRequiredMechancis.length; i++) {
					let mechanics = vendors.find((vnd :any)=> {
						if (Number(vnd.id) == Number(allRequiredMechancis[i].id) && vnd.isActive == true) {
							// var vrd : any = { vnd} ;
							vnd.firebaseData =  allRequiredMechancis[i]
							return vnd
						}
					})
					if (mechanics) {
						response.push(mechanics);
					}
				}
				console.log("response of get mechanics -------",response);
				return Promise.resolve(response);
			}).catch((err) => {
				return Promise.reject(err);
			});
		}
		else {
			return Promise.reject('order not Found');
		}
	}
}
