import {authenticate} from '@loopback/authentication';
import {FilterExcludingWhere, repository} from '@loopback/repository';
import {get, getModelSchemaRef, param} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {CouponTrans} from '../models';
import {CouponTransRepository} from '../repositories';

export class CouponTransController {
  constructor(
    @repository(CouponTransRepository)
    public couponTransRepository: CouponTransRepository,
  ) {}

  // @post('/coupon-trans', {
  //   responses: {
  //     '200': {
  //       description: 'CouponTrans model instance',
  //       content: {'application/json': {schema: getModelSchemaRef(CouponTrans)}},
  //     },
  //   },
  // })
  // async create(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(CouponTrans, {
  //           title: 'NewCouponTrans',
  //           exclude: ['id'],
  //         }),
  //       },
  //     },
  //   })
  //   couponTrans: Omit<CouponTrans, 'id'>,
  // ): Promise<CouponTrans> {
  //   return this.couponTransRepository.create(couponTrans);
  // }

  // @get('/coupon-trans/count', {
  //   responses: {
  //     '200': {
  //       description: 'CouponTrans model count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async count(
  //   @param.where(CouponTrans) where?: Where<CouponTrans>,
  // ): Promise<Count> {
  //   return this.couponTransRepository.count(where);
  // }

  // @get('/coupon-trans', {
  //   responses: {
  //     '200': {
  //       description: 'Array of CouponTrans model instances',
  //       content: {
  //         'application/json': {
  //           schema: {
  //             type: 'array',
  //             items: getModelSchemaRef(CouponTrans, {includeRelations: true}),
  //           },
  //         },
  //       },
  //     },
  //   },
  // })
  // async find(
  //   @param.filter(CouponTrans) filter?: Filter<CouponTrans>,
  // ): Promise<CouponTrans[]> {
  //   return this.couponTransRepository.find(filter);
  // }

  // @patch('/coupon-trans', {
  //   responses: {
  //     '200': {
  //       description: 'CouponTrans PATCH success count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(CouponTrans, {partial: true}),
  //       },
  //     },
  //   })
  //   couponTrans: CouponTrans,
  //   @param.where(CouponTrans) where?: Where<CouponTrans>,
  // ): Promise<Count> {
  //   return this.couponTransRepository.updateAll(couponTrans, where);
  // }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/coupon-trans/{id}', {
    responses: {
      '200': {
        description: 'CouponTrans model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(CouponTrans, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(CouponTrans, {exclude: 'where'}) filter?: FilterExcludingWhere<CouponTrans>
  ): Promise<CouponTrans> {
    return this.couponTransRepository.findById(id, filter);
  }

  // @patch('/coupon-trans/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'CouponTrans PATCH success',
  //     },
  //   },
  // })
  // async updateById(
  //   @param.path.number('id') id: number,
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(CouponTrans, {partial: true}),
  //       },
  //     },
  //   })
  //   couponTrans: CouponTrans,
  // ): Promise<void> {
  //   await this.couponTransRepository.updateById(id, couponTrans);
  // }

  // @put('/coupon-trans/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'CouponTrans PUT success',
  //     },
  //   },
  // })
  // async replaceById(
  //   @param.path.number('id') id: number,
  //   @requestBody() couponTrans: CouponTrans,
  // ): Promise<void> {
  //   await this.couponTransRepository.replaceById(id, couponTrans);
  // }

  // @del('/coupon-trans/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'CouponTrans DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.couponTransRepository.deleteById(id);
  // }
}
