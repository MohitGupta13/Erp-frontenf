import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Orderhistory} from '../models';
import {OrderhistoryRepository} from '../repositories';

export class OrderhistoryController {
	constructor(@repository(OrderhistoryRepository) public orderhistoryRepository: OrderhistoryRepository) {}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/orderhistories', {
		responses: {
			'200': {
				description: 'Orderhistory model instance',
				content: {'application/json': {schema: getModelSchemaRef(Orderhistory)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Orderhistory, {
						title: 'NewOrderhistory',
						exclude: ['id']
					})
				}
			}
		})
		orderhistory: Omit<Orderhistory, 'id'>
	): Promise<Orderhistory> {
		return this.orderhistoryRepository.create(orderhistory);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/orderhistories/count', {
		responses: {
			'200': {
				description: 'Orderhistory model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(Orderhistory) where?: Where<Orderhistory>): Promise<Count> {
		return this.orderhistoryRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/orderhistories', {
		responses: {
			'200': {
				description: 'Array of Orderhistory model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(Orderhistory, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(Orderhistory) filter?: Filter<Orderhistory>): Promise<any> {
		return this.orderhistoryRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/orderhistories', {
		responses: {
			'200': {
				description: 'Orderhistory PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Orderhistory, {partial: true})
				}
			}
		})
		orderhistory: Orderhistory,
		@param.where(Orderhistory) where?: Where<Orderhistory>
	): Promise<Count> {
		return this.orderhistoryRepository.updateAll(orderhistory, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/orderhistories/{id}', {
		responses: {
			'200': {
				description: 'Orderhistory model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Orderhistory, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(Orderhistory, {exclude: 'where'})
		filter?: FilterExcludingWhere<Orderhistory>
	): Promise<Orderhistory> {
		return this.orderhistoryRepository.findById(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/orderhistories/{id}', {
		responses: {
			'204': {
				description: 'Orderhistory PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Orderhistory, {partial: true})
				}
			}
		})
		orderhistory: Orderhistory
	): Promise<void> {
		await this.orderhistoryRepository.updateById(id, orderhistory);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/orderhistories/{id}', {
		responses: {
			'204': {
				description: 'Orderhistory PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() orderhistory: Orderhistory): Promise<void> {
		await this.orderhistoryRepository.replaceById(id, orderhistory);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@del('/orderhistories/{id}', {
		responses: {
			'204': {
				description: 'Orderhistory DELETE success'
			}
		}
	})
	async deleteById(@param.path.number('id') id: number): Promise<void> {
		await this.orderhistoryRepository.deleteById(id);
	}
}
