import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {ServiceMaster} from '../models';
import {ServiceMasterRepository} from '../repositories';

export class ServiceMasterController {
	constructor(@repository(ServiceMasterRepository) public serviceMasterRepository: ServiceMasterRepository) {}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
	@post('/service-masters', {
		responses: {
			'200': {
				description: 'ServiceMaster model instance',
				content: {'application/json': {schema: getModelSchemaRef(ServiceMaster)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(ServiceMaster, {
						title: 'NewServiceMaster',
						exclude: ['id']
					})
				}
			}
		})
		serviceMaster: Omit<ServiceMaster, 'id'>
	): Promise<ServiceMaster> {
		return this.serviceMasterRepository.create(serviceMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin,PermissionKeys.Customer]})
	@get('/service-masters/count', {
		responses: {
			'200': {
				description: 'ServiceMaster model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(ServiceMaster) where?: Where<ServiceMaster>): Promise<Count> {
		return this.serviceMasterRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser,PermissionKeys.Customer, PermissionKeys.Mechanic]})
	@get('/service-masters', {
		responses: {
			'200': {
				description: 'Array of ServiceMaster model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(ServiceMaster, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(ServiceMaster) filter?: Filter<ServiceMaster>): Promise<ServiceMaster[]> {
		return this.serviceMasterRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/service-masters', {
		responses: {
			'200': {
				description: 'ServiceMaster PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(ServiceMaster, {partial: true})
				}
			}
		})
		serviceMaster: ServiceMaster,
		@param.where(ServiceMaster) where?: Where<ServiceMaster>
	): Promise<Count> {
		return this.serviceMasterRepository.updateAll(serviceMaster, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin,PermissionKeys.Customer]})
	@get('/service-masters/{id}', {
		responses: {
			'200': {
				description: 'ServiceMaster model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(ServiceMaster, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(ServiceMaster, {exclude: 'where'})
		filter?: FilterExcludingWhere<ServiceMaster>
	): Promise<ServiceMaster> {
		return this.serviceMasterRepository.findById(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/service-masters/{id}', {
		responses: {
			'204': {
				description: 'ServiceMaster PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(ServiceMaster, {partial: true})
				}
			}
		})
		serviceMaster: ServiceMaster
	): Promise<void> {
		await this.serviceMasterRepository.updateById(id, serviceMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/service-masters/{id}', {
		responses: {
			'204': {
				description: 'ServiceMaster PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() serviceMaster: ServiceMaster): Promise<void> {
		await this.serviceMasterRepository.replaceById(id, serviceMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@del('/service-masters/{id}', {
		responses: {
			'204': {
				description: 'ServiceMaster DELETE success'
			}
		}
	})
	async deleteById(@param.path.number('id') id: number): Promise<void> {
		await this.serviceMasterRepository.deleteById(id);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/unique-service-names', {
		responses: {
			'200': {
				description: 'service-master names based on the conditions!'
			}
		}
	})
	async findServiceNameByTypeAndCC(@requestBody() body: {type: string; qualifier: number; cc: number}): Promise<any> {
		const type = body.type;
		let qualifier = '<';
		switch (body.qualifier) {
			case -1:
				qualifier = '<';
				break;

			case 0:
				qualifier = '=';
				break;

			case 1:
				qualifier = '>';
				break;

			default:
				break;
		}
		const sql =
			`select distinct s.name from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and CONVERT(cc, UNSIGNED INTEGER) ` +
			qualifier +
			` ? order by s.name asc`;
		const cc = body.cc;
		return this.serviceMasterRepository.dataSource.execute(sql, [type, cc]);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/unique-service-names-mobile', {
		responses: {
			'200': {
				description: 'service-master names based on the conditions!'
			}
		}
	})
	async findServiceNameByTypeAndCCMobile(@requestBody() body: {type: string; qualifier: number; cc: number}): Promise<any> {
		const type = body.type;
		let qualifier = '<';
		switch (body.qualifier) {
			case -1:
				qualifier = '<';
				break;

			case 0:
				qualifier = '=';
				break;

			case 1:
				qualifier = '>';
				break;

			default:
				break;
		}
		const sql =
			`select distinct s.name from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and CONVERT(cc, UNSIGNED INTEGER) ` +
			qualifier +
			` ? order by s.name asc`;
		const cc = body.cc;
		const data = await this.serviceMasterRepository.dataSource.execute(sql, [type, cc]);
		return {
			data: data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/distinct-service-names', {
		responses: {
			'200': {
				description: 'service names based on the conditions!'
			}
		}
	})
	async findMakeModelByTypeCategoryService(@requestBody() body: {type: string; category: string}): Promise<any> {
		const sql = `select distinct s.name from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and VM.category=? order by s.name asc`;
		const type = body.type;
		const category = body.category;
		return this.serviceMasterRepository.dataSource.execute(sql, [type, category]);
	}


	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/distinct-service-categories', {
		responses: {
			'200': {
				description: 'service categories!'
			}
		}
	})
	async findCategories(): Promise<any> {
		const sql = `select distinct subCategory from ServiceMaster where clientId = 1 and subCategory is not null`;
		return this.serviceMasterRepository.dataSource.execute(sql, []);
	}


	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/distinct-service-categories-mobile', {
		responses: {
			'200': {
				description: 'service categories!'
			}
		}
	})
	async findCategoriesMobile(@requestBody() body: {type: string; category: string}): Promise<any> {
		const sql = `select distinct subCategory from ServiceMaster where clientId = 1 and subCategory is not null`;
		const data = await this.serviceMasterRepository.dataSource.execute(sql, []);
		return {
			data: data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/service-masters/distinct-service-names-mobile', {
		responses: {
			'200': {
				description: 'service names based on the conditions!'
			}
		}
	})
	async findMakeModelByTypeCategoryServiceMobile(@requestBody() body: {type: string; category: string}): Promise<any> {
		const sql = `select distinct s.name from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and VM.category in (?) order by s.name asc`;
		const type = body.type;
		// category is always going to be an array
		const category = body.category;
		const data = await this.serviceMasterRepository.dataSource.execute(sql, [type, category]);
		return {
			data: data
		};
	}
}
