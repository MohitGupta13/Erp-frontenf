import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {AggregatorService} from '../models';
import {AggregatorServiceRepository} from '../repositories';

export class AggregatorServiceController {
	constructor(@repository(AggregatorServiceRepository) public aggregatorServiceRepository: AggregatorServiceRepository) {}

	async gettingAggregatorServicesHelper(filter?: Filter<AggregatorService>) {
		const data = await this.aggregatorServiceRepository.find(filter);
		return {
			data: data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/aggregator-services', {
		responses: {
			'200': {
				description: 'AggregatorService model instance',
				content: {'application/json': {schema: getModelSchemaRef(AggregatorService)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(AggregatorService, {
						title: 'NewAggregatorService',
						exclude: ['id']
					})
				}
			}
		})
		aggregatorService: Omit<AggregatorService, 'id'>
	): Promise<unknown> {
		try {
			return await this.aggregatorServiceRepository.create(aggregatorService);
		} catch (e) {
			return {
				statusCode: 500,
				error: e
			}
		}
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/aggregator-services/count', {
		responses: {
			'200': {
				description: 'AggregatorService model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(AggregatorService) where?: Where<AggregatorService>): Promise<Count> {
		return this.aggregatorServiceRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/aggregator-services', {
		responses: {
			'200': {
				description: 'Array of AggregatorService model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(AggregatorService, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(AggregatorService) filter?: Filter<AggregatorService>): Promise<AggregatorService[]> {
		return this.aggregatorServiceRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/aggregator-services-mobile', {
		responses: {
			'200': {
				description: 'Array of AggregatorService model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(AggregatorService, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async findMobile(@param.filter(AggregatorService) filter?: Filter<AggregatorService>): Promise<any> {
		return this.gettingAggregatorServicesHelper(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/aggregator-services', {
		responses: {
			'200': {
				description: 'AggregatorService PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(AggregatorService, {partial: true})
				}
			}
		})
		aggregatorService: AggregatorService,
		@param.where(AggregatorService) where?: Where<AggregatorService>
	): Promise<Count> {
		return this.aggregatorServiceRepository.updateAll(aggregatorService, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/aggregator-services/{id}', {
		responses: {
			'200': {
				description: 'AggregatorService model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(AggregatorService, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(AggregatorService, {exclude: 'where'})
		filter?: FilterExcludingWhere<AggregatorService>
	): Promise<AggregatorService> {
		return this.aggregatorServiceRepository.findById(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/aggregator-services/{id}', {
		responses: {
			'204': {
				description: 'AggregatorService PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(AggregatorService, {partial: true})
				}
			}
		})
		aggregatorService: AggregatorService
	): Promise<void> {
		await this.aggregatorServiceRepository.updateById(id, aggregatorService);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/aggregator-services/{id}', {
		responses: {
			'204': {
				description: 'AggregatorService PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() aggregatorService: AggregatorService): Promise<void> {
		await this.aggregatorServiceRepository.replaceById(id, aggregatorService);
	}

	// @del('/aggregator-services/{id}', {
	//   responses: {
	//     '204': {
	//       description: 'AggregatorService DELETE success',
	//     },
	//   },
	// })
	// async deleteById(@param.path.number('id') id: number): Promise<void> {
	//   await this.aggregatorServiceRepository.deleteById(id);
	// }
}
