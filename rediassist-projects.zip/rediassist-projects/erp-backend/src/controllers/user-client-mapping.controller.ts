import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,

  repository,
  Where
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param,


  patch, post,




  put,

  Request,
  requestBody,
  RestBindings
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {TokenServiceBindings, UserServiceBindings} from '../keys';
import {UserClientMapping} from '../models';
import {ClientMasterRepository, UserClientMappingRepository} from '../repositories';
import {JWTService} from '../services/jwt-service';
import {MyUserService} from '../services/user-service';
export class UserClientMappingController {
  constructor(
    @repository(UserClientMappingRepository)
    public userClientMappingRepository : UserClientMappingRepository,
    @repository(ClientMasterRepository)
    public clientMasterRepository : ClientMasterRepository,
    @inject(RestBindings.Http.REQUEST)
    private req: Request,

    @inject(UserServiceBindings.USER_SERVICE)
    public userService: MyUserService,
    //@inject('service.jwt.service')
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: JWTService
  ) {}

  @post('/user-client-mappings', {
    responses: {
      '200': {
        description: 'UserClientMapping model instance',
        content: {'application/json': {schema: getModelSchemaRef(UserClientMapping)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserClientMapping, {
            title: 'NewUserClientMapping',
            exclude: ['id'],
          }),
        },
      },
    })
    userClientMapping: Omit<UserClientMapping, 'id'>,
  ): Promise<UserClientMapping> {
    return this.userClientMappingRepository.create(userClientMapping);
  }

  @get('/user-client-mappings/count', {
    responses: {
      '200': {
        description: 'UserClientMapping model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(UserClientMapping) where?: Where<UserClientMapping>,
  ): Promise<Count> {
    return this.userClientMappingRepository.count(where);
  }

  @get('/user-client-mappings', {
    responses: {
      '200': {
        description: 'Array of UserClientMapping model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(UserClientMapping, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(UserClientMapping) filter?: Filter<UserClientMapping>,
  ): Promise<UserClientMapping[]> {
    return this.userClientMappingRepository.find(filter);
  }

  @patch('/user-client-mappings', {
    responses: {
      '200': {
        description: 'UserClientMapping PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserClientMapping, {partial: true}),
        },
      },
    })
    userClientMapping: UserClientMapping,
    @param.where(UserClientMapping) where?: Where<UserClientMapping>,
  ): Promise<Count> {
    return this.userClientMappingRepository.updateAll(userClientMapping, where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/user-client-mappings', {
    responses: {
      '200': {
        description: 'UserClientMapping model instance',
        content: {
          'application/json': {
            type: 'array'
          },
        },
      },
    },
  })
  async findUserClientMapping(
    @param.filter(UserClientMapping) filter?: Filter<UserClientMapping>,
  ): Promise<any> {

    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    const id = userProfile.id;
    const clientList:any = [];
    const fltr = {where:{
      userId:id,
      isActive:1
    }};
    const userClientMapping = await this.userClientMappingRepository.find(fltr);

    if(userClientMapping.length > 0){
      userClientMapping.forEach((obj) => {
        clientList.push(obj.clientId);
      });
      const client =  await this.clientMasterRepository.find({where: {id: {inq: clientList}}, fields: {id: true, name: true,}},filter);
      return {userClientMapping:1,client};
    }else{
      const allClient = await this.clientMasterRepository.find({fields: {id: true, name: true,}},filter);
      return {userClientMapping:0,client:allClient};
    }
  }

  @patch('/user-client-mappings/{id}', {
    responses: {
      '204': {
        description: 'UserClientMapping PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UserClientMapping, {partial: true}),
        },
      },
    })
    userClientMapping: UserClientMapping,
  ): Promise<void> {
    await this.userClientMappingRepository.updateById(id, userClientMapping);
  }

  @put('/user-client-mappings/{id}', {
    responses: {
      '204': {
        description: 'UserClientMapping PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() userClientMapping: UserClientMapping,
  ): Promise<void> {
    await this.userClientMappingRepository.replaceById(id, userClientMapping);
  }

  // @del('/user-client-mappings/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'UserClientMapping DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.userClientMappingRepository.deleteById(id);
  // }
}
