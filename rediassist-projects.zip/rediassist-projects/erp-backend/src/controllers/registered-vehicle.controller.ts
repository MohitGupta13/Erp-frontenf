import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {RegisteredVehicle} from '../models';
import {RegisteredVehicleRepository} from '../repositories';

export class RegisteredVehicleController {
  constructor(
    @repository(RegisteredVehicleRepository)
    public registeredVehicleRepository: RegisteredVehicleRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/registered-vehicles', {
    responses: {
      '200': {
        description: 'RegisteredVehicle model instance',
        content: {'application/json': {schema: getModelSchemaRef(RegisteredVehicle)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(RegisteredVehicle, {
            title: 'NewRegisteredVehicle',
            exclude: ['id'],
          }),
        },
      },
    })
    registeredVehicle: Omit<RegisteredVehicle, 'id'>,
  ): Promise<RegisteredVehicle> {
    return this.registeredVehicleRepository.create(registeredVehicle);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/registered-vehicles/count', {
    responses: {
      '200': {
        description: 'RegisteredVehicle model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(RegisteredVehicle) where?: Where<RegisteredVehicle>,
  ): Promise<Count> {
    return this.registeredVehicleRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @get('/registered-vehicles', {
    responses: {
      '200': {
        description: 'Array of RegisteredVehicle model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(RegisteredVehicle, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(RegisteredVehicle) filter?: Filter<RegisteredVehicle>,
  ): Promise<RegisteredVehicle[]> {
    return this.registeredVehicleRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/registered-vehicles', {
    responses: {
      '200': {
        description: 'RegisteredVehicle PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(RegisteredVehicle, {partial: true}),
        },
      },
    })
    registeredVehicle: RegisteredVehicle,
    @param.where(RegisteredVehicle) where?: Where<RegisteredVehicle>,
  ): Promise<Count> {
    return this.registeredVehicleRepository.updateAll(registeredVehicle, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
  @get('/registered-vehicles/{id}', {
    responses: {
      '200': {
        description: 'RegisteredVehicle model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(RegisteredVehicle, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(RegisteredVehicle, {exclude: 'where'}) filter?: FilterExcludingWhere<RegisteredVehicle>
  ): Promise<RegisteredVehicle> {
    return this.registeredVehicleRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/registered-vehicles/{id}', {
    responses: {
      '204': {
        description: 'RegisteredVehicle PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(RegisteredVehicle, {partial: true}),
        },
      },
    })
    registeredVehicle: RegisteredVehicle,
  ): Promise<void> {
    await this.registeredVehicleRepository.updateById(id, registeredVehicle);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/registered-vehicles/{id}', {
    responses: {
      '204': {
        description: 'RegisteredVehicle PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() registeredVehicle: RegisteredVehicle,
  ): Promise<void> {
    await this.registeredVehicleRepository.replaceById(id, registeredVehicle);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/registered-vehicles/{id}', {
    responses: {
      '204': {
        description: 'RegisteredVehicle DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.registeredVehicleRepository.deleteById(id);
  }
}
