// Uncomment these imports to begin using these cool features!

// import {inject} from 'underscore';

import {inject} from '@loopback/core';
import {post, requestBody} from '@loopback/rest';
import {CustomerRepository} from '../repositories/customer.repository';


export class PwaApisController {
  constructor(
    @inject('repositories.CustomerRepository') public customerRepository: CustomerRepository,
  ) {}


  @post('/requestOTP', {
    responses: {
      '200': {
        description: 'Request OTP for a customer',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                sucess: {
                  type: 'boolean'
                },
                otp: {
                  type: 'string'
                }
              }
            }
          }
        }
      }
    }
  })
  async sendOTPToCustomer(@requestBody() body: {
    mobile: string
  }): Promise<any> {
    const custFound = await this.customerRepository.findOne({where: {mobileNo: body.mobile}});
    return custFound;
  }
}
