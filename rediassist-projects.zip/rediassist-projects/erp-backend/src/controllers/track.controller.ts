import '@firebase/firestore';
import {inject} from '@loopback/core';
import {get, getModelSchemaRef, param} from '@loopback/rest';
import * as firebase from 'firebase';
import * as geofirestore from 'geofirestore';
import * as util from 'util';
import {Customer} from '../models';
import {
  OrderDetailsRepository,
  OrderRepository,
  ServiceMasterRepository,
  VehicleMasterRepository,
  VendorRepository
} from '../repositories';
const GoogleDistanceApi = require('google-distance-api');

interface ItaskGeoPoint {
  lng: number;
  lat: number;
}
export class TrackController {
  constructor(
    @inject('repositories.OrderRepository')
    public orderRepository: OrderRepository,
    @inject('repositories.OrderDetailsRepository')
    public orderDetailsRepository: OrderDetailsRepository,
    @inject('repositories.VendorRepository')
    public vendorRepository: VendorRepository,
    @inject('repositories.ServiceMasterRepository')
    public serviceMasterRepository: ServiceMasterRepository,
    @inject('repositories.VehicleMasterRepository')
    public vehicleMasterRepository: VehicleMasterRepository,
  ) {}

  @get('/tracking/{OId}', {
    responses: {
      '200': {
        description: 'Order tracking information',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async customerOrderDetails(
    @param.path.string('OId') OId: string,
  ): Promise<any> {
    if (!OId) {
      return {statuscode: 200, success: true, screen: 'error'};
    }

    //parsing of string to base 36
    const id = parseInt(OId, 36);

    try {
      const orderObject = await this.orderRepository.findById(id);
      if (orderObject) {
        if (!orderObject.taskGeopoint) {
          return {statusCode: 200, success: true, screen: 'error'};
        }
        let requiredStatuses = [4];
        if (requiredStatuses.includes(orderObject.status)) {
          const orderDetailsData = await this.orderDetailsRepository.find({
            where: {orderId: id},
          });
          if (orderDetailsData[0]) {
            const vehicleInfo = await this.vehicleMasterRepository.findById(
              orderObject.vehicleId,
            );
            const vendorId = orderDetailsData[0].vendorId
              ? orderDetailsData[0].vendorId
              : '';
            if (!vendorId) {
              return {statusCode: 200, success: true, screen: 'error'};
            }
            const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;
            const vendorInfo = await this.vendorRepository.findById(
              orderDetailsData[0].vendorId,
            );
            const serviceInfo = await this.serviceMasterRepository.findById(
              orderObject.serviceId,
            );

            // firebase related
            const firestore = firebase.firestore();
            const GeoFireStore = geofirestore.initializeApp(firestore);
            const geocollection = GeoFireStore.collection('vendor').doc(
              vendorId.toString(),
            );

            // write the code for getting the location of the vendor here
            const doc = await geocollection.get();
            if (!doc.exists) {
              return {statusCode: 200, success: true, screen: 'error'};
            } else {
              let data = doc.data();

              const options = {
                key: process.env.GOOGLE_API_KEY,
                origins: [
                  '"' +
                    data!.Locations._lat +
                    ',' +
                    data!.Locations._long +
                    '"',
                ],
                destinations: [
                  '"' + tasklocation.lat + ',' + tasklocation.lng + '"',
                ],
              };

              const distanceData = util.promisify(GoogleDistanceApi.distance);
              let distance:any;
              let duration:any;
              await distanceData(options).then((res: any) => {
                distance=res[0].distance;
                duration=res[0].duration;
              });

              let response = {
                statusCode: 200,
                success: true,
                screen: 'map',
                data: {
                  id: id,
                  orderTime: orderObject.bookingTime,
                  source: orderObject.source,
                  vendorName: vendorInfo.name,
                  vendorMobile: vendorInfo.mobile,
                  vehicleNumber: orderObject.vehicleIdentificationNumber,
                  makeModel: vehicleInfo.make + ', ' + vehicleInfo.model,
                  vehicleType: vehicleInfo.type,
                  profileUrl: vendorInfo.profilePic1,
                  serviceName: serviceInfo.name,
                  tasklocation: tasklocation,
                  distance: distance,
                  time: duration,
                  mechanicLocation: {
                    lat: data!.Locations._lat,
                    lng: data!.Locations._long,
                  },
                },
              };
              return response;
            }
          }
        } else {
          return {statusCode: 200, success: true, status: orderObject.status,screen:"check"};
        }
      } else {
        return {statusCode: 200, success: true, status: 0,screen:"error"};
      }
    } catch (error) {
      return {statusCode: 200, success: true,status: 0,screen:"error"};
    }
  }

  @get('/mechanicLocation/{OId}', {
    responses: {
      '200': {
        description: 'Mechanic Location',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async vendorLocationDetails(
    @param.path.string('OId') OId: string,
  ): Promise<any> {
    if (!OId) {
      return {statuscode: 200, success: true, screen: 'error'};
    }

   //parsing of string to base 36
    const id = parseInt(OId, 36);;

    try {
      const orderObject = await this.orderRepository.findById(id);
      if (orderObject) {
          const orderDetailsData = await this.orderDetailsRepository.find({
            where: {orderId: id},
          });
          if (orderDetailsData[0]) {
            const vendorId = orderDetailsData[0].vendorId
              ? orderDetailsData[0].vendorId
              : '';
            if (!vendorId) {
              return {statusCode: 200, success: true, screen: 'error'};
            }
            const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;
            // firebase related
            const firestore = firebase.firestore();
            const GeoFireStore = geofirestore.initializeApp(firestore);
            const geocollection = GeoFireStore.collection('vendor').doc(
              vendorId.toString(),
            );

            // write the code for getting the location of the vendor here
            const doc = await geocollection.get();
            if (!doc.exists) {
              return {statusCode: 200, success: true, screen: 'error'};
            } else {
              let data = doc.data();

              // Distance Matrix api call
              // const options = {
              //   key: process.env.GOOGLE_API_KEY,
              //   origins: [
              //     '"' +
              //       data!.Locations._lat +
              //       ',' +
              //       data!.Locations._long +
              //       '"',
              //   ],
              //   destinations: [
              //     '"' + tasklocation.lat + ',' + tasklocation.lng + '"',
              //   ],
              // };


              // const distanceData = util.promisify(GoogleDistanceApi.distance);
              // let distance:any;
              // let duration:any;
              // await distanceData(options).then((res: any) => {
              //   distance=res[0].distance;
              //   duration=res[0].duration;
              // });

              let response = {
                statusCode: 200,
                success: true,
                screen: 'map',
                data: {
                   tasklocation: tasklocation,
                  // distance: distance,
                  // time: duration,
                  mechanicLocation: {
                    lat: data!.Locations._lat,
                    lng: data!.Locations._long,
                  },
                },
              };
              return response;
            }
          }else{
            return {statusCode: 200, success: true, screen: 'error'};
          }
        }else{
          return {statusCode: 200, success: true, screen: 'error'};
        }
    } catch (error) {
      return {statusCode: 200, success: true, screen: 'error'};
    }
  }
}
