import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {VendorHistory} from '../models';
import {VendorHistoryRepository} from '../repositories';

export class VendorHistoryController {
  constructor(
    @repository(VendorHistoryRepository)
    public vendorHistoryRepository: VendorHistoryRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/vendor-histories', {
    responses: {
      '200': {
        description: 'VendorHistory model instance',
        content: {'application/json': {schema: getModelSchemaRef(VendorHistory)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorHistory, {
            title: 'NewVendorHistory',
            exclude: ['id'],
          }),
        },
      },
    })
    vendorHistory: Omit<VendorHistory, 'id'>,
  ): Promise<VendorHistory> {
    return this.vendorHistoryRepository.create(vendorHistory);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-histories/count', {
    responses: {
      '200': {
        description: 'VendorHistory model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(VendorHistory) where?: Where<VendorHistory>,
  ): Promise<Count> {
    return this.vendorHistoryRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-histories', {
    responses: {
      '200': {
        description: 'Array of VendorHistory model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(VendorHistory, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(VendorHistory) filter?: Filter<VendorHistory>,
  ): Promise<VendorHistory[]> {
    return this.vendorHistoryRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-histories', {
    responses: {
      '200': {
        description: 'VendorHistory PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorHistory, {partial: true}),
        },
      },
    })
    vendorHistory: VendorHistory,
    @param.where(VendorHistory) where?: Where<VendorHistory>,
  ): Promise<Count> {
    return this.vendorHistoryRepository.updateAll(vendorHistory, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-histories/{id}', {
    responses: {
      '200': {
        description: 'VendorHistory model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(VendorHistory, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(VendorHistory, {exclude: 'where'}) filter?: FilterExcludingWhere<VendorHistory>
  ): Promise<VendorHistory> {
    return this.vendorHistoryRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-histories/{id}', {
    responses: {
      '204': {
        description: 'VendorHistory PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorHistory, {partial: true}),
        },
      },
    })
    vendorHistory: VendorHistory,
  ): Promise<void> {
    await this.vendorHistoryRepository.updateById(id, vendorHistory);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/vendor-histories/{id}', {
    responses: {
      '204': {
        description: 'VendorHistory PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() vendorHistory: VendorHistory,
  ): Promise<void> {
    await this.vendorHistoryRepository.replaceById(id, vendorHistory);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/vendor-histories/{id}', {
    responses: {
      '204': {
        description: 'VendorHistory DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.vendorHistoryRepository.deleteById(id);
  }
}
