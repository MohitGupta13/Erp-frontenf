import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Team} from '../models';
import {TeamRepository} from '../repositories';

export class TeamController {
  constructor(
    @repository(TeamRepository)
    public teamRepository: TeamRepository,
  ) { }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/teams', {
    responses: {
      '200': {
        description: 'Team model instance',
        content: {'application/json': {schema: getModelSchemaRef(Team)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Team, {
            title: 'NewTeam',
            exclude: ['id'],
          }),
        },
      },
    })
    team: Omit<Team, 'id'>,
  ): Promise<Team> {
    return this.teamRepository.create(team);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/teams/count', {
    responses: {
      '200': {
        description: 'Team model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(@param.where(Team) where?: Where<Team>): Promise<Count> {
    return this.teamRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser]})
  @get('/teams', {
    responses: {
      '200': {
        description: 'Array of Team model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Team, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(@param.filter(Team) filter?: Filter<Team>): Promise<Team[]> {
    return this.teamRepository.find(filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/mobile/teams', {
    responses: {
      '200': {
        description: 'Array of Team model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Team, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async mobileFind(@param.filter(Team) filter?: Filter<Team>): Promise<any> {
    try {
      const teams = await this.teamRepository.find(filter);
      return {
        statusCode: 200,
        data: teams
      }
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      }
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/teams', {
    responses: {
      '200': {
        description: 'Team PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Team, {partial: true}),
        },
      },
    })
    team: Team,
    @param.where(Team) where?: Where<Team>,
  ): Promise<Count> {
    return this.teamRepository.updateAll(team, where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/teams/{id}', {
    responses: {
      '200': {
        description: 'Team model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Team, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Team, {exclude: 'where'}) filter?: FilterExcludingWhere<Team>,
  ): Promise<Team> {
    return this.teamRepository.findById(id, filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/mobile/teams/{id}', {
    responses: {
      '200': {
        description: 'Team model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Team, {includeRelations: true}),
          },
        },
      },
    },
  })
  async mobileFindById(
    @param.path.number('id') id: number,
    @param.filter(Team, {exclude: 'where'}) filter?: FilterExcludingWhere<Team>,
  ): Promise<any> {
    try {
      const teams = await this.teamRepository.findById(id, filter);
      return {
        statusCode: 200,
        data: teams
      }
    } catch (e) {
      return {
        statusCode: 500,
        error: e
      }
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/teams/{id}', {
    responses: {
      '204': {
        description: 'Team PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Team, {partial: true}),
        },
      },
    })
    team: Team,
  ): Promise<void> {
    await this.teamRepository.updateById(id, team);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/teams/{id}', {
    responses: {
      '204': {
        description: 'Team PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() team: Team,
  ): Promise<void> {
    await this.teamRepository.replaceById(id, team);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/teams/{id}', {
    responses: {
      '204': {
        description: 'Team DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.teamRepository.deleteById(id);
  }
}
