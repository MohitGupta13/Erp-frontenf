import '@firebase/firestore';
import {authenticate} from '@loopback/authentication';
import {UserRepository} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {Count, CountSchema, Filter, FilterExcludingWhere, IsolationLevel, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, Request, requestBody, RestBindings} from '@loopback/rest';
import * as firebase from 'firebase';
import * as geofirestore from 'geofirestore';
import _ from 'lodash';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, NUM_CHARACTERS_IN_OTP, OTP_CHARACTERS} from '../constants';
import {PasswordHasherBindings, TokenServiceBindings, UserServiceBindings} from '../keys';
import {Customer} from '../models';
import {CustomerRepository, OrderDetailsRepository, OrderRepository, SmsLogRepository, VendorRepository} from '../repositories';
import {Smsotp} from '../services';
import {BcryptHasher} from '../services/hash.password';
import {JWTService} from '../services/jwt-service';
import {MyUserService} from '../services/user-service';
import {ElasticqueriesController} from './elasticqueries.controller';

interface verifyOtpInterface {
  mobile: string;
  otp: number;
}

interface mobileExists {
  mobile: string;
}

interface ItaskGeoPoint {
  lng: number;
  lat: number;
}

export class CustomerController {
  constructor(
    @repository(CustomerRepository)
    public customerRepository: CustomerRepository,
    @inject('services.Smsotp') protected smsService: Smsotp,
    @inject('repositories.SmsLogRepository') public smsLogRepository: SmsLogRepository,
    @inject('repositories.UserRepository') public userRepository: UserRepository,
    @inject('repositories.OrderRepository') public orderRepository: OrderRepository,
    @inject('repositories.OrderDetailsRepository') public orderDetailsRepository: OrderDetailsRepository,
    @inject('repositories.VendorRepository') public vendorRepository: VendorRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER) public hasher: BcryptHasher,
    @inject(UserServiceBindings.USER_SERVICE) public userService: MyUserService,
    @inject(TokenServiceBindings.TOKEN_SERVICE) public jwtService: JWTService,
    @inject('controllers.ElasticqueriesController') public elasticQueries: ElasticqueriesController,

    @inject(RestBindings.Http.REQUEST)
    private req: Request
  ) { }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @post('/customers', {
    responses: {
      '200': {
        description: 'Customer model instance',
        content: {'application/json': {schema: getModelSchemaRef(Customer)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Customer, {
            title: 'NewCustomer',
            exclude: ['id'],
          }),
        },
      },
    })
    customer: Omit<Customer, 'id'>,
  ): Promise<Customer> {
    return this.customerRepository.create(customer);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @get('/customers/count', {
    responses: {
      '200': {
        description: 'Customer model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(Customer) where?: Where<Customer>,
  ): Promise<Count> {
    return this.customerRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer, PermissionKeys.Mechanic]})
  @get('/customers', {
    responses: {
      '200': {
        description: 'Array of Customer model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Customer, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(Customer) filter?: Filter<Customer>,
  ): Promise<Customer[]> {
    return this.customerRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @patch('/customers', {
    responses: {
      '200': {
        description: 'Customer PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Customer, {partial: true}),
        },
      },
    })
    customer: Customer,
    @param.where(Customer) where?: Where<Customer>,
  ): Promise<Count> {
    return this.customerRepository.updateAll(customer, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @get('/customers/{id}', {
    responses: {
      '200': {
        description: 'Customer model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Customer, {exclude: 'where'}) filter?: FilterExcludingWhere<Customer>
  ): Promise<Customer> {
    return this.customerRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @patch('/customers/{id}', {
    responses: {
      '204': {
        description: 'Customer PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Customer, {partial: true}),
        },
      },
    })
    customer: Customer,
  ): Promise<void> {
    await this.customerRepository.updateById(id, customer);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @put('/customers/{id}', {
    responses: {
      '204': {
        description: 'Customer PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() customer: Customer,
  ): Promise<void> {
    await this.customerRepository.replaceById(id, customer);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @del('/customers/{id}', {
    responses: {
      '204': {
        description: 'Customer DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.customerRepository.deleteById(id);
  }

  // ---------------------------------------changes by deval-----------------------------------------------

  // ==== mobile no exist ====
  @post('/mobile/customer/existence/', {
    responses: {
      '204': {
        description: 'Mobile Number verification',
      },
      '200': {
        description: 'Mobile Number found!',
      },
      '404': {
        description: 'Mobile number not found',
      }
    },
  })
  async findByMobileBody(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'Customer phone exists?',
                properties: {
                  "mobile": {
                    "type": "string"
                  }
                },
                required: ["mobile"],
                additionalProperties: false
              }
            },
            "example": {
              "mobile": "919988776655"
            }
          }
        }
      }
    }) data: mobileExists
  ) {
    const mobile = data.mobile
    return this.customerMobileExistenceHelper(mobile);
  }

  async customerMobileExistenceHelper(mobile: string) {

    // apply check for mobile number existence in customer table first
    const response = await this.customerRepository.find({where: {mobileNo: mobile}});

    // console.log("customer----", response);
    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: 'User/customer mobile no not found!',
        success: false
      }
    }
    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "Customer is blocked!",
        success: false
      }
    }

    let OTP = '';
    for (let i = 0; i < NUM_CHARACTERS_IN_OTP; i++) {
      OTP += OTP_CHARACTERS[Math.floor(Math.random() * OTP_CHARACTERS.length)];
    }
    console.log("otp---", OTP);
    await this.smsLogRepository.create({
      mobile: mobile,
      otp: parseInt(OTP)
    });
    response[0].otp = parseInt(OTP);
    await this.customerRepository.updateById(response[0].id, response[0]);
    return {
      statusCode: 200,
      message: "User/customer found!",
      success: true,
      ...this.callSmsOTPAPI(mobile, parseInt(OTP))
    };
  }

  async callSmsOTPAPI(mobile: string, otp: number): Promise<any> {
    return this.smsService.sendOTP(mobile, otp);
  }

  // ==== customer login by otp verify ===

  @post('/mobile/customer/login', {
    responses: {
      '200': {
        description: 'On successful verification',
        content: {
          'application/json': {
            schema: {
              "example": {
                "message": "OTP verified success",
                "type": "success"
              }
            }
          }
        }
      }
    }
  })
  async verifyOTP(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            definitions: {
              VerifyOTP: {
                title: 'Customer Login',
                properties: {
                  "mobile": {
                    "type": "string"
                  },
                  "otp": {
                    "type": "number"
                  }
                },
                required: ["mobile", "otp"],
                additiletlProperties: false
              }
            },
            "example": {
              "mobile": "919988776655",
              "otp": 12345
            }
          }
        }
      }
    }) data: verifyOtpInterface,
  ): Promise<any> {
    const tx = this.customerRepository.dataSource.beginTransaction({
      isolationLevel: IsolationLevel.READ_COMMITTED,
    });

    // apply check for mobile number existence in customer table first and user table
    // we should specifically check if it's really a customer and not the Admin user.
    const credentials = {mobileNo: "", password: "", RoleName: ""};
    const userExistence = await this.userRepository.find({where: {mobileNo: data.mobile, RoleName: PermissionKeys.Customer}}, {tx});
    const response = await this.customerRepository.find({where: {mobileNo: data.mobile}}, {tx});
    if (response[0] === undefined) {
      return {
        statusCode: 404,
        message: "User/customer mobile no not found!",
        success: false
      }
    }

    if (response[0].isActive === false) {
      return {
        statusCode: 403,
        message: "customer is blocked!",
        success: false
      }
    }

    if (userExistence[0] === undefined) {
      const userData = {mobileNo: data.mobile, password: "ra@123456", RoleName: PermissionKeys.Customer};
      userData.password = await this.hasher.hashPassword(userData.password);
      let crt = await this.userRepository.create(userData);

      credentials.mobileNo = data.mobile;
      credentials.password = "ra@123456";
      credentials.RoleName = PermissionKeys.Customer

    } else if(userExistence[0] != undefined) {
      if (userExistence[0].isActive === false) {
        return {
          statusCode: 403,
          message: "Inactive user!",
          success: false
        }
      }else{
        credentials.mobileNo = data.mobile;
        credentials.password = userExistence[0].password
        credentials.RoleName = PermissionKeys.Customer
      }
    }

    const res = this.serviceOTPVerify(data.mobile, data.otp);


    const returnRes: {success: Boolean, message: string, token: string} =
      {success: false, message: '', token: ''};

    await res.then(logRes => {
      if (!logRes) {
        returnRes.success = false;
        returnRes.message = "Sorry your OTP is wrong!";
        return returnRes;
      } else {
        returnRes.success = true
        returnRes.message = "You are Authorized!"

      }
    })

    if (returnRes.success && userExistence[0] === undefined ) {
      const user = await this.userService.verifyCredentialsV2(credentials);
      const userProfile = this.userService.convertToUserProfile(user);
      const token = await this.jwtService.generateToken(userProfile);
      returnRes.token = token;
    }

    if (returnRes.success && userExistence[0] != undefined) {
      const user = await this.userService.verifyCredentialsV3(credentials);
      const userProfile = this.userService.convertToUserProfile(user);
      const token = await this.jwtService.generateToken(userProfile);
      returnRes.token = token;
    }
    await (await tx).commit();

    return returnRes;
  }

  async serviceOTPVerify(mobile: string, otp: number): Promise<boolean> {
    const smsLog = await this.smsLogRepository.find({where: {mobile: mobile}});
    // console.log("smslog---", smsLog);
    const logOtp = smsLog[smsLog.length - 1].otp;
    if (logOtp === otp)
      return Promise.resolve(true);
    else
      return Promise.resolve(false);
  }


  // =============find mechanics near order =================
  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Customer]})
  @get('/customer/fetchmyinprogressorders', {
    responses: {
      '200': {
        description: 'Customer model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async getMechanicsofOrderId(): Promise<any> {

    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    // console.log("user profile ---", userProfile);
    const id: any = userProfile.id;
    const customerData = await this.userRepository.findById(id);

    // try{
    const orderObject = await this.orderRepository.find({where: {custPhoneNumber: customerData.mobileNo, status: {inq: [4, 5, 6, 7, 8]}}});
    return Promise.resolve(orderObject);
    // if (orderObject) {
    //   if (!orderObject.taskGeopoint) {
    //     return Promise.reject('Task location not found');
    //   }
    //   // =======================
    //   const orderDetailsData = await this.orderDetailsRepository.find({where: {orderId: id}})
    //   if (orderDetailsData[0]) {
    //     const vendorId = orderDetailsData[0].vendorId ? orderDetailsData[0].vendorId : '';
    //     // =======================

    //     const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;

    //     const config = {
    //       type: "service_account",
    //       projectId: "ra-vendor-app-dev",
    //       privateKeyId: "62295439b2fd7093e85e005c37433b48edc82d9f",
    //       privateKey: "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCR8juMR69FmGic\n97GpKIKtCxSBYIWxoJfr+xhcSoFDF/K9xFVmBQGGv8enQsQNJ67mHbkLOCUmxkj8\n9qJar0jvrLKUmU2vrRsM0cn6G3t4lCDUTGxPH0XgBzd+221KUSBHqcAWXLMr8iZt\nFUK6I8u+9RuETHQHQXDjS4CZal48OaiDQUNrmdxfGIr4hdMroJNxU5VUXBT5PNIE\nCZZl6nMpOjMTI+q9ZtXe5BJf0KgMgHHsb2biPBBTLwaKZx30WfsNjOuVVBKlvzIx\nriOZhzIs5Yxg/yeXqXmz4wJ1kHu3EP0GkBPZmqkL040I3YHB031Fcnyjj4r3KC1G\nRa2HOvkdAgMBAAECggEAFyj5iilWBxVIhKBJ8S4cjplTh7RpguaZNTmDhCHOoXcL\nblHZu3bP5zJH3KMbuXqyppHQ65bdTmno6zu4R+vJBz/AlxQ838P4pvAjvSzfSyM2\nknoONgAgdoyuodLwZPq6xKSLdwD+7dpffrABBsjnbEY5N6VqRDx+TZONtMrMaYH/\nbsjMtgIHqR9TQN9Zb51W3FqUrCkhtvKWCU6jyNXbY5N7LPsECfMAtuogE/8ji722\nydeOhswtUBORCT8MDHd2j1JBhJaWR05FL1tPIW708XyDJ1OyaPlxitrcyRFDJmRp\n/BzF9thvsVf2zKiccm9Up/qFIJkxIdPGuNSALgfUAQKBgQDLStZxWI3j6eEzlS4b\nARLxgNleG1HzUEzKJYABYmt+gxbYpsUp4BaNeJGAjvDUl8N2HRO/tPmHG3UL1m0C\nI0BsEdRykO/YRxvPBArqOgdgJgioBQnV4tNbZpVZJa1m3Jtz2tHKyyI6qbh5x7tD\nvZzSfrz9AZT+FTs4lDwzfhP3FQKBgQC3ySZm+kP0PrGF22bTXfr2YLAlukZxNwKd\nocUf23rpyG429z7TpZujhyOHn0Tb2lHLkyPqK9CdAJD97qhzwUJxq/JY8ngL8pzH\nRgs8mp+Qoy8XdvcMeK4Uvmz7IqSNk2FwvUzOezYapaiozVuFB9yyFFEjl8ezmh/y\nBaZmR/h76QKBgFCXeY3zukR5SpMFeAKymUzudL3O/N0Fn3ugBDAIUW8VDvCSpKUm\nNiqdeqlJgYX2KEHh4xtj5mw+YVdxCUQIr5hoNR26Aatu/UJDawRSPuxKB7J8VNrb\nEkkw0NJHkoetu17hh7vqbcZt1DlLCh0fxVTZc5ilkOhtiE20zmzndYjFAoGBAIRX\n9DBpfW+vibRjhsskPOkYPSAd4EX8oASVDldffEZHD57DMlnEQqxiTyKFfVd4Aji/\nTzh8rq+wTbieGG2quEcU0+JbUDkCTwVsmgDdM5Q6/lk+UK6JZIoJin7ZtndArwU5\nO8rgjNhpfGd54bKNM86EtN0Vmjfp/6EPkoDKyNOpAoGBALeiivGviYQ4zSoopZEf\nqOJzZPpNt64VpGZH3frwPBrwzUDF2Qmh2DXjfi7adZak7yLIRQzWJ6TGWt4fVWbh\nN3RReKsrQQclr0h3I3+oswm/3r4Uit+dcMYcCVHmACG11Cc01InTC42nR/b1Ov5/\n6v4+1KOniIaHKR71nJWi+B7/",
    //       clientEmail: "firebase-adminsdk-9lrvp@ra-vendor-app-dev.iam.gserviceaccount.com",
    //       clientId: "105108010927011102915",
    //       authUri: "https://accounts.google.com/o/oauth2/auth",
    //       tokenUri: "https://oauth2.googleapis.com/token",
    //       auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    //       client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-9lrvp%40ra-vendor-app-dev.iam.gserviceaccount.com"
    //     }
    //     if (!firebase.apps.length) {
    //       firebase.initializeApp(config);
    //     }

    //     const firestore = firebase.firestore();
    //     const GeoFireStore = geofirestore.initializeApp(firestore);
    //     const geocollection = GeoFireStore.collection('vendor');

    //     return geocollection.get().then(async (values) => {

    //       let allRequiredMechancis = values.docs.map(doc => ({id: doc.id, lon: doc.data().Locations._long, lat: doc.data().Locations._lat}))

    //       // console.log('all required mechanics--', allRequiredMechancis);

    //       allRequiredMechancis = _.sortBy(allRequiredMechancis, 'dist',).reverse().slice(0, 5);
    //       const mechanicArray = allRequiredMechancis.map(ele => {
    //         return parseInt(ele.id);
    //       })
    //       // console.log("mechanic array ---", mechanicArray);

    //       for (let i = 0; i < allRequiredMechancis.length; i++) {
    //         if (Number(allRequiredMechancis[i].id) == vendorId) {
    //           // console.log("id mathced---", allRequiredMechancis[i])
    //           let response = {
    //             tasklocation: tasklocation,
    //             mechanicLocation: {
    //               lat: allRequiredMechancis[i].lat,
    //               lng: allRequiredMechancis[i].lon
    //             }
    //           }
    //           return Promise.resolve(response);
    //         }
    //       }
    //     }).catch((err) => {
    //       return Promise.reject(err);
    //     });
    //   }
    //   else {
    //     return Promise.reject('order data not found');
    //   }
    // }
    // else {
    //   return Promise.reject('order not Found');
    // }
    // }
    // catch(error){
    //   return {
    // 		statusCode: 500,
    // 		message: "Internal Server Error!",error
    // 	}
    // }
  }


  // Get Customer Order Details
  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Customer]})
  @get('/customer/order/{id}', {
    responses: {
      '200': {
        description: 'Customer model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async customerOrderDetails(
    @param.path.number('id') id: number,
  ): Promise<any> {
    if (!id) {
      return Promise.reject('Order not found');
    }
    try{
      const orderObject = await this.orderRepository.findById(id);
      if(orderObject){
        if(!orderObject.taskGeopoint){
          return Promise.reject('Task location not found');
        }

        const orderDetailsData = await this.orderDetailsRepository.find({where: {orderId: id}})
        if(orderDetailsData[0]){
          const vendorId = orderDetailsData[0].vendorId ? orderDetailsData[0].vendorId : '' ;
          const tasklocation = orderObject.taskGeopoint as ItaskGeoPoint;

          const firestore = firebase.firestore();
          const GeoFireStore = geofirestore.initializeApp(firestore);
          const geocollection = GeoFireStore.collection('vendor');

        return geocollection.get().then(async (values) => {
          let allRequiredMechancis = values.docs.map(doc => ({id: doc.id, lon: doc.data().Locations._long, lat: doc.data().Locations._lat}));

          allRequiredMechancis = _.sortBy(allRequiredMechancis, 'dist',).reverse().slice(0, 5);
          let vendorExist = false

          for (let i = 0; i < allRequiredMechancis.length; i++) {
            if(Number(allRequiredMechancis[i].id) == vendorId){
              vendorExist = true
              let response = {
                tasklocation : tasklocation,
                mechanicLocation : {
                  lat:allRequiredMechancis[i].lat,
                  lng:allRequiredMechancis[i].lon
                }
              }
              return Promise.resolve(response);
            }
          }

          if(!vendorExist){
            return Promise.reject('Vendor not found');
          }
        }).catch((err) => {
          return Promise.reject(err);
        });
        }
        else{
          return Promise.reject('order data not found');
        }
      }
      else{
        return Promise.reject('order not Found');
      }
    }
    catch(error){
      return {
    		statusCode: 500,
    		message: "Internal Server Error!",error
    	}
    }
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Customer]})
  @get('/customerDetail', {
    responses: {
      '200': {
        description: 'Customer model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Customer, {includeRelations: true}),
          },
        },
      },
    },
  })
  async CustomerData():
    Promise<any> {
    const token = this.req.headers.authorization?.split(' ')[1];
    const userProfile = await this.jwtService.verifyToken(token!);
    // console.log("user profile ---", userProfile);
    const id = userProfile.id;
    const customerData = await this.userRepository.findById(id);

    if (customerData) {
      return {
        statusCode: 200,
        message: "Get customer Successfully",
        customerDetails: customerData
      }
    }
    return {
      statusCode: 500,
      message: "Vendor Not found!"
    }
  }
}
