import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {VendorLead} from '../models';
import {VendorLeadRepository} from '../repositories';

export class VendorLeadController {
  constructor(
    @repository(VendorLeadRepository)
    public vendorLeadRepository: VendorLeadRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/vendor-leads', {
    responses: {
      '200': {
        description: 'VendorLead model instance',
        content: {'application/json': {schema: getModelSchemaRef(VendorLead)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorLead, {
            title: 'NewVendorLead',
            exclude: ['id'],
          }),
        },
      },
    })
    vendorLead: Omit<VendorLead, 'id'>,
  ): Promise<VendorLead> {
    return this.vendorLeadRepository.create(vendorLead);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads/count', {
    responses: {
      '200': {
        description: 'VendorLead model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(VendorLead) where?: Where<VendorLead>,
  ): Promise<Count> {
    return this.vendorLeadRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads', {
    responses: {
      '200': {
        description: 'Array of VendorLead model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(VendorLead, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(VendorLead) filter?: Filter<VendorLead>,
  ): Promise<VendorLead[]> {
    return this.vendorLeadRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-leads', {
    responses: {
      '200': {
        description: 'VendorLead PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorLead, {partial: true}),
        },
      },
    })
    vendorLead: VendorLead,
    @param.where(VendorLead) where?: Where<VendorLead>,
  ): Promise<Count> {
    return this.vendorLeadRepository.updateAll(vendorLead, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads/{id}', {
    responses: {
      '200': {
        description: 'VendorLead model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(VendorLead, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(VendorLead, {exclude: 'where'}) filter?: FilterExcludingWhere<VendorLead>
  ): Promise<VendorLead> {
    return this.vendorLeadRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-leads/{id}', {
    responses: {
      '204': {
        description: 'VendorLead PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorLead, {partial: true}),
        },
      },
    })
    vendorLead: VendorLead,
  ): Promise<void> {
    await this.vendorLeadRepository.updateById(id, vendorLead);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/vendor-leads/{id}', {
    responses: {
      '204': {
        description: 'VendorLead PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() vendorLead: VendorLead,
  ): Promise<void> {
    await this.vendorLeadRepository.replaceById(id, vendorLead);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/vendor-leads/{id}', {
    responses: {
      '204': {
        description: 'VendorLead DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.vendorLeadRepository.deleteById(id);
  }
}
