import { authenticate } from '@loopback/authentication';
import { inject } from '@loopback/core';
import { Count, CountSchema, Filter, FilterExcludingWhere, repository, Where } from '@loopback/repository';
import { del, get, getModelSchemaRef, param, patch, post, put, requestBody } from '@loopback/rest';
import moment from 'moment';
import { PermissionKeys } from '../authorization/permission-keys';
import { AdhocServiceQuantityPatch, AUTH_STRATEGY, InvoiceServiceId, serviceQuantityPatch } from '../constants';
import { Invoice } from '../models';
import { InvoiceRepository, OrderRepository, ServiceMasterRepository, TransactionRepository } from '../repositories';

export class InvoiceController {
	constructor(
		@repository(InvoiceRepository) public invoiceRepository: InvoiceRepository,
		@inject('repositories.ServiceMasterRepository') public serviceMasterRepository: ServiceMasterRepository,
		@inject('repositories.OrderRepository') public orderRepository: OrderRepository,
		@inject('repositories.TransactionRepository') public transactionRepository: TransactionRepository
	) {}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@post('/invoices', {
		responses: {
			'200': {
				description: 'Invoice model instance',
				content: { 'application/json': { schema: getModelSchemaRef(Invoice) } }
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Invoice, {
						title: 'NewInvoice',
						exclude: [ 'id' ]
					})
				}
			}
		})
		invoice: Omit<Invoice, 'id'>
	): Promise<Invoice> {
		return this.invoiceRepository.create(invoice);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@get('/invoices/count', {
		responses: {
			'200': {
				description: 'Invoice model count',
				content: { 'application/json': { schema: CountSchema } }
			}
		}
	})
	async count(@param.where(Invoice) where?: Where<Invoice>): Promise<Count> {
		return this.invoiceRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@get('/invoices', {
		responses: {
			'200': {
				description: 'Array of Invoice model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(Invoice, { includeRelations: true })
						}
					}
				}
			}
		}
	})
	async find(@param.filter(Invoice) filter?: Filter<Invoice>): Promise<Invoice[]> {
		return this.invoiceRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@patch('/invoices', {
		responses: {
			'200': {
				description: 'Invoice PATCH success count',
				content: { 'application/json': { schema: CountSchema } }
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Invoice, { partial: true })
				}
			}
		})
		invoice: Invoice,
		@param.where(Invoice) where?: Where<Invoice>
	): Promise<Count> {
		return this.invoiceRepository.updateAll(invoice, where);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin, PermissionKeys.Mechanic ] })
	@get('/invoices/{id}', {
		responses: {
			'200': {
				description: 'Invoice model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(Invoice, { includeRelations: true })
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(Invoice, { exclude: 'where' })
		filter?: FilterExcludingWhere<Invoice>
	): Promise<unknown> {
		const actualInvoice = await this.invoiceRepository.findById(id, filter);
		const transactions = await this.transactionRepository.find({ where: { invoiceId: id } });
		const actualInvoiceJson = actualInvoice.toObject();
		const returnVal = {};
		Object.assign(returnVal, actualInvoiceJson);
		Object.assign(returnVal, { transactions: transactions });
		return returnVal;
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@patch('/invoices/{id}', {
		responses: {
			'204': {
				description: 'Invoice PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(Invoice, { partial: true })
				}
			}
		})
		invoice: Invoice
	): Promise<void> {
		await this.invoiceRepository.updateById(id, invoice);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@put('/invoices/{id}', {
		responses: {
			'204': {
				description: 'Invoice PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() invoice: Invoice): Promise<unknown> {
		const invoiceData = await this.invoiceRepository.findById(id);
		const arr = invoiceData.services!;
		// const serviceId = '';
		const [ serviceId ] = Object.keys(invoice.services![0]);
		const [ serviceQuantity ] = Object.values(invoice.services![0]);
		let searchInd = -1;

		const orderId = invoiceData.orderId;
		const orderRes = await this.orderRepository.findById(orderId!);

		// const dt = new Date(orderRes.bookingTime!);
		// const hr = dt.getHours();
		const dt = moment(orderRes.bookingTime!).utcOffset('+05:30');
		const hr = dt.hour();
		// const min = dt.getMinutes();

		const serviceData = await this.serviceMasterRepository.findById(parseInt(serviceId));
		let amountForService = 0;
		let check = false;
		// currentTime - 0 Night and 1 Day

		// let currentTime;
		if (hr >= 20 && hr < 8) {
			// currentTime = 0;
			if (serviceData.nightCharge > 0) {
				check = true;
				amountForService = serviceData.nightCharge;
			}
		} else {
			// currentTime = 1;
			if (serviceData.dayCharge > 0) {
				check = true;
				amountForService = serviceData.dayCharge;
			}
		}

		if (!check) {
			return {
				success: false,
				message: 'This service is not avaible for this time'
			};
		}

		for (let i = 0; i < arr.length; i++) {
			const [ searchKey ] = Object.keys(arr[i]);
			if (searchKey === serviceId) {
				searchInd = i;
				break;
			}
		}

		// let check = false;
		// check = serviceData.dayCharge > 0 && currentTime == 1 || serviceData.nightCharge > 0 && currentTime == 0;

		if (check) {
			if (searchInd === -1) {
				invoiceData.services!.push(invoice.services![0]);
			} else if (searchInd !== -1) {
				let [ val ] = Object.values(invoiceData.services![searchInd]);
				invoiceData.services!.splice(searchInd, 1);
				val += serviceQuantity;

				const obj: InvoiceServiceId = {};
				obj[serviceId] = val;
				invoiceData.services!.push(obj);
			}

			//TODO: UPDATE THE Transaction Logic
			const amount = amountForService * serviceQuantity * (1 + serviceData.tax / 100);
			invoiceData.amount += amount;
			invoiceData.due += amount;
			await this.invoiceRepository.replaceById(id, invoiceData);
		}
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@del('/invoices-service/{id}', {
		responses: {
			'204': {
				description: 'Delete a particular service from order items i.e. invoiced data'
			}
		}
	})
	async deleteByServiceId(@param.path.number('id') id: number, @requestBody() serviceId: number): Promise<void> {
		const invoiceData = await this.invoiceRepository.findById(id);
		const arr = invoiceData.services!;

		let searchInd = -1;
		for (let i = 0; i < arr.length; i++) {
			const [ searchKey ] = Object.keys(arr[i]);
			if (parseInt(searchKey) === serviceId) {
				searchInd = i;
				break;
			}
		}
		if (searchInd !== -1) {
			arr.splice(searchInd, 1);
		}
		invoiceData.services = arr;
		// Calculate due , amount again
		await this.calculateAmounts(invoiceData);
		return this.invoiceRepository.replaceById(id, invoiceData);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@patch('/invoices-service/{id}', {
		responses: {
			'204': {
				description: 'Patch a particular service from order items i.e. invoiced data'
			}
		}
	})
	async patchByServiceId(@param.path.number('id') id: number, @requestBody() service: serviceQuantityPatch): Promise<void> {
		const invoiceData = await this.invoiceRepository.findById(id);
		const arr = invoiceData.services!;

		let searchInd = -1;
		for (let i = 0; i < arr.length; i++) {
			const [ searchKey ] = Object.keys(arr[i]);
			if (parseInt(searchKey) === service.serviceId) {
				searchInd = i;

				break;
			}
		}

		const serviceMod: InvoiceServiceId = {};
		serviceMod[service.serviceId] = {
			quantity: service.quantity,
			service: await this.serviceMasterRepository.findById(service.serviceId)
		};
		if (searchInd !== -1) {
			arr[searchInd] = serviceMod;
		} else {
			arr.push(serviceMod);
		}
		invoiceData.services = arr;
		// Calculate due , amount again
		await this.calculateAmounts(invoiceData);
		return this.invoiceRepository.replaceById(id, invoiceData);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@patch('/invoices-service/{id}/adhoc', {
		responses: {
			'204': {
				description: 'Patch a particular service from order items i.e. invoiced data'
			}
		}
	})
	async patchByAdhocService(@param.path.number('id') id: number, @requestBody() service: AdhocServiceQuantityPatch): Promise<void> {
		const invoiceData = await this.invoiceRepository.findById(id);
		let arr = invoiceData.adhocServices!;

		let searchInd = -1;
		if (arr !== null) {
			for (let i = 0; i < arr.length; i++) {
				if (arr[i].serviceName === service.serviceName) {
					searchInd = i;
					break;
				}
			}
		}

		const serviceMod = {
			quantity: service.quantity,
			serviceName: service.serviceName,
			tax: service.tax,
			rate: service.rate
		};
		if (searchInd !== -1) {
			arr[searchInd] = serviceMod;
		} else if (!arr) {
			arr = [ serviceMod ];
		} else {
			arr.push(serviceMod);
		}
		console.log(arr);
		invoiceData.adhocServices = arr;
		// Calculate due , amount again
		await this.calculateAmounts(invoiceData);
		return this.invoiceRepository.replaceById(id, invoiceData);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@del('/invoices-service/{id}/adhoc/{serviceName}', {
		responses: {
			'204': {
				description: 'Delete a particular adhoc service from order items i.e. invoiced data'
			}
		}
	})
	async deleteAdhocService(@param.path.number('id') id: number, @param.path.string('serviceName') serviceName: string): Promise<void> {
		const invoiceData = await this.invoiceRepository.findById(id);
		const arr: AdhocServiceQuantityPatch[] = invoiceData.adhocServices!;
		console.log(arr.length);
		let searchInd = -1;
		for (let i = 0; i < arr.length; i++) {
			if (arr[i].serviceName === serviceName) {
				searchInd = i;
				break;
			}
		}
		if (searchInd !== -1) {
			arr.splice(searchInd, 1);
		}
		console.log(arr.length);
		invoiceData.adhocServices = [ ...arr ];
		// Calculate due , amount again
		await this.calculateAmounts(invoiceData);
		return this.invoiceRepository.replaceById(id, invoiceData);
	}

	@authenticate(AUTH_STRATEGY, { required: [ PermissionKeys.Admin ] })
	@del('/invoices/{id}', {
		responses: {
			'204': {
				description: 'Invoice DELETE success'
			}
		}
	})
	async deleteById(@param.path.number('id') id: number): Promise<void> {
		await this.invoiceRepository.deleteById(id);
	}

	async calculateAmounts(invoiceData: Invoice): Promise<unknown> {
		const orderId = invoiceData.orderId;
		const orderRes = await this.orderRepository.findById(orderId!);

		// const dt = new Date(orderRes.bookingTime!);
		// const hr = dt.getHours();
		const dt = moment(orderRes.bookingTime!).utcOffset('+05:30');
		const hr = dt.hour();
		const currentTime = hr >= 20 || hr < 8 ? 1 : 0;
		let amount = 0;
		const { services, adhocServices } = invoiceData;
		services.forEach((item) => {
			const [ serviceObj ] = Object.values(item);
			const serviceQuantity = serviceObj.quantity;
			const serviceItem = serviceObj.service;
			const rate = currentTime ? serviceItem.nightCharge : serviceItem.dayCharge;
			amount += rate * serviceQuantity * (1 + serviceItem.tax / 100);
		});
		if (adhocServices) {
			adhocServices.forEach((serviceObj: any) => {
				amount += serviceObj.rate * serviceObj.quantity * (1 + serviceObj.tax / 100);
			});
		}
		invoiceData.amount = amount;
		invoiceData.due = invoiceData.amount - invoiceData.paid;
		return invoiceData;
	}
}
