// Uncomment these imports to begin using these cool features!

import * as admin from 'firebase-admin';

// moment.utc(new Date()).format('yyyyMMDD/hhmmss')
// import * as moment from 'moment';

// import {inject} from '@loopback/context';


export class FirebasecController {
  private db: unknown;
  constructor() {
    const serviceAccount = require("/Users/pawan/development/readyassist/personalgoogleaccountcredentials/prefab-mountain-509-firebase-adminsdk-yxwdu-9c0743bea9.json");
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      // databaseURL: "https://prefab-mountain-509.firebaseio.com"
    });
    this.db = admin.firestore();
  }

  // @get('/firebaseHello')
  // async dummyFunction() {
  //   const vhref = this.db.collection('vendorhistory').get();
  //   // await vhref.get().then((doc) => {
  //   //   if (!doc.exists) {
  //   //     console.log('No such document!');
  //   //   } else {
  //   //     console.log('Document data:', doc.data());
  //   //   }
  //   // }).catch((err) => {
  //   //   console.log('Error getting document', err);
  //   // })
  //   return (await vhref).docs;
  // }
}
