import {authenticate} from '@loopback/authentication';
import {repository} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Shift, VendorLead} from '../models';
import {VendorLeadRepository} from '../repositories';

export class VendorLeadShiftController {
  constructor(
    @repository(VendorLeadRepository)
    public vendorLeadRepository: VendorLeadRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads/{id}/shift', {
    responses: {
      '200': {
        description: 'Shift belonging to VendorLead',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Shift)},
          },
        },
      },
    },
  })
  async getShift(
    @param.path.number('id') id: typeof VendorLead.prototype.id,
  ): Promise<Shift> {
    return this.vendorLeadRepository.shift(id);
  }
}
