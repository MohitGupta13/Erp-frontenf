// import {
//     Count,
//     CountSchema,
//     Filter,
//     FilterExcludingWhere,
//     repository,
//     Where,
// } from '@loopback/repository';

import {authenticate} from '@loopback/authentication';
import {inject} from "@loopback/context";
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {get, getModelSchemaRef, param, patch, post, put, Request, requestBody, Response, RestBindings} from '@loopback/rest';
import fs from 'fs';
import multer from "multer";
import path from "path";
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY, tmpFileDir} from '../constants';
import {File} from "../models";
import {FileRepository, OrderDetailsRepository, VendorRepository} from '../repositories';
import {S3FileUploader} from '../utils';

// ToDo: refactor code with below interfaces at the time of refactoring

// interface MyFile {
//     originalname: string;
//     path: PathLike;
//     mimetype: string;
//     mobileno: string;
//     filetype: string;
// }

// interface MyDetails {
//     ETag: string;
//     Location: string;
//     key: string;
//     Key: string;
//     Bucket: String;
// }

export class FileController {
    constructor(
        @repository(FileRepository)
        public fileRepository: FileRepository,
        @inject(RestBindings.Http.RESPONSE)
        public res: Response,
        @inject('repositories.VendorRepository')
        public vendorRepository: VendorRepository,
        @inject('repositories.OrderDetailsRepository')
        public orderDetailsRepository: OrderDetailsRepository,
    ) {
    }

    async generateRandomString(): Promise<string> {
        const len = 10;
        const charSet = 'abcdefghijklmnopqrstuvwxyz0123456789';
        let randomString = '';
        for (let i = 0; i < len; i++) {
            const randomPoz = Math.floor(Math.random() * charSet.length);
            randomString += charSet.substring(randomPoz, randomPoz + 1);
        }
        return randomString;
    }

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @post('/files/upload/{mobileno}/vendor')
    async uploadFile(@requestBody({
        description: 'multipart/form-data value.',
        required: true,
        content: {
            'multipart/form-data': {
                // Skip body parsing
                'x-parser': 'stream',
                schema: {type: 'object'},
            },
        },
    })
    request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
        @param.path.string('mobileno') mobileno: string,
        @param.query.string('fileType') fileType: string,
    ): Promise<Object> {

        if (!fs.existsSync(tmpFileDir)) {
            fs.mkdirSync(tmpFileDir);

        }

        // const storage = memoryStorage();
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, tmpFileDir)
            },
            filename: function (req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
            }
        });
        const upload = multer({storage}).single('attachment');

        return new Promise((resolve, reject) => {

            // eslint-disable-next-line @typescript-eslint/no-misused-promises
            upload(request, response, async (err: unknown) => {

                if (err) reject(err);

                if (!request.file) {
                    reject('No files given!');
                } else {
                    const fileObj = request.file;
                    const name = fileObj.originalname;
                    const parts = name.split('.');
                    const extension = parts[parts.length - 1];
                    // ToDo: put a mobile number as an argument later
                    const tempstring = await this.generateRandomString();
                    const fileName = mobileno + "/" + tempstring + name;
                    resolve(new S3FileUploader().uploadFile(fileName, 'ra-vendor-' + process.env.NODE_ENV, fileObj.path).then(async (details: AWS.S3.ManagedUpload.SendData) => {
                        // details will be like this
                        // {
                        //     ETag: '"13345026b7e51ef76d5e4e0169b7811d"',
                        //     Location: 'https://ra-vendor-development.s3.amazonaws.com/9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     key: '9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     Key: '9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     Bucket: 'ra-vendor-development'
                        //   }
                        try {
                            fs.unlinkSync(tmpFileDir + fileName);
                        } catch (error) {
                            console.log("Error while deleting the file!");
                        }

                        const vendorCreated = await this.vendorRepository.findOne({where: {mobile: mobileno}});
                        let vendorId = null;
                        if (vendorCreated == null) {
                            vendorId = null;
                        } else {
                            vendorId = vendorCreated.getId();
                        }

                        return this.fileRepository.create({
                            path: details.Key,
                            extension: extension,
                            displayName: name,
                            mimeType: fileObj.mimetype,
                            bucketName: details.Bucket,
                            vendor: vendorId,
                            fileType: fileType
                        });

                    }))
                }
            });
        });
    }

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @get('/files/count', {
        responses: {
            '200': {
                description: 'File model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(File) where?: Where<File>,
    ): Promise<Count> {
        return this.fileRepository.count(where);
    }

    @get('/files', {
        responses: {
            '200': {
                description: 'Array of File model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            items: getModelSchemaRef(File, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(
        @param.filter(File) filter?: Filter<File>,
    ): Promise<File[]> {
        return this.fileRepository.find(filter);
    }
    //
    // @patch('/files', {
    //     responses: {
    //         '200': {
    //             description: 'File PATCH success count',
    //             content: {'application/json': {schema: CountSchema}},
    //         },
    //     },
    // })
    // async updateAll(
    //     @requestBody({
    //         content: {
    //             'application/json': {
    //                 schema: getModelSchemaRef(File, {partial: true}),
    //             },
    //         },
    //     })
    //         file: File,
    //     @param.where(File) where?: Where<File>,
    // ): Promise<Count> {
    //     return this.fileRepository.updateAll(file, where);
    // }
    //

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @get('/files/{id}', {
        responses: {
            '200': {
                description: 'File model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(File, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.number('id') id: number,
        @param.filter(File, {exclude: 'where'}) filter?: FilterExcludingWhere<File>
    ): Promise<File> {
        return this.fileRepository.findById(id, filter);
    }

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @patch('/files/{id}', {
        responses: {
            '204': {
                description: 'File PATCH success',
            },
        },
    })
    async updateById(
        @param.path.number('id') id: number,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(File, {partial: true}),
                },
            },
        })
        file: File,
    ): Promise<void> {
        await this.fileRepository.updateById(id, file);
    }

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @put('/files/{id}', {
        responses: {
            '204': {
                description: 'File PUT success',
            },
        },
    })
    async replaceById(
        @param.path.number('id') id: number,
        @requestBody() file: File,
    ): Promise<void> {
        await this.fileRepository.replaceById(id, file);
    }
    //
    // @del('/files/{id}', {
    //     responses: {
    //         '204': {
    //             description: 'File DELETE success',
    //         },
    //     },
    // })
    // async deleteById(@param.path.number('id') id: number): Promise<void> {
    //     await this.fileRepository.deleteById(id);
    // }

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
    @post('/mobile/files/upload/order/{id}/vehicle')
    async uploadFileMobile(@requestBody({
        description: 'multipart/form-data value.',
        required: true,
        content: {
            'multipart/form-data': {
                // Skip body parsing
                'x-parser': 'stream',
                schema: {type: 'object'},
            },
        },
    })
    request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
        @param.path.string('id') orderId: string,
        @param.query.string('fileType') fileType: string,
    ): Promise<Object> {

        if (!fs.existsSync(tmpFileDir)) {
            fs.mkdirSync(tmpFileDir);
        }

        // const storage = memoryStorage();
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, tmpFileDir)
            },
            filename: function (req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
            }
        });

        const upload = multer({storage}).single('attachement');

        return new Promise((resolve, reject) => {

            upload(request, response, async (err: any) => {
                if (err) reject(err);

                if (!request.file) {
                    reject('No files given!');
                } else {
                    const fileObj = request.file;
                    const name = fileObj.originalname;
                    const parts = name.split('.');
                    const extension = parts[parts.length - 1];
                    // ToDo: put a mobile number as an argument later
                    const tempstring = await this.generateRandomString();
                    const fileName = orderId + "/" + tempstring + name;
                    resolve(new S3FileUploader().uploadFile(fileName, 'ra-order-' + process.env.NODE_ENV, fileObj.path).then(async (details: AWS.S3.ManagedUpload.SendData) => {
                        // details will be like this
                        // {
                        //     ETag: '"13345026b7e51ef76d5e4e0169b7811d"',
                        //     Location: 'https://ra-order-development.s3.amazonaws.com/9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     key: '9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     Key: '9766003668/frfoakqx5m84219068_2894345294117738_5949801290157522944_o.jpg',
                        //     Bucket: 'ra-order-development'
                        //   }
                        try {
                            fs.unlinkSync(tmpFileDir + fileName);
                        } catch (error) {
                            console.log("Error while deleting the file!");
                        }
                        const orderData = await this.orderDetailsRepository.findById(parseInt(orderId));

                        const fileCreated = await this.fileRepository.create({
                            path: details.Key,
                            extension: extension,
                            displayName: name,
                            mimeType: fileObj.mimetype,
                            bucketName: details.Bucket,
                            vendor: orderData.vendorId,
                            fileType: fileType
                        });
                        await orderData.files.push(fileCreated.id!);
                        await this.orderDetailsRepository.updateById(parseInt(orderId), orderData);
                        return {
                            statusCode: 200,
                            message: "Upload successfully",
                            files: fileCreated
                        }
                    }))
                }
            });
        });
    }



    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.Mechanic]})
    @get('/files/download/{id}', {
        responses: {
            '200': {
                description: 'File model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(File, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async downnloadFile(
        @param.path.number('id') id: number,
    ) {
        const f = await this.fileRepository.findById(id);
        const fileData = await new S3FileUploader().downloadFile(f.path, f.bucketName, "client");
        this.res.status(200).contentType(f.mimeType).attachment(f.displayName).send(fileData);
    }



    //open api for prifile download for pwa
    @get('/profile/{id}', {
        responses: {
            '200': {
                description: 'File model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(File, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async downnloadFile1(
        @param.path.number('id') id: number,
    ) {
        const f = await this.fileRepository.findById(id);
        const fileData = await new S3FileUploader().downloadFile(f.path, f.bucketName, "client");
        this.res.status(200).contentType(f.mimeType).attachment(f.displayName).send(fileData);
    }

    // brand image upload

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @post('/files/upload/brand')
    async uploadBrand(@requestBody({
        description: 'multipart/form-data value.',
        required: true,
        content: {
            'multipart/form-data': {
                // Skip body parsing
                'x-parser': 'stream',
                schema: {type: 'object'},
            },
        },
    })
    request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ): Promise<Object> {

        if (!fs.existsSync(tmpFileDir)) {
            fs.mkdirSync(tmpFileDir);
        }

        // const storage = memoryStorage();
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, tmpFileDir)
            },
            filename: function (req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
            }
        });
        const upload = multer({storage}).single('attachment');

        return new Promise((resolve, reject) => {

            // eslint-disable-next-line @typescript-eslint/no-misused-promises
            upload(request, response, async (err: unknown) => {

                if (err) reject(err);

                if (!request.file) {
                    reject('No files given!');
                } else {
                    const fileObj = request.file;
                    const name = fileObj.originalname;
                    const parts = name.split('.');
                    const extension = parts[parts.length - 1];
                    // ToDo: put a mobile number as an argument later
                    const tempstring = await this.generateRandomString();
                    const fileName = tempstring + name;
                    resolve(new S3FileUploader().uploadFile(fileName, 'ra-brand-' + process.env.NODE_ENV, fileObj.path).then((details: AWS.S3.ManagedUpload.SendData) => {
                        try {
                            fs.unlinkSync(tmpFileDir + fileName);
                        } catch (error) {
                            console.log("Error while deleting the file!");
                        }
                        return this.fileRepository.create({
                            path: details.Key,
                            extension: extension,
                            displayName: name,
                            mimeType: fileObj.mimetype,
                            bucketName: details.Bucket
                        })
                    }))
                }
            });
        });
    }


    // vehicle image upload

    @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
    @post('/files/upload/vehicle')
    async uploadVehicle(@requestBody({
        description: 'multipart/form-data value.',
        required: true,
        content: {
            'multipart/form-data': {
                // Skip body parsing
                'x-parser': 'stream',
                schema: {type: 'object'},
            },
        },
    })
    request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ): Promise<Object> {

        if (!fs.existsSync(tmpFileDir)) {
            fs.mkdirSync(tmpFileDir);
        }

        // const storage = memoryStorage();
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, tmpFileDir)
            },
            filename: function (req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
            }
        });
        const upload = multer({storage}).single('attachment');

        return new Promise((resolve, reject) => {

            // eslint-disable-next-line @typescript-eslint/no-misused-promises
            upload(request, response, async (err: unknown) => {

                if (err) reject(err);

                if (!request.file) {
                    reject('No files given!');
                } else {
                    const fileObj = request.file;
                    const name = fileObj.originalname;
                    const parts = name.split('.');
                    const extension = parts[parts.length - 1];
                    // ToDo: put a mobile number as an argument later
                    const tempstring = await this.generateRandomString();
                    const fileName = tempstring + name;
                    resolve(new S3FileUploader().uploadFile(fileName, 'ra-vehicle-' + process.env.NODE_ENV, fileObj.path).then((details: AWS.S3.ManagedUpload.SendData) => {
                        try {
                            fs.unlinkSync(tmpFileDir + fileName);
                        } catch (error) {
                            console.log("Error while deleting the file!");
                        }
                        return this.fileRepository.create({
                            path: details.Key,
                            extension: extension,
                            displayName: name,
                            mimeType: fileObj.mimetype,
                            bucketName: details.Bucket
                        })
                    }))
                }
            });
        });
    }
}
