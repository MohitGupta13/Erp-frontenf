import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {ClientMaster, VendorSelfServeMapping} from '../models';
import {ClientMasterRepository, VendorRepository, VendorSelfServeMappingRepository} from '../repositories';

export class VendorSelfServeMappingController {
  constructor(
    @repository(VendorSelfServeMappingRepository)
    public vendorSelfServeMappingRepository: VendorSelfServeMappingRepository,
    @repository(VendorRepository)
    public vendorRepository: VendorRepository,
    @repository(ClientMasterRepository)
    public clientMasterRepository: ClientMasterRepository
  ) { }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/vendor-self-serve-mappings', {
    responses: {
      '200': {
        description: 'VendorSelfServeMapping model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(VendorSelfServeMapping),
          },
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorSelfServeMapping, {
            title: 'NewVendorSelfServeMapping',
            exclude: ['id'],
          }),
        },
      },
    })
    vendorSelfServeMapping: Omit<VendorSelfServeMapping, 'id'>,
  ): Promise<VendorSelfServeMapping> {
    return this.vendorSelfServeMappingRepository.create(vendorSelfServeMapping);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/vendor-self-serve-mappings-array', {
    responses: {
      '200': {
        description: 'VendorSelfServeMapping model instance',
        content: {
          'application/json': {
            schema:{
              type: 'array',
              items : getModelSchemaRef(VendorSelfServeMapping)
            }
          },
        },
      },
    },
  })
  async createArray(
    @requestBody.array({
      content: {
        'application/json': {
          schema: {
            type:'array',
            default:VendorSelfServeMapping,
            items: {
              'x-ts-type': VendorSelfServeMapping,
            },
          },
        },
      },
    })
    vendorSelfServeMapping: VendorSelfServeMapping[],
  ): Promise<any> {

    return this.vendorSelfServeMappingRepository.createAll(vendorSelfServeMapping);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-self-serve-mappings/count', {
    responses: {
      '200': {
        description: 'VendorSelfServeMapping model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(VendorSelfServeMapping) where?: Where<VendorSelfServeMapping>,
  ): Promise<Count> {
    return this.vendorSelfServeMappingRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-self-serve-mappings', {
    responses: {
      '200': {
        description: 'Array of VendorSelfServeMapping model instances',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              items: getModelSchemaRef(VendorSelfServeMapping, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(VendorSelfServeMapping)
    filter?: Filter<VendorSelfServeMapping>,
  ): Promise<VendorSelfServeMapping[]> {
    return this.vendorSelfServeMappingRepository.find(filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-client-details', {
    responses: {
      '200': {
        description: 'Array of Vendor Client details',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(ClientMaster, {
                includeRelations: true,
              }),
            },
          },
        },
      },
    },
  })
  async findClientDetails(
    @param.filter(ClientMaster)
    filter?: Filter<ClientMaster>,
  ): Promise<ClientMaster[]> {
    return this.clientMasterRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-self-serve-mappings', {
    responses: {
      '200': {
        description: 'VendorSelfServeMapping PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorSelfServeMapping, {partial: true}),
        },
      },
    })
    vendorSelfServeMapping: VendorSelfServeMapping,
    @param.where(VendorSelfServeMapping) where?: Where<VendorSelfServeMapping>,
  ): Promise<Count> {
    return this.vendorSelfServeMappingRepository.updateAll(
      vendorSelfServeMapping,
      where,
    );
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-self-serve-mappings/{id}', {
    responses: {
      '200': {
        description: 'VendorSelfServeMapping model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(VendorSelfServeMapping, {
              includeRelations: true,
            }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(VendorSelfServeMapping, {exclude: 'where'})
    filter?: FilterExcludingWhere<VendorSelfServeMapping>,
  ): Promise<VendorSelfServeMapping> {
    return this.vendorSelfServeMappingRepository.findById(id, filter);
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/vendor-self-serve-mappings/{id}', {
    responses: {
      '204': {
        description: 'VendorSelfServeMapping PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(VendorSelfServeMapping, {partial: true}),
        },
      },
    })
    vendorSelfServeMapping: VendorSelfServeMapping,
  ): Promise<void> {
    await this.vendorSelfServeMappingRepository.updateById(
      id,
      vendorSelfServeMapping,
    );
  }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/vendor-self-serve-mappings', {
    responses: {
      '204': {
        description: 'VendorSelfServeMapping PUT success',
      },
    },
  })
  async replaceById(
    @requestBody() vendorSelfServeMapping: VendorSelfServeMapping,
  ): Promise<void> {

    let vendorMapping = await this.vendorSelfServeMappingRepository.find({where:{vid:vendorSelfServeMapping.vid,cid:vendorSelfServeMapping.cid},fields:{id:true,createdAt:true,updatedAt:true}});
    let dt = new Date();
    let now = dt.getFullYear() + "/" + (dt.getMonth() + 1) +"/"+dt.getDate() + " "+dt.getHours()  + ":"+dt.getMinutes()  + ":"+dt.getSeconds();

    if(vendorMapping[0].id != undefined){
      vendorSelfServeMapping.createdAt = vendorMapping[0].createdAt;
      vendorSelfServeMapping.updatedAt = now;
      await this.vendorSelfServeMappingRepository.replaceById(
        vendorMapping[0].id,
        vendorSelfServeMapping,
      );
    }


  }

  // @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  // @del('/vendor-self-serve-mappings/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'VendorSelfServeMapping DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.vendorSelfServeMappingRepository.deleteById(id);
  // }
}
