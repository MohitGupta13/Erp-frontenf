import {authenticate} from '@loopback/authentication';
import {repository} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Team, VendorLead} from '../models';
import {VendorLeadRepository} from '../repositories';

export class VendorLeadTeamController {
  constructor(
    @repository(VendorLeadRepository)
    public vendorLeadRepository: VendorLeadRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/vendor-leads/{id}/team', {
    responses: {
      '200': {
        description: 'Team belonging to VendorLead',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Team)},
          },
        },
      },
    },
  })
  async getTeam(
    @param.path.number('id') id: typeof VendorLead.prototype.id,
  ): Promise<Team> {
    return this.vendorLeadRepository.team(id);
  }
}
