// Uncomment these imports to begin using these cool features!

import {ApiResponse, Client, RequestParams} from '@elastic/elasticsearch';
import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {get, param} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Elasticqueries} from '../services/elasticqueries.service';
const client = new Client({node: process.env.ES_HOST});

// import {inject} from '@loopback/context';


export class ElasticqueriesController {
  constructor(
    @inject('services.Elasticqueries') protected esService: Elasticqueries,
  ) {
  }

  // @get('/ralocations')
  // async find() {
  //   return this.callGetES('/ralocations/_search');
  // }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin,PermissionKeys.Customer, PermissionKeys.Mechanic]})
  @get('/ralocations/{lon}/{lat}')
  async findPolygonsWithPointInIt(
    @param.path.float('lon') lon: number,
    @param.path.float('lat') lat: number,
  ) {
    const esBody: RequestParams.Search = {
      index: 'ralocation',
      body: {
        query: {
          bool: {
            must: {match_all: {}},
            filter: {
              geo_shape: {
                geofence: {
                  shape: {
                    type: "point",
                    coordinates: [
                      lon,
                      lat
                    ]
                  },
                  "relation": "contains"
                }
              }
            }
          }
        }
      }
    };

    const abc = await client.search(esBody).then((data: ApiResponse) => {
      return data.body.hits.hits;
    }).catch((err: Error) => {
      return err;
    });

    return abc;
  }


  // keep this api open as this is for entering into the service.
  @get('/pwa/ralocations/{lon}/{lat}')
  async findLocationIdIfServiceable(
    @param.path.float('lon') lon: number,
    @param.path.float('lat') lat: number,
  ) {
    const esBody: RequestParams.Search = {
      index: 'ralocation',
      body: {
        query: {
          bool: {
            must: {match_all: {}},
            filter: {
              geo_shape: {
                geofence: {
                  shape: {
                    type: "point",
                    coordinates: [
                      lon,
                      lat
                    ]
                  },
                  "relation": "contains"
                }
              }
            }
          }
        }
      }
    };

    const abc = await client.search(esBody).then((data: ApiResponse) => {

      return data.body.hits.hits;
    }).catch((err: Error) => {
      return err;
    });

    // const responseJson = {
    //   locationIds: []
    // };

    if (abc.length > 0) {
      // means locations found
      return {
        locationIds: [abc[0]._id]
      }
    }
    // if there's nothing then send empty response.
    return {
      locationIds: []
    }
  }

  // async callGetES(url: string) {
  //   return this.esService.get(url);
  // }

  // async callGetWithBodyES(url: string, body: object) {
  //   return this.esService.getWithBody(url, body);
  // }
}
