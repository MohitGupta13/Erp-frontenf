import {authenticate} from '@loopback/authentication';
import {inject} from '@loopback/core';
import {
  Filter,

  repository
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param,
  post,

  requestBody
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Coupon} from '../models';
import {CouponRepository, CouponTransRepository, UserRepository} from '../repositories';


export class CouponController {
  constructor(
    @repository(CouponRepository)
    public couponRepository: CouponRepository,

    @inject('repositories.UserRepository')
    public userRepository: UserRepository,

    @inject('repositories.CouponTransRepository')
    public couponTransRepository: CouponTransRepository,
  ) {}

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/coupons', {
    responses: {
      '200': {
        description: 'Coupon model instance',
        content: {'application/json': {schema: getModelSchemaRef(Coupon)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Coupon, {
            title: 'NewCoupon',
            exclude: ['id'],
          }),
        },
      },
    })
    coupon: Omit<Coupon, 'id'>,
  ): Promise<Coupon> {
    return this.couponRepository.create(coupon);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/coupons/{coupon}', {
    responses: {
      '200': {
        description: 'Check Coupon code'
      },
    },
  })
  async checkCoupon(
    @param.path.string('coupon') coupon: string,
    @requestBody({
      content: {
        'application/json': {
          title: 'Data For Coupon Apply'
        }
      }
    })
    body: any
  ): Promise<any> {

    // check 1: check for the coupon code in DB
    const couponRes = await this.couponRepository.find({where: {couponCode: coupon}});

    if (couponRes[0] == undefined) {
      return {
        success: false,
        statusCode: 404,
        message: "Coupon Code not exists"
      }
    }

    const startDate: string = couponRes[0].startDate;
    const expiryDate: string = couponRes[0].expiryDate;
    const currentDate: string = Date.now().toString();

    // check 2: check the time
    if (expiryDate < currentDate || currentDate < startDate) {
      return {
        success: false,
        statusCode: 404,
        message: "Coupon Code is not active due to time"
      }
    }

    // check 3: check the status of coupon
    if (!couponRes[0].isActive) {
      return {
        success: false,
        statusCode: 404,
        message: "Coupon Code is not active"
      }
    }

    // check 4: check for the minimum purchase value
    if (body.amount < couponRes[0].minPurchaseValue) {
      return {
        success: false,
        statusCode: 404,
        message: "You have to buy of at least " + couponRes[0].minPurchaseValue
      }
    }


    // check 5: check the limit of coupon
    if (couponRes[0].limit == 0) {
      return {
        success: false,
        statusCode: 404,
        message: "Coupon is already use upto it's maximum limit "
      }
    }

    // check 6: is Specific check up
    const userRes = await this.userRepository.find({where: {mobileNo: body.mobile}});
    if (couponRes[0].isSpecific) {
      if (userRes[0] == undefined) {
        return {
          success: false,
          statusCode: 404,
          message: "User doesn't exitsts with thie mobile No "
        }
      }


      // check 7: User is valid to use this coupon
      let checkup: Boolean = false;
      couponRes[0].userId!.forEach(ele => {
        if (ele == userRes[0].id) {
          checkup = true;
        }
      });

      if (!checkup) {
        return {
          success: false,
          statusCode: 404,
          message: "User can't use this coupon"
        }
      }
    }

    // check 8: if not specific then save user into the DB
    else if (!couponRes[0].isSpecific) {
      let alreadyExists: Boolean = false;
      couponRes[0].userId!.forEach(ele => {
        if (ele == userRes[0].id) {
          alreadyExists = true;
        }
      })
      if (!alreadyExists) {
        couponRes[0].userId!.push(userRes[0].id!);
      }
    }

    // check 9: Update the coupon limit
    if (couponRes[0].limit != -1) {
      couponRes[0].limit--;
    }

    // check 10: Type of discount if true then fixed if false then varies
    let discount: number = couponRes[0].perOfDiscount;
    if (!couponRes[0].type) {
      discount = Math.round(Math.random() * discount * 100);
    }

    let discountAfterTran: number = (discount * body.amount) / 100;
    if (couponRes[0].maxDiscountValue < discountAfterTran) {
      discountAfterTran = couponRes[0].maxDiscountValue;
    }

    await this.couponTransRepository.create({
      CouponCode: couponRes[0].couponCode,
      usedBy: userRes[0].id,
    })

    await this.couponRepository.updateById(couponRes[0].id, couponRes[0]);
    return {
      success: true,
      statusCode: 200,
      message: "Coupon Code Apply Successfully",
      discount: discountAfterTran
    }

  }

  // @get('/coupons/count', {
  //   responses: {
  //     '200': {
  //       description: 'Coupon model count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async count(
  //   @param.where(Coupon) where?: Where<Coupon>,
  // ): Promise<Count> {
  //   return this.couponRepository.count(where);
  // }

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/coupons', {
    responses: {
      '200': {
        description: 'Array of Coupon model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Coupon, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(Coupon) filter?: Filter<Coupon>,
  ): Promise<Coupon[]> {
    return this.couponRepository.find(filter);
  }

  // @patch('/coupons', {
  //   responses: {
  //     '200': {
  //       description: 'Coupon PATCH success count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Coupon, {partial: true}),
  //       },
  //     },
  //   })
  //   coupon: Coupon,
  //   @param.where(Coupon) where?: Where<Coupon>,
  // ): Promise<Count> {
  //   return this.couponRepository.updateAll(coupon, where);
  // }

  // @get('/coupons/{id}', {
  //   responses: {
  //     '200': {
  //       description: 'Coupon model instance',
  //       content: {
  //         'application/json': {
  //           schema: getModelSchemaRef(Coupon, {includeRelations: true}),
  //         },
  //       },
  //     },
  //   },
  // })
  // async findById(
  //   @param.path.number('id') id: number,
  //   @param.filter(Coupon, {exclude: 'where'}) filter?: FilterExcludingWhere<Coupon>
  // ): Promise<Coupon> {
  //   return this.couponRepository.findById(id, filter);
  // }

  // @patch('/coupons/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'Coupon PATCH success',
  //     },
  //   },
  // })
  // async updateById(
  //   @param.path.number('id') id: number,
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Coupon, {partial: true}),
  //       },
  //     },
  //   })
  //   coupon: Coupon,
  // ): Promise<void> {
  //   await this.couponRepository.updateById(id, coupon);
  // }

  // @put('/coupons/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'Coupon PUT success',
  //     },
  //   },
  // })
  // async replaceById(
  //   @param.path.number('id') id: number,
  //   @requestBody() coupon: Coupon,
  // ): Promise<void> {
  //   await this.couponRepository.replaceById(id, coupon);
  // }

  // @del('/coupons/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'Coupon DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.couponRepository.deleteById(id);
  // }
}
