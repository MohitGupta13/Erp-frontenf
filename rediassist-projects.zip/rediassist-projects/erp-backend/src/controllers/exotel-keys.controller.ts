// Uncomment these imports to begin using these cool features!

import {authenticate} from '@loopback/authentication';
import {get} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';



interface ExotelAPIKeys {
  status: number,
  data: {
    APIKEY: string,
    APITOKEN: string,
  }
}

export class ExotelKeysController {

  constructor() {}

  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Mechanic]})
  @get('/exotelapikeys', {
    responses: {
      '200': {
        description: 'Exotel API Keys',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                status: {
                  type: 'number',
                },
                data: {
                  type: 'object',
                  properties: {
                    APIKEY: {
                      type: 'string'
                    },
                    APITOKEN: {
                      type: 'string',
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  })
  async exotelAPIKeys(): Promise<ExotelAPIKeys> {

    // later if required replace this with database call

    const exotelAPIKEYS: ExotelAPIKeys = {
      status: 200,
      data: {
        APIKEY: process.env.EXOTEL_API_KEY ?? '',
        APITOKEN: process.env.EXOTEL_API_TOKEN ?? '',
      }
    }

    return exotelAPIKEYS;
  }

}
