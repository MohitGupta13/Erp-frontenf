import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {PaymentTypes} from '../models';
import {PaymentTypesRepository} from '../repositories';

export class PaymentTypeController {
  constructor(
    @repository(PaymentTypesRepository) public paymentTypesRepository: PaymentTypesRepository,
  ) {}

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin]
  })
  @post('/payment-types', {
    responses: {
      '200': {
        description: 'PaymentTypes model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(PaymentTypes)
          }
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PaymentTypes, {
            title: 'NewPaymentTypes',
            exclude: ['id'],
          }),
        },
      },
    }) paymentTypes: Omit<PaymentTypes, 'id'>,
  ): Promise<PaymentTypes> {
    return this.paymentTypesRepository.create(paymentTypes);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin]
  })
  @get('/payment-types/count', {
    responses: {
      '200': {
        description: 'PaymentTypes model count',
        content: {
          'application/json': {
            schema: CountSchema
          }
        },
      },
    },
  })
  async count(
    @param.where(PaymentTypes) where?: Where<PaymentTypes>,
  ): Promise<Count> {
    return this.paymentTypesRepository.count(where);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin, PermissionKeys.Mechanic, PermissionKeys.AreaManager, PermissionKeys.QualityUser]
  })
  @get('/payment-types', {
    responses: {
      '200': {
        description: 'Array of PaymentTypes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(PaymentTypes, {
                includeRelations: true
              }),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(PaymentTypes) filter?: Filter<PaymentTypes>,
  ): Promise<PaymentTypes[]> {
    return this.paymentTypesRepository.find(filter);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin, PermissionKeys.Mechanic]
  })
  @get('/mobile/payment-types', {
    responses: {
      '200': {
        description: 'Array of PaymentTypes model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(PaymentTypes, {
                includeRelations: true
              }),
            },
          },
        },
      },
    },
  })
  async findMobile(
    @param.filter(PaymentTypes) filter?: Filter<PaymentTypes>,
  ): Promise<any> {
    const paymentMethods = await this.paymentTypesRepository.find(filter);
    if (paymentMethods) {
      return {
        statusCode: 200,
        message: "All Allowed Payment Types!",
        paymentTypes: paymentMethods
      }
    }
    return {
      statusCode: 500,
      message: "Somethign went wrong"
    }
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin]
  })
  @patch('/payment-types', {
    responses: {
      '200': {
        description: 'PaymentTypes PATCH success count',
        content: {
          'application/json': {
            schema: CountSchema
          }
        },
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PaymentTypes, {
            partial: true
          }),
        },
      },
    }) paymentTypes: PaymentTypes,
    @param.where(PaymentTypes) where?: Where<PaymentTypes>,
  ): Promise<Count> {
    return this.paymentTypesRepository.updateAll(paymentTypes, where);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin, PermissionKeys.Mechanic]
  })
  @get('/payment-types/{id}', {
    responses: {
      '200': {
        description: 'PaymentTypes model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(PaymentTypes, {
              includeRelations: true
            }),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(PaymentTypes, {
      exclude: 'where'
    }) filter?: FilterExcludingWhere<PaymentTypes>
  ): Promise<PaymentTypes> {
    return this.paymentTypesRepository.findById(id, filter);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin]
  })
  @patch('/payment-types/{id}', {
    responses: {
      '204': {
        description: 'PaymentTypes PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PaymentTypes, {
            partial: true
          }),
        },
      },
    }) paymentTypes: PaymentTypes,
  ): Promise<void> {
    await this.paymentTypesRepository.updateById(id, paymentTypes);
  }

  @authenticate(AUTH_STRATEGY, {
    required: [PermissionKeys.Admin]
  })
  @put('/payment-types/{id}', {
    responses: {
      '204': {
        description: 'PaymentTypes PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() paymentTypes: PaymentTypes,
  ): Promise<void> {
    await this.paymentTypesRepository.replaceById(id, paymentTypes);
  }

  // @del('/payment-types/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'PaymentTypes DELETE success',
  //     },
  //   },
  // })
  // async deleteById(@param.path.number('id') id: number): Promise<void> {
  //   await this.paymentTypesRepository.deleteById(id);
  // }
}
