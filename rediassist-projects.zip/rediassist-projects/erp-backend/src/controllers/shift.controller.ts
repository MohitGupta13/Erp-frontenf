import {authenticate} from '@loopback/authentication';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody
} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {Shift} from '../models';
import {ShiftRepository} from '../repositories';

export class ShiftController {
  constructor(
    @repository(ShiftRepository)
    public shiftRepository: ShiftRepository,
  ) {}


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @post('/shifts', {
    responses: {
      '200': {
        description: 'Shift model instance',
        content: {'application/json': {schema: getModelSchemaRef(Shift)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Shift, {
            title: 'NewShift',
            exclude: ['id'],
          }),
        },
      },
    })
    shift: Omit<Shift, 'id'>,
  ): Promise<Shift> {
    return this.shiftRepository.create(shift);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/shifts/count', {
    responses: {
      '200': {
        description: 'Shift model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @param.where(Shift) where?: Where<Shift>,
  ): Promise<Count> {
    return this.shiftRepository.count(where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.QualityUser]})
  @get('/shifts', {
    responses: {
      '200': {
        description: 'Array of Shift model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              items: getModelSchemaRef(Shift, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
    @param.filter(Shift) filter?: Filter<Shift>,
  ): Promise<Shift[]> {
    return this.shiftRepository.find(filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/shifts', {
    responses: {
      '200': {
        description: 'Shift PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Shift, {partial: true}),
        },
      },
    })
    shift: Shift,
    @param.where(Shift) where?: Where<Shift>,
  ): Promise<Count> {
    return this.shiftRepository.updateAll(shift, where);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @get('/shifts/{id}', {
    responses: {
      '200': {
        description: 'Shift model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Shift, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Shift, {exclude: 'where'}) filter?: FilterExcludingWhere<Shift>
  ): Promise<Shift> {
    return this.shiftRepository.findById(id, filter);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @patch('/shifts/{id}', {
    responses: {
      '204': {
        description: 'Shift PATCH success',
      },
    },
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Shift, {partial: true}),
        },
      },
    })
    shift: Shift,
  ): Promise<void> {
    await this.shiftRepository.updateById(id, shift);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @put('/shifts/{id}', {
    responses: {
      '204': {
        description: 'Shift PUT success',
      },
    },
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() shift: Shift,
  ): Promise<void> {
    await this.shiftRepository.replaceById(id, shift);
  }


  @authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
  @del('/shifts/{id}', {
    responses: {
      '204': {
        description: 'Shift DELETE success',
      },
    },
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.shiftRepository.deleteById(id);
  }
}
