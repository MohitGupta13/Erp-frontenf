import {authenticate} from '@loopback/authentication';
import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where} from '@loopback/repository';
import {del, get, getModelSchemaRef, param, patch, post, put, requestBody} from '@loopback/rest';
import {PermissionKeys} from '../authorization/permission-keys';
import {AUTH_STRATEGY} from '../constants';
import {VehicleMaster} from '../models';
import {VehicleMasterRepository} from '../repositories';

export class VehicleMasterController {
	constructor(@repository(VehicleMasterRepository) public vehicleMasterRepository: VehicleMasterRepository) {}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters', {
		responses: {
			'200': {
				description: 'VehicleMaster model instance',
				content: {'application/json': {schema: getModelSchemaRef(VehicleMaster)}}
			}
		}
	})
	async create(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(VehicleMaster, {
						title: 'NewVehicleMaster',
						exclude: ['id']
					})
				}
			}
		})
		vehicleMaster: Omit<VehicleMaster, 'id'>
	): Promise<VehicleMaster> {
		return this.vehicleMasterRepository.create(vehicleMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/vehicle-masters/count', {
		responses: {
			'200': {
				description: 'VehicleMaster model count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async count(@param.where(VehicleMaster) where?: Where<VehicleMaster>): Promise<Count> {
		return this.vehicleMasterRepository.count(where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin, PermissionKeys.AreaManager, PermissionKeys.QualityUser,PermissionKeys.Customer, PermissionKeys.Mechanic]})
	@get('/vehicle-masters', {
		responses: {
			'200': {
				description: 'Array of VehicleMaster model instances',
				content: {
					'application/json': {
						schema: {
							type: 'array',
							items: getModelSchemaRef(VehicleMaster, {includeRelations: true})
						}
					}
				}
			}
		}
	})
	async find(@param.filter(VehicleMaster) filter?: Filter<VehicleMaster>): Promise<VehicleMaster[]> {
		return this.vehicleMasterRepository.find(filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/vehicle-masters', {
		responses: {
			'200': {
				description: 'VehicleMaster PATCH success count',
				content: {'application/json': {schema: CountSchema}}
			}
		}
	})
	async updateAll(
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(VehicleMaster, {partial: true})
				}
			}
		})
		vehicleMaster: VehicleMaster,
		@param.where(VehicleMaster) where?: Where<VehicleMaster>
	): Promise<Count> {
		return this.vehicleMasterRepository.updateAll(vehicleMaster, where);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/vehicle-masters/{id}', {
		responses: {
			'200': {
				description: 'VehicleMaster model instance',
				content: {
					'application/json': {
						schema: getModelSchemaRef(VehicleMaster, {includeRelations: true})
					}
				}
			}
		}
	})
	async findById(
		@param.path.number('id') id: number,
		@param.filter(VehicleMaster, {exclude: 'where'})
		filter?: FilterExcludingWhere<VehicleMaster>
	): Promise<VehicleMaster> {
		return this.vehicleMasterRepository.findById(id, filter);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@patch('/vehicle-masters/{id}', {
		responses: {
			'204': {
				description: 'VehicleMaster PATCH success'
			}
		}
	})
	async updateById(
		@param.path.number('id') id: number,
		@requestBody({
			content: {
				'application/json': {
					schema: getModelSchemaRef(VehicleMaster, {partial: true})
				}
			}
		})
		vehicleMaster: VehicleMaster
	): Promise<void> {
		await this.vehicleMasterRepository.updateById(id, vehicleMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@put('/vehicle-masters/{id}', {
		responses: {
			'204': {
				description: 'VehicleMaster PUT success'
			}
		}
	})
	async replaceById(@param.path.number('id') id: number, @requestBody() vehicleMaster: VehicleMaster): Promise<void> {
		await this.vehicleMasterRepository.replaceById(id, vehicleMaster);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@del('/vehicle-masters/{id}', {
		responses: {
			'204': {
				description: 'VehicleMaster DELETE success'
			}
		}
	})
	async deleteById(@param.path.number('id') id: number): Promise<void> {
		await this.vehicleMasterRepository.deleteById(id);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/vehicle-masters/getminmaxcc', {
		responses: {
			'200': {
				description: 'Vehicle master cc MIN MAX!'
			}
		}
	})
	async findMinMaxBasedOnType(): Promise<any> {
		return this.vehicleMasterRepository.dataSource.execute(
			"select type 'TYPE', min(CONVERT(cc, UNSIGNED INTEGER)) 'MINCC', max(CONVERT(cc, UNSIGNED INTEGER)) 'MAXCC' from VehicleMaster where cc <> 'ELECTRIC' group by 1"
		);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@get('/vehicle-masters/mobilegetminmaxcc', {
		responses: {
			'200': {
				description: 'Vehicle master cc MIN MAX!'
			}
		}
	})
	async findMinMaxBasedOnTypeMobile(): Promise<any> {
		const data = await this.vehicleMasterRepository.dataSource.execute(
			"select type 'TYPE', min(CONVERT(cc, UNSIGNED INTEGER)) 'MINCC', max(CONVERT(cc, UNSIGNED INTEGER)) 'MAXCC' from VehicleMaster where cc <> 'ELECTRIC' group by 1"
		);
		return {
			data: data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/agg-unique-make-and-model', {
		responses: {
			'200': {
				description: 'service-master names based on the conditions!'
			}
		}
	})
	async findServiceNameByTypeAndCC(@requestBody() body: {type: string; qualifier: number; cc: number; serviceName: string}): Promise<
		any
	> {
		const type = body.type;
		let qualifier = '<';
		switch (body.qualifier) {
			case -1:
				qualifier = '<';
				break;

			case 0:
				qualifier = '=';
				break;

			case 1:
				qualifier = '>';
				break;

			default:
				break;
		}
		const sql =
			`select distinct VM.make "MAKE", VM.model "MODEL" from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and CONVERT(cc, UNSIGNED INTEGER) ` +
			qualifier +
			` ? and s.name = ? order by 1, 2 asc`;
		const cc = body.cc;
		const sname = body.serviceName;
		return this.vehicleMasterRepository.dataSource.execute(sql, [type, cc, sname]);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/agg-unique-make-and-model-mobile', {
		responses: {
			'200': {
				description: 'service-master names based on the conditions!'
			}
		}
	})
	async findServiceNameByTypeAndCCMobile(@requestBody()
	body: {
		type: string;
		qualifier: number;
		cc: number;
		serviceName: string;
	}): Promise<any> {
		const type = body.type;
		let qualifier = '<';
		switch (body.qualifier) {
			case -1:
				qualifier = '<';
				break;

			case 0:
				qualifier = '=';
				break;

			case 1:
				qualifier = '>';
				break;

			default:
				break;
		}
		const sql =
			`select distinct VM.make "MAKE", VM.model "MODEL" from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and CONVERT(cc, UNSIGNED INTEGER) ` +
			qualifier +
			` ? and s.name = ? order by 1, 2 asc`;
		const cc = body.cc;
		const sname = body.serviceName;
		const data = await this.vehicleMasterRepository.dataSource.execute(sql, [type, cc, sname]);
		return {
			data: data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/distinct-categories', {
		responses: {
			'200': {
				description: 'Vehicle master get categoriess'
			}
		}
	})
	async findCategoriesBasedOnType(@requestBody() body: {type: string}): Promise<any> {
		const type = body.type;
		return this.vehicleMasterRepository.dataSource.execute("select distinct category 'category' from VehicleMaster where type = ?", [
			type
		]);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/distinct-categories-mobile', {
		responses: {
			'200': {
				description: 'Vehicle master get categoriess'
			}
		}
	})
	async findCategoriesBasedOnTypeMobile(@requestBody() body: {type: string}): Promise<any> {
		const type = body.type;
		const data = await this.vehicleMasterRepository.dataSource.execute(
			"select distinct category 'category' from VehicleMaster where type = ?",
			[type]
		);
		return {
			data
		};
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/distinct-make-and-model', {
		responses: {
			'200': {
				description: 'vehicle make & model names based on the conditions!'
			}
		}
	})
	async findMakeModelByTypeCategoryService(@requestBody() body: {type: string; category: string; serviceName: string}): Promise<any> {
		const sql = `select distinct VM.make "MAKE", VM.model "MODEL" from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and VM.category = ? and s.name = ? order by 1, 2 asc`;
		const type = body.type;
		const category = body.category;
		const sname = body.serviceName;
		return this.vehicleMasterRepository.dataSource.execute(sql, [type, category, sname]);
	}

	@authenticate(AUTH_STRATEGY, {required: [PermissionKeys.Admin]})
	@post('/vehicle-masters/distinct-make-and-model-mobile', {
		responses: {
			'200': {
				description: 'vehicle make & model names based on the conditions!'
			}
		}
	})
	async findMakeModelByTypeCategoryServiceMobile(
		@requestBody() body: {type: string; category: string; subCategory: string}):
		Promise<any> {
		const sql = `select distinct VM.make "MAKE", VM.model "MODEL" from ServiceMaster s JOIN VehicleMaster VM on s.vehicleId = VM.id and s.clientId = 1 and VM.type=? and VM.category in (?) and s.subCategory = ? order by 1, 2 asc`;
		const type = body.type;
		// category will be array of strings.
		const category = body.category;
		const sname = body.subCategory;
		const data = await this.vehicleMasterRepository.dataSource.execute(sql, [type, category, sname]);
		return {
			data: data
		};
	}
}
