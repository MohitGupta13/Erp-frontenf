import AWS from 'aws-sdk';
import fs from "fs";

AWS.config.update({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    signatureVersion: 'v4'
});

export class S3FileUploader {
    tmpPath: string;
    s3: AWS.S3;
    constructor() {
        this.tmpPath = '../tmp/';
        this.s3 = new AWS.S3();
    }

    public async uploadFile(fileName: AWS.S3.ObjectKey, bucketName: string, path: string): Promise<AWS.S3.ManagedUpload.SendData> {
        return new Promise((resolve, reject) => {
            this.s3.upload({
                Key: fileName,
                Body: fs.readFileSync(path),
                Bucket: bucketName
            }, (err, s3data) => {
                if (err) {
                    reject(err);
                }
                resolve(s3data);
            });
        });
    }


    public async downloadFile(fileName: string, bucketName: string, downloadTo?: string) {
        return new Promise((resolve, reject) => {
            downloadTo = "client";
            this.s3.getObject({Key: fileName, Bucket: bucketName}, (err, data) => {
                if (err) reject(err);
                if(data && data.Body){
                    if(data !== null){
                        resolve(data.Body);
                    }
                    else{
                        resolve([]);
                    }

                }
            })
        });
    }


}
