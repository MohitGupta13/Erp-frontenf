import {model, property} from '@loopback/repository';
import {BaseModel} from "./base-model.model";

@model()
export class AggregatorServiceList extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  name: string;


  constructor(data?: Partial<AggregatorServiceList>) {
    super(data);
  }
}

export interface AggregatorServiceListRelations {
  // describe navigational properties here
}

export type AggregatorServiceListWithRelations = AggregatorServiceList & AggregatorServiceListRelations;
