import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class ClientMaster extends BaseModel {
  @property({
    type: 'string',
    required: true,
    index: {
      unique: true,
    },
  })
  name: string;

  constructor(data?: Partial<ClientMaster>) {
    super(data);
  }
}

export interface ClientMasterRelations {
  // describe navigational properties here
}

export type ClientMasterWithRelations = ClientMaster & ClientMasterRelations;
