import {belongsTo, model, property} from '@loopback/repository';
import {Vendor} from '.';
import {BaseModel} from './base-model.model';

@model()
export class AggregatorService extends BaseModel {
	@property({
		type: 'string',
		required: true
	})
	name: string;

	@property({
		type: 'string',
		required: true
	})
	type: string;

	@property({
		type: 'string',
		required: false
	})
	category: number;

	// @property({
	//   type: 'number',
	//   required: true,
	// })
	// cc: number;

	@property({
		type: 'number',
		required: true
	})
	dayCharge: number;

	@property({
		type: 'number',
		required: false
	})
	nightCharge: number;

	@property({
		type: 'number',
		required: false
	})
	extraKmDayCharge: number;

	@property({
		type: 'number',
		required: false
	})
	extraKmNightCharge: number;

	@property({
		type: 'number',
		required: false
	})
	extraKmTerrainDayCharge: number;

	@property({
		type: 'number',
		required: false
	})
	extraKmTerrainNightCharge: number;

	@property({
		type: 'number',
		required: false
	})
	extraPunctureCharge: number;

	@property({
		type: 'string',
		required: false,
		mysql: {
			dataType: "TEXT",
		}
	})
	exclusion: string;

	@belongsTo(() => Vendor)
	vendorId: number;

	constructor(data?: Partial<AggregatorService>) {
		super(data);
	}
}

export interface AggregatorServiceRelations {
	// describe navigational properties here
}

export type AggregatorServiceWithRelations = AggregatorService & AggregatorServiceRelations;
