import {belongsTo, model, property} from '@loopback/repository';
import {File} from ".";
import {vehicleTypes} from '../constants';
import {BaseModel} from "./base-model.model";

@model()
export class VehicleMaster extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  make: string;

  @property({
    type: 'string',
    required: true,
  })
  model: string;

  @property({
    type: 'string',
    required: false,
  })
  version: string;

  // @property({
  //   type: 'string',
  //   required: true,
  // })
  // brandImage: string;

  // @property({
  //   type: 'string',
  //   required: true,
  // })
  // vehicleImage: string;

  @property({
    type: 'string',
    required: true,
  })
  cc: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: Object.values(vehicleTypes),
  })
  type: string;

  @property({
    type: 'string',
    required: true,
  })
  category: string;

  @belongsTo(() => File)
  vehicleId: number;

  @belongsTo(() => File)
  brandId: number;


  constructor(data?: Partial<VehicleMaster>) {
    super(data);
  }
}

export interface VehicleMasterRelations {
  // describe navigational properties here
}

export type VehicleMasterWithRelations = VehicleMaster & VehicleMasterRelations;
