import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class VendorEvents extends BaseModel {
  @property({
    type: 'number',
    required: true,
  })
  vid: number;

  @property({
    type: 'number',
    required: true,
  })
  state: number;


  constructor(data?: Partial<VendorEvents>) {
    super(data);
  }
}

export interface VendorEventsRelations {
  // describe navigational properties here
}

export type VendorEventsWithRelations = VendorEvents & VendorEventsRelations;
