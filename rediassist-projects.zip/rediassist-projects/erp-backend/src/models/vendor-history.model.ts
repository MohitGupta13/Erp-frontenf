import {belongsTo, model, property} from '@loopback/repository';
import {Vendor} from '.';
import {BaseModel} from './base-model.model';

@model()
export class VendorHistory extends BaseModel {
  @property({
    type: 'object',
    required: true,
  })
  vendorJson: object;

  @property({
    type: 'string',
    required: true
  })
  actionPerformed: string;


  // going forward this is going to be a foreign key
  // database optimizaions are to be done later
  @belongsTo(() => Vendor)
  vendorId: number;


  constructor(data?: Partial<VendorHistory>) {
    super(data);
  }
}

export interface VendorHistoryRelations {
  // describe navigational properties here
}

export type VendorHistoryWithRelations = VendorHistory & VendorHistoryRelations;
