import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class File extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  path: string;

  @property({
    type: 'string',
    required: true,
  })
  displayName: string;

  @property({
    type: 'string',
    required: true,
  })
  bucketName: string;

  @property({
    type: 'string',
    required: true,
  })
  extension: string;

  @property({
    type: 'string',
    required: true,
  })
  mimeType: string;

  @property({
    type: 'number',
    required: false,
  })
  vendor: number;

  @property({
    type: 'number',
    required: false,
  })
  vendorLead: number;

  @property({
    type: 'string',
    required: false
  })
  fileType: string;

  constructor(data?: Partial<File>) {
    super(data);
  }
}

export interface FileRelations {
  // describe navigational properties here
}

export type FileWithRelations = File & FileRelations;
