import {hasOne, model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';
import {User} from './user.model';

@model()
export class Role extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  RoleName: string;

  @property({
    type: 'string',
    required: true,
  })
  RoleValue: string;

  @hasOne(() => User, {keyTo: 'RoleName'})
  user: User;

  constructor(data?: Partial<Role>) {
    super(data);
  }
}

export interface RoleRelations {
  // describe navigational properties here
}

export type RoleWithRelations = Role & RoleRelations;
