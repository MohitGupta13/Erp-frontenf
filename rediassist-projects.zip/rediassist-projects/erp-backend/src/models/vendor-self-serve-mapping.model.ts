import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';


@model({
  name: 'VendorSelfServeMapping',
  settings: {
      description: 'Vendor SelfServe Mapping',
      indexes: {
          idxUniqueVidCid: {
              keys: {
                  vid: 1,
                  cid:1,
              },
              options: {
                  unique: true,
              },
          },
      },
  }
})
export class VendorSelfServeMapping extends BaseModel {

  @property({
    type: 'number',
    required: true,
  })
  vid: number;

  @property({
    type: 'number',
    required: true,
  })
  cid: number;


  constructor(data?: Partial<VendorSelfServeMapping>) {
    super(data);
  }
}

export interface VendorSelfServeMappingRelations {
  // describe navigational properties here
}

export type VendorSelfServeMappingWithRelations = VendorSelfServeMapping & VendorSelfServeMappingRelations;
