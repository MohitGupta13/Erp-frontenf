export * from './address.model';
export * from './aggregator-service-list.model';
export * from './aggregator-service.model';
export * from './area-manager.model'; // added by deval
export * from './client-master.model';
export * from './coupon-trans.model';
export * from './coupon.model';
export * from './customer.model';
export * from './file.model';
export * from './invoice.model';
export * from './location.model';
export * from './order-details.model';
export * from './order.model';
export * from './orderhistory.model';
export * from './payment-types.model';
export * from './qualityUser.model'; // added by deval
export * from './registered-vehicle.model';
export * from './role.model';
export * from './service-master.model';
export * from './shift.model';
export * from './sms-log.model';
export * from './team.model';
export * from './transaction.model';
export * from './user.model';
export * from './vehicle-master.model';
export * from './vendor-history.model';
export * from './vendor-lead.model';
export * from './vendor.model';

export * from './payment-types.model';
export * from './aggregator-service.model';
export * from './aggregator-service-list.model';
export * from './vendor-self-serve-mapping.model';
export * from './user-client-mapping.model';
export * from './vendor-events.model';
