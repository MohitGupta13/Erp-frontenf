import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class CouponTrans extends BaseModel {
  @property({
    type: 'string',
  })
  CouponCode?: string;


  @property({
    type: 'number',
  })
  usedBy?: number;

  @property({
    type: 'number',
  })
  orderId?: number;




  constructor(data?: Partial<CouponTrans>) {
    super(data);
  }
}

export interface CouponTransRelations {
  // describe navigational properties here
}

export type CouponTransWithRelations = CouponTrans & CouponTransRelations;
