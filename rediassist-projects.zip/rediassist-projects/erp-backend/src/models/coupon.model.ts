import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class Coupon extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
  })
  couponCode?: string;

  @property({
    type: 'boolean',
    default: false,
  })
  isSpecific?: boolean;

  @property({
    type: 'array',
    itemType: 'number',
    default: []
  })
  userId?: number[];


  @property({
    type: 'boolean',
    default: true,
  })
  type?: boolean;

  @property({
    type: 'date',
  })
  startDate: string;

  @property({
    type: 'date',
  })
  expiryDate: string;

  @property({
    type: 'boolean',
    default: false,
  })
  status?: boolean;

  @property({
    type: 'number',
    default: -1,
  })
  limit: number;

  @property({
    type: 'number',
    default: 0,
  })
  minPurchaseValue: number;

  @property({
    type: 'number',
  })
  perOfDiscount: number;

  @property({
    type: 'number',
  })
  maxDiscountValue: number;

  @property({
    type: 'string',
  })
  location?: string;


  @property({
    type: 'string',
    default: 'Reduction'
  })
  discountType?: string;


  constructor(data?: Partial<Coupon>) {
    super(data);
  }
}

export interface CouponRelations {
  // describe navigational properties here
}

export type CouponWithRelations = Coupon & CouponRelations;
