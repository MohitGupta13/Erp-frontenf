import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class SmsLog extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  mobile: string;

  @property({
    type: 'number',
    required: true,
  })
  otp: number;


  constructor(data?: Partial<SmsLog>) {
    super(data);
  }
}

export interface SmsLogRelations {
  // describe navigational properties here
}

export type SmsLogWithRelations = SmsLog & SmsLogRelations;
