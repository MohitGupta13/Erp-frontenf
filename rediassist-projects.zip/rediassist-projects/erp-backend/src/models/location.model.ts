import {model, property} from '@loopback/repository';
import {BaseModel} from "./base-model.model";

@model()
export class Location extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  shortCode: string;

  @property({
    type: 'string',
    required: true,
    mysql: {
      dataType: "TEXT",
    }
  })
  geofence: string;


  constructor(data?: Partial<Location>) {
    super(data);
  }
}

export interface LocationRelations {
  // describe navigational properties here
}

export type LocationWithRelations = Location & LocationRelations;
