import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class AreaManager extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
    index: {
      unique: true
    }
  })
  mobileNo: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'number',
  })
  otp?: number;

  constructor(data?: Partial<AreaManager>) {
    super(data);
  }
}

export interface AreaManagerRelations {
  // describe navigational properties here
}

export type AreaManagerWithRelations = AreaManager & AreaManagerRelations;
