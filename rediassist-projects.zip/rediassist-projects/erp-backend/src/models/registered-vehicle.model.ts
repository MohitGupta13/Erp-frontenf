import {belongsTo, model, property} from '@loopback/repository';
import {Order, VehicleMaster} from '.';
import {BaseModel} from './base-model.model';

@model()
export class RegisteredVehicle extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  registrationNumber: string;

  @belongsTo(() => VehicleMaster)
  vehicleId: number;

  @belongsTo(() => Order)
  orderId: number;

  constructor(data?: Partial<RegisteredVehicle>) {
    super(data);
  }
}

export interface RegisteredVehicleRelations {
  // describe navigational properties here
}

export type RegisteredVehicleWithRelations = RegisteredVehicle & RegisteredVehicleRelations;
