import {Entity, model, property} from '@loopback/repository';

@model()
export class BaseModel extends Entity {
    @property({
        type: 'number',
        id: true,
        generated: true,
    })
    id?: number;

    @property({
        type: 'date',
        required: false,
        mysql: {
            default: 'CURRENT_TIMESTAMP',
            nullable: 'N',
        },
    })
    createdAt?: string;

    @property({
        type: 'date',
        required: false,
        mysql: {
            default: 'CURRENT_TIMESTAMP',
            nullable: 'N',
        },
    })
    updatedAt?: string;

    @property({
        type: 'boolean',
        default: true,
    })
    isActive?: boolean;


    constructor(data?: Partial<BaseModel>) {
        super(data);
    }
}

export interface BaseModelRelations {
    // describe navigational properties here
}

export type BaseModelWithRelations = BaseModel & BaseModelRelations;
