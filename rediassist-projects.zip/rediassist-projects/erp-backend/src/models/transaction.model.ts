import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class Transaction extends BaseModel {
  @property({
    type: 'object',
  })
  metadata?: object;

  @property({
    type: 'number',
    required: true,
  })
  invoiceId: number;

  @property({
    type: 'number',
    required: true,
    mysql: {
      dataType: 'float',
      precision: 20,
      scale: 4
    }
  })
  paid: number;

  @property({
    type: 'string',
    required: true,
  })
  mode: string;

  @property({
    type: 'string',
  })
  transactionRefNo: string;


  constructor(data?: Partial<Transaction>) {
    super(data);
  }
}

export interface TransactionRelations {
  // describe navigational properties here
}

export type TransactionWithRelations = Transaction & TransactionRelations;
