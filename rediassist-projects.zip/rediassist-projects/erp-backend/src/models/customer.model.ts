import {model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';

@model()
export class Customer extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
    index: {
      unique: true
    }
  })
  mobileNo: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'number',
  })
  otp?: number;

  constructor(data?: Partial<Customer>) {
    super(data);
  }
}

export interface CustomerRelations {
  // describe navigational properties here
}

export type CustomerWithRelations = Customer & CustomerRelations;
