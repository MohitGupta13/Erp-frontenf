import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {ClientMaster, Invoice, Location, Orderhistory, ServiceMaster, VehicleMaster} from '.';
import {BaseModel} from "./base-model.model";


@model()
export class Order extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  source: string;

  @property({
    type: 'string',
    required: true,
  })
  platform: string;

  @property({
    type: 'string',
    required: true,
  })
  orderAddress: string;

  @property({
    type: 'string',
    required: false,
  })
  dropOffAddress: string;

  @property({
    type: 'string',
    required: true,
  })
  custName: string;

  @property({
    type: 'string',
    required: true,
  })
  custPhoneNumber: string;

  @property({
    type: 'string',
    required: false
  })
  custEmail?: string;

  @property({
    type: 'string',
    required: true,
  })
  notes: string;

  @property({
    type: 'number',
    required: true,
  })
  status: number;

  @property({
    type: 'string',
  })
  tag?: string;

  @property({
    type: 'object',
  })
  creationGeopoint: object;

  @property({
    type: 'object',
    required: true,
  })
  taskGeopoint: object;

  @property({
    type: 'object',
    required: false,
  })
  dropOffGeopoint: object;

  @property({
    type: 'string',
    required: true,
  })
  vehicleIdentificationNumber: string;

  @property({
    type: 'date',
    required: true,
    mysql: {
      default: 'CURRENT_TIMESTAMP',
      nullable: 'N',
    },
  })
  bookingTime?: string;

  @belongsTo(() => ClientMaster)
  clientId: number;

  @belongsTo(() => ServiceMaster)
  serviceId: number;

  @belongsTo(() => VehicleMaster)
  vehicleId: number;

  @belongsTo(() => Invoice)
  invoiceId: number;

  @belongsTo(() => Location)
  locationId: number;

  @hasMany(() => Orderhistory)
  orderHistory: Orderhistory[];

  constructor(data?: Partial<Order>) {
    super(data);
  }
}

export interface OrderRelations {
  // describe navigational properties here
}

export type OrderWithRelations = Order & OrderRelations;
