import {model, property} from '@loopback/repository';
import {BaseModel} from "./base-model.model";

@model()
export class PaymentTypes extends BaseModel {
  @property({
    type: 'string',
    required: true,
  })
  method: string;

  @property({
    type: 'string',
  })
  type?: string;

  @property({
    type: 'boolean',
  })
  android?: boolean;

  @property({
    type: 'boolean',
  })
  web?: boolean;

  @property({
    type:'boolean',
  })
  transactionIdReq?: boolean;

  constructor(data?: Partial<PaymentTypes>) {
    super(data);
  }
}

export interface PaymentTypesRelations {
  // describe navigational properties here
}

export type PaymentTypesWithRelations = PaymentTypes & PaymentTypesRelations;
