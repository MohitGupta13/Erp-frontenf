import { belongsTo, model, property } from '@loopback/repository';
import { Order } from '.';
import { AdhocServiceQuantityPatch } from '../constants';
import { BaseModel } from './base-model.model';

@model()
export class Invoice extends BaseModel {
	@property({
		type: 'array',
		itemType: 'object',
		default: []
	})
	services: object[];

	@property({
		type: 'array',
		itemType: 'object',
		default: []
	})
	adhocServices: AdhocServiceQuantityPatch[];

	@property({
		type: 'number',
		default: 0,
		mysql: {
			dataType: 'float',
			precision: 20,
			scale: 4
		}
	})
	amount: number;

	@property({
		type: 'number',
		default: 0,
		mysql: {
			dataType: 'float',
			precision: 20,
			scale: 4
		}
	})
	due: number;

	@property({
		type: 'number',
		default: 0,
		mysql: {
			dataType: 'float',
			precision: 20,
			scale: 4
		}
	})
	paid: number;

	// going forward this is going to be a foreign key
	// database optimizaions are to be done later
	@belongsTo(() => Order)
	orderId: number;

	constructor(data?: Partial<Invoice>) {
		super(data);
	}
}

export interface InvoiceRelations {
	// describe navigational properties here
}

export type InvoiceWithRelations = Invoice & InvoiceRelations;
