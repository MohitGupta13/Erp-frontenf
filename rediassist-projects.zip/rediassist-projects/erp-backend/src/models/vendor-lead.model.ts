import {model, property, belongsTo, hasMany} from '@loopback/repository';
import {Team} from './team.model';
import {Shift} from './shift.model';
import {Location} from './location.model';
import {BaseModel} from "./base-model.model";
import {paymentFrequency, allowanceType} from "../constants"
import {File} from "./file.model";

@model()
export class VendorLead extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  image: string;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'string',
    required: true,
  })
  mobile: string;

  @property({
    type: 'number',
  })
  otp?: number;

  @property({
    type: 'number',
    required: true,
  })
  type: number;

  @property({
    type: 'number',
    required: true,
  })
  category: number;

  @property({
    type: 'string',
    required: true,
  })
  latlon: object;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @property({
    type: 'string',
    required: true,
  })
  locationText: string;

  @property({
    type: 'number',
    required: true,
  })
  status: number;

  @property({
    type: 'number',
    required: true,
  })
  applicationStatus: number;

  @property({
    type: 'date',
  })
  activationDate?: string;

  @property({
    type: 'string',
    required: true,
  })
  aadharNumber: string;

  @property({
    type: 'string',
    required: true,
  })
  panNumber: string;

  @property({
    type: 'number',
    required: true,
  })
  transportationType: number;

  @property({
    type: 'number',
    required: true,
  })
  dailyCompensation: number;

  @property({
    type: 'number',
    required: true,
  })
  monthlyNoOfDaysOff: number;

  @property({
    type: 'string',
    required: true,
    jsonSchema: Object.values(paymentFrequency),
  })
  paymentFrequency: string;

  @property({
    type: 'boolean',
    required: true
  })
  isAllowTravelAllowance: boolean;

  @property({
    type: 'string',
    required: false,
    jsonSchema: Object.values(allowanceType),
  })
  allowanceType: string;

  @property({
    type: 'number',
    required: false
  })
  perDayAllowance: number;

  @property({
    type: 'boolean',
    required: false,
  })
  isApplyKmCharges: boolean;

  @property({
    type: 'number',
    required: false,
  })
  ratePerKM: number;

  @property({
    type: 'boolean',
    required: false,
  })
  isPerformanceAllowance: boolean;

  @property({
    type: 'number',
    required: false,
  })
  minOrderCount: number;

  @property({
    type: 'number',
    required: false,
  })
  incentivePerOrderBeyondMinCount: number;

  @property({
    type: 'boolean',
    required: false,
  })
  countOrdersOnlyWithinETA: boolean;

  // s3 url for profile pic 1 -> mandatory
  @property({
    type: 'string',
    required: true,
  })
  profilePic1: string;

  // s3 url for profile pic 2 -> optional
  @property({
    type: 'string',
    required: false,
  })
  profilePic2: string;

  // s3 url for profile pic 3 -> optional
  @property({
    type: 'string',
    required: false,
  })
  profilePic3: string;

  @belongsTo(() => Team)
  teamId: number;

  @belongsTo(() => Shift)
  shiftId: number;

  @belongsTo(() => Location)
  locationId: number;

  @hasMany(() => File)
  files?: File[];

  constructor(data?: Partial<VendorLead>) {
    super(data);
  }
}

export interface VendorLeadRelations {
  // describe navigational properties here
}

export type VendorLeadWithRelations = VendorLead & VendorLeadRelations;
