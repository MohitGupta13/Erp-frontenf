import {model, property} from '@loopback/repository';
import {BaseModel} from "./base-model.model";

@model()
export class Team extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'number',
    required: false,
  })
  teamType: number;

  @property({
    type: 'number',
    required: false,
  })
  sequence: number;


  constructor(data?: Partial<Team>) {
    super(data);
  }
}

export interface TeamRelations {
  // describe navigational properties here
}

export type TeamWithRelations = Team & TeamRelations;
