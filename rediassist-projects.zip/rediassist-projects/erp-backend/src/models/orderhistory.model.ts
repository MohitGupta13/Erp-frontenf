import {belongsTo, model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';
import {Order} from './order.model';

@model()
export class Orderhistory extends BaseModel {
	@property({
		type: 'object',
		required: true
	})
	orderJson: object;

	@property({
		type: 'string',
		required: true
	})
	actionPerformed: string;

	@property({
		type: 'string',
		required: false
	})
	location: string;

	@property({
		type: 'string',
		required: false
	})
	notes: string;

	@property({
		type: 'object',
		required: false
	})
	changedBy: object;

	@property({
		type: 'string',
		required: false
	})
	recordingUrl: string;

	@property({
		type: 'string',
		required: false
	})
	ExotelCallSid: string;

	// going forward this is going to be a foreign key
	// database optimizaions are to be done later
	@belongsTo(() => Order)
	orderId: number;

	constructor(data?: Partial<Orderhistory>) {
		super(data);
	}
}

export interface OrderhistoryRelations {
	// describe navigational properties here
}

export type OrderhistoryWithRelations = Orderhistory & OrderhistoryRelations;
