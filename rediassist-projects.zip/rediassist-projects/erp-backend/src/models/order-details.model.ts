import {belongsTo, model, property} from '@loopback/repository';
import {Order, Vendor} from '.';
import {BaseModel} from "./base-model.model";

@model()
export class OrderDetails extends BaseModel {
  @property({
    type: 'number',
  })
  internalRating?: number;

  @property({
    type: 'number',
  })
  customerRating?: number;

  @property({
    type: 'date',
    required: false,
    mysql: {
      default: 'CURRENT_TIMESTAMP',
      nullable: 'N',
    },
  })
  assignmentTime: string;

  @property({
    type: 'date',
  })
  acceptanceTime?: string;

  @property({
    type: 'date',
  })
  vendorReachTime?: string;

  @property({
    type: 'date',
  })
  expectedCompTime?: string;

  @property({
    type: 'date',
  })
  actualCompTime?: string;

  @property({
    type: 'date',
  })
  CancelledTime?: string;

  @belongsTo(() => Order)
  orderId: number;

  @belongsTo(() => Vendor)
  vendorId: number;


  // @hasMany(() => File)
  // files: number[];
  @property({
    type: 'array',
    default: [],
    itemType: 'number'
  })
  files: number[];


  constructor(data?: Partial<OrderDetails>) {
    super(data);
  }
}

export interface OrderDetailsRelations {
  // describe navigational properties here
}

export type OrderDetailsWithRelations = OrderDetails & OrderDetailsRelations;
