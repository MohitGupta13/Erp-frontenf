import {belongsTo, model} from '@loopback/repository';
import {BaseModel} from './base-model.model';
import {ClientMaster} from './client-master.model';
import {User} from './user.model';

@model()
export class UserClientMapping extends BaseModel {

  @belongsTo(() => User)
  userId: number;

  @belongsTo(() => ClientMaster)
  clientId: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<UserClientMapping>) {
    super(data);
  }
}

export interface UserClientMappingRelations {
  // describe navigational properties here
}

export type UserClientMappingWithRelations = UserClientMapping & UserClientMappingRelations;
