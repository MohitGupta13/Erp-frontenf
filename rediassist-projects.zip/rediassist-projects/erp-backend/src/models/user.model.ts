import {belongsTo, model, property} from '@loopback/repository';
import {BaseModel} from './base-model.model';
import {Vendor} from './vendor.model';

@model()
export class User extends BaseModel {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'string',
    required: true,
  })
  mobileNo: string;

  @property({
    type: 'string',
    required: true,
  })
  password: string;

  @property({
    type: 'string',
  })
  firstName?: string;

  @property({
    type: 'string',
  })
  lastName?: string;


  @belongsTo(() => Vendor)
  vendorId: number;


  @property({
    type: 'string',
  })
  RoleName: string;


  // @property.array(String)
  // permissions: String[];

  constructor(data?: Partial<User>) {
    super(data);
  }
}

export interface UserRelations {
  // describe navigational properties here
}

export type UserWithRelations = User & UserRelations;
