import {belongsTo, model, property} from '@loopback/repository';
import {serviceCategoryIntervalTime, serviceCategoryLeadTime, serviceCategoryTypes, serviceCodes} from "../constants";
import {BaseModel} from './base-model.model';
import {ClientMaster} from "./client-master.model";
import {Location} from "./location.model";
import {VehicleMaster} from "./vehicle-master.model";
import {Vendor} from './vendor.model';



@model()
export class ServiceMaster extends BaseModel {
  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(serviceCategoryTypes),
    },
  })
  category: string;

  @property({
    type: 'string',
    required: false,
  })
  subCategory: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      enum: Object.values(serviceCodes)
    }
  })
  serviceCode: string;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      enum: Object.values(serviceCategoryLeadTime)
    }
  })
  leadTime: number;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      enum: Object.values(serviceCategoryIntervalTime)
    }
  })
  intervalTime: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  // @property({
  //   type: 'number',
  // })
  // charge?: number;

  // @property({
  //   type: 'string',
  //   required: true,
  //   jsonSchema: {
  //     enum: Object.values(serviceShift),
  //   },
  // })
  // shift: string;


  @property({
    type: 'number',
    required: false,
    default: 0
  })
  dayCharge: number;


  @property({
    type: 'number',
    required: false,
    default: 0
  })
  nightCharge: number;


  @property({
    type: 'number',
    required: true,
  })
  tax: number;

  @property({
    type: 'boolean',
    required: true,
    default: false,
  })
  displayToCustomer: boolean;

  @belongsTo(() => ClientMaster)
  clientId: number;

  @belongsTo(() => Location)
  locationId: number;

  @belongsTo(() => VehicleMaster)
  vehicleId: number;

  @belongsTo(() => Vendor)
  vendorId: number;


  constructor(data?: Partial<ServiceMaster>) {
    super(data);
  }
}

export interface ServiceMasterRelations {
  // describe navigational properties here
}

export type ServiceMasterWithRelations = ServiceMaster & ServiceMasterRelations;
