import {model, property} from '@loopback/repository';
import {BaseModel} from "./base-model.model";

@model()
export class Address extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  addressText: string;

  @property({
    type: 'string',
    required: true,
  })
  addressLine1: string;

  @property({
    type: 'string',
  })
  addressLine2?: string;

  @property({
    type: 'string',
    required: true,
  })
  city: string;

  @property({
    type: 'string',
    required: true,
  })
  state: string;

  @property({
    type: 'number',
    required: true,
  })
  pincode: number;


  constructor(data?: Partial<Address>) {
    super(data);
  }
}

export interface AddressRelations {
  // describe navigational properties here
}

export type AddressWithRelations = Address & AddressRelations;
