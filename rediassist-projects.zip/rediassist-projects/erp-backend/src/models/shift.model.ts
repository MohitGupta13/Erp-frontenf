import {model, property} from '@loopback/repository';
import { BaseModel } from './base-model.model';

@model()
export class Shift extends BaseModel {

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'number',
    required: true,
  })
  description: number;

  @property({
    type: 'date',
    required: true,
  })
  startTime: string;

  @property({
    type: 'date',
    required: true,
  })
  endTime: string;


  constructor(data?: Partial<Shift>) {
    super(data);
  }
}

export interface ShiftRelations {
  // describe navigational properties here
}

export type ShiftWithRelations = Shift & ShiftRelations;
