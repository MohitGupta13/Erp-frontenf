import {belongsTo, hasMany, model, property} from '@loopback/repository';
import {allowanceType, mechanicStatus, paymentFrequency, TowingTypes, TowingVehicleTypes} from '../constants';
import {Address} from "./address.model";
import {BaseModel} from './base-model.model';
import {File} from "./file.model";
import {Location} from './location.model';
import {Role} from './role.model';
import {Shift} from './shift.model';
import {Team} from './team.model';
import {VendorHistory} from './vendor-history.model';


@model({
    name: 'Vendor',
    settings: {
        description: 'Vendor Master',
        forceId: true,
        indexes: {
            idxUniqueMobileNo: {
                keys: {
                    mobile: 1,
                },
                options: {
                    unique: true,
                },
            },
        },
    }
})
export class Vendor extends BaseModel {

    @property({
        type: 'string',
        required: true,
    })
    image: string;

    @property({
        type: 'string',
        required: true,
    })
    name: string;

    @property({
        type: 'string',
        required: true,
    })
    email: string;

    @property({
        type: 'string',
        required: true,
    })
    mobile: string;

    @property({
        type: 'number',
    })
    otp?: number;

    @property({
        type: 'number',
        required: true,
    })
    type: number;

    @property({
        type: 'number',
        required: true,
    })
    category: number;

    @property({
        type: 'string',
        required: true,
    })
    latlon: object;

    @property({
        type: 'string',
        required: true,
    })
    addressText: string;

    @property({
        type: 'string',
        required: true,
    })
    locationText: string;

    @property({
        type: 'number',
        required: true,
    })
    status: number;

    @property({
        type: 'number',
        required: true,
    })
    applicationStatus: number;

    @property({
        type: 'date',
        required: false,
    })
    activationDate?: string;

    @property({
        type: 'string',
        required: true,
    })
    aadharNumber: string;

    @property({
        type: 'string',
        required: true,
    })
    panNumber: string;

    @property({
        type: 'string',
        required: false,
    })
    GSTIN: string;

    @property({
        type: 'string',
        required: false,
    })
    tanNumber: string;

    @property({
        type: 'number',
        required: true,
    })
    transportationType: number;


    @property({
        type: 'number',
        required: true,
    })
    dailyCompensation: number;

    @property({
        type: 'number',
        required: true,
    })
    monthlyNoOfDaysOff: number;

    @property({
        type: 'string',
        required: true,
        jsonSchema: Object.values(paymentFrequency),
    })
    paymentFrequency: string;

    @property({
        type: 'boolean',
        required: true
    })
    isAllowTravelAllowance: boolean;

    @property({
        type: 'string',
        required: false,
        jsonSchema: Object.values(allowanceType),
    })
    allowanceType: string;

    @property({
        type: 'number',
        required: false
    })
    perDayAllowance: number;

    @property({
        type: 'boolean',
        required: false,
    })
    isApplyKmCharges: boolean;

    @property({
        type: 'number',
        required: false,
    })
    ratePerKM: number;

    @property({
        type: 'boolean',
        required: false,
    })
    isPerformanceAllowance: boolean;

    @property({
        type: 'number',
        required: false,
    })
    minOrderCount: number;

    @property({
        type: 'number',
        required: false,
    })
    incentivePerOrderBeyondMinCount: number;

    @property({
        type: 'boolean',
        required: false,
    })
    countOrdersOnlyWithinETA: boolean;

    // s3 url for profile pic 1 -> mandatory
    @property({
        type: 'string',
        required: true,
    })
    profilePic1: string;

    // s3 url for profile pic 2 -> optional
    @property({
        type: 'string',
        required: false,
    })
    profilePic2: string;

    // s3 url for profile pic 3 -> optional
    @property({
        type: 'string',
        required: false,
    })
    profilePic3: string;

    @property({
        type: 'number',
        required: false,
        default: mechanicStatus.NotOnDuty,
        jsonSchema: Object.values(mechanicStatus),
    })
    mechanicStatus: number;

    @property({
        type: 'string',
        required: false
    })
    notes: string;

    @property({
        type: 'string',
        required: false
    })
    deviceId: string;

    @property({
        type: 'object',
        required: false
    })
    firebaseData: object;

    @property({
        type: 'string',
        required: false
    })
    fcmToken: string;

    // this will be used for aggregator mechanics
    @property({
        type: 'boolean',
        required: false
    })
    isMinimumMonthlyGuarantee: boolean;

    @property({
        type: 'number',
        required: false
    })
    minimumMonthlyGuarantee: number;

    @property({
        type: 'number',
        required: false,
        jsonSchema: {
            enum: Object.values(TowingVehicleTypes)
        }
    })
    towingVehicleType: number;

    @property({
        type: 'number',
        required: false,
        jsonSchema: {
            enum: Object.values(TowingTypes)
        }
    })
    towingType: number;

    @property({
        type: 'boolean',
        default: false,
    })
    selfserve?: boolean;

    @belongsTo(() => Team)
    teamId: number;

    @belongsTo(() => Role)
    roleId: number;


    @belongsTo(() => Shift)
    shiftId: number;

    @belongsTo(() => Location)
    locationId: number;

    // following is for the cleaned address
    // in future we may have interfaces for cleaning addresses
    @belongsTo(() => Address)
    addressId: number;

    @hasMany(() => File)
    files?: File[];

    @hasMany(() => VendorHistory)
    vendorHistorys?: VendorHistory[];

    constructor(data?: Partial<Vendor>) {
        super(data);
    }
}

export interface VendorRelations {
    // describe navigational properties here
}

export type VendorWithRelations = Vendor & VendorRelations;
