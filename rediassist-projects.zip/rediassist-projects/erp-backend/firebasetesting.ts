import '@firebase/firestore';
import * as turf from '@turf/turf';
import * as firebase from 'firebase';
import * as geofirestore from 'geofirestore';
import _ from 'underscore';

const config = {
  name: 'firebaseds',
  connector: 'loopback-connector-firestore',
  type: "service_account",
  projectId: "prefab-mountain-509",
  privateKeyId: "9c0743bea9638df86a646b6dd2f17124a44382fb",
  privateKey: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCWJpIPGhiq3aZR\n8imGmDD0k/9GN+WAlr5zLrxuGMI3kuJAZ2wYHeQ2/5wVBr0K7eWN3VmbZVLH7rpt\n2cs7NEKuRG3Sga5/M3mnuefZc0YUtBVfwFqQDQCbN0vDluRM7+cCa3n0hT2qq+PO\nVCvH4ycDFCphV2N0bQ07eLHLfgLj+SB/BSccjwsGZIe0sEIowZ9KhNB51mleC62J\n7CmTYFLTPjtwzDRDUxiScfmjALvfOnVutZZNUKTlmEVdEjrX9Uq+1BW5OFHzF7T7\nQP9mmsFSR9bai0Z6JJlv2+QA8d8rBsLMavOiZHuPzedVRMddcqb+Z0TYsoHKJY6m\nW1i+/sZ5AgMBAAECggEAAUBIkAvOKKjHYBPi3cUVy1ecWjnQ2pWr5G0JMMC8NshU\nxJjEUoCo85wPBPWGQs1IgTpW3Bw7fEWbzv0hg2JkK4nelQJgE+xVVz9wJ/gTE6WM\nLx9fREUWPCEqg+ifRK0nrYmPkW3x3YUyN5X7f7b107fk6ZWmmBzo0Hht/A7HlbGe\nN2vEGlRu3hbe3wnY0OZ8vbINLa1XeBs3FQzj6NIcqVfo6EfFyEKD+0d/Qlcekr1Q\n3fiF52ag0AZq2yL2syIAxObmkXc1BlqFR+tBb7zhaGOcRzkv0kLjDe1DTLq2rxUU\nZNofcaDqeqoVza/4nnzxwo7aUfAruim4YgOUeFOp8QKBgQDR1ihJnaYmpCvel/V8\nauk2QLz1pwsnMeT/lcbHoEYXp7yTK8CWBjxhR4ZzUvmga8FwJbGNPYMreure/ghD\np8u6eUnqPJhZccpKojuS0jRRZ0Ii1tmqWLbXMxSlRdlze5CMaDwmtd8tqh2OfatW\nXGVtP9/4kCiejrAuRVlJb7XqdQKBgQC3LvKCSZy1w4eU2i8jgvWJJ8XbvnbFJ2UM\nq7Ym6IbEK5AuQcUEPb4ScaRW5Vxln5d/JYdbkeEQUOTPVridmjbO2MDDRySXTyNA\nKon2qXSmNVYYhftoGasF+dgD/Yzitiv9vBxXslRISb9GBD2qajso4mkr9k4JzkVp\nTXGyBsZDdQKBgQDQqVdyrPQWJNcDCLUyvdWe/41n8m5i0XjYt4Xt6PEKgOBCsRVX\nmmfcjJWkhHR7E+xNqw3+V5biW97HVHG/ZVJv4kCgTxVojIEO6ni3LZSdBkN8BY55\nmLJpGQCEwQrVjaBWHykBjYWbETlHAqyoukSZ+RStRh0+XsHPoWKCZjXOKQKBgQCl\nVXM+UtBlYbBqki6/n4CbpVE4j4TFV1QmBolmPrL8NdFxXp1CwbNfFEDeyS8G7e8f\nrDCqXlVDk6+gz8XbQYg8U3hQCFMnWh8X2A0jmziUl0k44xzRjXFF+IWWvG8/ZGr6\nHaF7KZJWmHFR8ZvyxuTUdt2z9x/iS9FsRKDcrK6fzQKBgHeJtYjfi88/4gqOjC6g\nT/vAHizC+C6hC4XkOZI+nLKlzaIl/1Xu4Jy1Sk1gvgQQSKUVp48r6Ohsn7S5gRJ7\nnDoUoxovYznjOg6WNv9dahX4fqiCbI5pZ+OhOz0Z21msjQpJCEozzblpHRL1QI5q\nB4d9umitK4xp6Q1M0p/EmRTP\n-----END PRIVATE KEY-----\n",
  clientEmail: "firebase-adminsdk-yxwdu@prefab-mountain-509.iam.gserviceaccount.com",
  clientId: "117399523349634114463",
  authUri: "https://accounts.google.com/o/oauth2/auth",
  tokenUri: "https://oauth2.googleapis.com/token",
  authProviderX509CertUrl: "https://www.googleapis.com/oauth2/v1/certs",
  clientX509CertUrl: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-yxwdu%40prefab-mountain-509.iam.gserviceaccount.com"
};

const polygon = turf.polygon([
  [
    [
      72.8781509399414,
      19.00751233804502
    ],
    [
      72.88364410400389,
      19.005645858120225
    ],
    [
      72.88604736328125,
      19.001101297690546
    ],
    [
      72.89291381835938,
      18.99688123757382
    ],
    [
      72.9001235961914,
      18.997855107099333
    ],
    [
      72.9056167602539,
      18.993310333893152
    ],
    [
      72.90630340576172,
      18.998828970925903
    ],
    [
      72.91248321533203,
      19.002724369237626
    ],
    [
      72.91522979736327,
      19.007268885329545
    ],
    [
      72.91797637939453,
      19.01668213079985
    ],
    [
      72.91900634765625,
      19.031936948379204
    ],
    [
      72.91694641113281,
      19.04524319840765
    ],
    [
      72.90904998779297,
      19.048163939806823
    ],
    [
      72.90321350097656,
      19.05205818170657
    ],
    [
      72.89325714111328,
      19.054978803148376
    ],
    [
      72.88304328918457,
      19.05351849885474
    ],
    [
      72.86956787109375,
      19.04873185577617
    ],
    [
      72.85909652709961,
      19.041592199379426
    ],
    [
      72.8499984741211,
      19.02990846295003
    ],
    [
      72.84905433654785,
      19.01392313129852
    ],
    [
      72.85446166992188,
      19.002643216036322
    ],
    [
      72.86252975463867,
      19.003698204565687
    ],
    [
      72.87008285522461,
      19.006619676346205
    ],
    [
      72.8781509399414,
      19.00751233804502
    ]
  ]
]);


firebase.initializeApp(config);
const firestore = firebase.firestore();
const GeoFireStore = geofirestore.initializeApp(firestore);
const geocollection = GeoFireStore.collection('vendor');

geocollection.get().then((values) => {
  // console.log(value.docs);
  // const point = turf.point([value.docs[0].data().gp.longitude, value.docs[0].data().gp.latitude]);
  // // console.log(turf.booleanPointInPolygon(point, polygon));
  // console.log(turf.booleanPointInPolygon(turf.point([72.9048755, 18.9907972]), polygon));

  const allRequiredMechancis = values.docs.map(doc => ({id: doc.id, lon: doc.data().gp.longitude, lat: doc.data().gp.latitude}))
    .filter(doc => turf.booleanPointInPolygon(turf.point([doc.lon, doc.lat]), polygon))
    .map(doc => ({id: doc.id, lon: doc.lon, lat: doc.lat, dist: turf.distance(turf.point([doc.lon, doc.lat]), turf.point([72.9048755, 18.9907972]), {units: 'kilometers'})}));
  console.log(allRequiredMechancis);
  console.log(_.sortBy(allRequiredMechancis, 'dist',).reverse().slice(0, 5));
  return;
}).catch((err) => {
  console.log(err);
});

