# erp-backend
Backend system for entire Readyassist ERP. This is going to contain all the centralised code for overall backend systems for readyassist following applications:
1. B2C - Consumer application
2. Vendor application APIs
3. Admin application APIs
4. Mechanic application APIs


#### How to run the application on local?

---
Once you are done cloning the repository, assuming that you have docker (and docker compose) installed in your local, simply do following:

```bash
docker-compose up -d
```

the `-d` option is used for running the services in the backend.

Once you fire above command you should be able to see following output that says that the services have started fine.

```text
✗ docker-compose up -d
Creating network "erp-backend_default" with the default driver
Creating ra-es-service ... done
Creating ra-api-server     ... done
Creating ra-kibana-service ... done
✗ 
```

and when you want to turn down the environment, in the same directory, fire `docker-compose down` command and it should display following output:

```text
✗ docker-compose down
Stopping ra-api-server     ... done
Stopping ra-kibana-service ... done
Stopping ra-es-service     ... done
Removing ra-api-server     ... done
Removing ra-kibana-service ... done
Removing ra-es-service     ... done
Removing network erp-backend_default
✗ 
```