const admin = require('firebase-admin');
const moment = require('moment');
const serviceAccount = require('/Users/pawan/Documents/Readyassist/firebase/ra-prod-mechapp-2d6b8bea44c7.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});
// let a = ['20201101', '20201102', '20201003', '20201004', '20201005', '20201006', '20201007', '20201008', '20201009',
// '20201010', '20201018', '20201011', '20201012', '20201013', '20201014', '20201015', '20201016',
// '20201017', '20201018', '20201019', '20201020', '20201021', '20201022', '20201023', '20201024', '20201025',
// '20201026', '20201027', '20201028', '20201029', '20201030', '20201031', '20201101'];
const db = admin.firestore();
const vendorRef = db.collection('vendor');
vendorRef.get().then(snapshot => {
  snapshot.forEach(doc => {
    let mydata = doc.data();
    db.collection('vendor_history')
      .doc(doc.id)
      .listCollections()
      .then(myList => {
        let listOfCollections = [];
        myList.forEach(collection => {
          // if (a.includes(String(collection.id))) {
          if (String(collection.id).substring(4, 6) === '11' || String(collection.id).substring(4, 6) === '12') {
              db.collection(`vendor_history/${doc.id}/${collection.id}/`)
                .orderBy('ts')
                .get()
                .then(vh => {
                  vh.forEach(vhdoc => {
                    let vhdata = vhdoc.data();
                    if (vhdata.vs.toUpperCase() !== 'NOT ON DUTY') {
                      // console.log(vhdata.ts.toDate());
                      console.log(
                        doc.id,
                        ',',
                        moment
                          .utc(vhdata.ts.toDate())
                          .local()
                          .format()
                          .toString()
                          .replace('T', ' ')
                          .replace('+5:30', ''),
                        ',',
                        vhdata.vs,
                      );
                    }
                  });
                });
          }
        });
      });
  });
});

// db.collection(`vendor_history/19/20200914/`).orderBy('ts').get().then((vh) => {
//   vh.forEach(vhdoc => {
//     let vhdata = vhdoc.data();
//     // if (vhdata.vs.toUpperCase() !== 'NOT ON DUTY') {
//     // console.log(vhdata.ts.toDate());
//     console.log(vhdoc.id, ',', moment.utc(vhdata.ts.toDate()).local().format().toString().replace('T', ' ').replace('+5:30', ''), ',', vhdata.vs);
//     // }
//   });
// });

// db.collection(`vendor`).get().then((vd) => {
//   vd.forEach((vd) => {
//     let v = vd.data
//     console.log(v.id, v.vs, v.ts, v.VendorStatus, v.mrodt);
//   })
// });
