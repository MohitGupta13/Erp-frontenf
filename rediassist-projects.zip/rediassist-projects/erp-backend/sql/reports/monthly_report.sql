-- orders by vendor per date of august.
select o.id                          "ORDER ID",
       V.id                          "VENDOR ID",
       V.name                        "VENDOR NAME",
       t.name                        "TEAM NAME",
       s.name                        "SHIFT NAME",
       o.createdAt                   "ORDER CREATION DATE IN UTC",
       o.bookingTime                 "ORDER BOOKING TIME IN UTC",
       OD.acceptanceTime             "ORDER ACCEPTANCE TIME",
       OD.expectedCompTime           "EXPECTED COMPLETION TIME",
       OD.vendorReachTime            "VENDOR REACH TIME",
       o.source                      "ORDER SOURCE",
       o.platform                    "ORDER PLATFORM",
       o.orderAddress                "ORDER ADDRESS",
       case o.status
           WHEN 1 THEN "New Order"
           WHEN 2 THEN "Mechanic Assigned"
           WHEN 3 THEN "Mechanic Acknowledged"
           WHEN 4 THEN "Mechanic Started"
           WHEN 5 THEN "Mechanic Reached"
           WHEN 6 THEN "Work Started"
           WHEN 7 THEN "Work Completed"
           WHEN 8 THEN "Payment Pending"
           WHEN 9 THEN "Order Closed"
           WHEN 10 THEN "Successful"
           WHEN 11 THEN "Failed"
           WHEN 12 THEN "Cancelled"
           ELSE NULL
           END                       "ORDER STATUS",
       o.status                      "ORDER STATUS NUMERIC",
       o.taskGeopoint                "ORDER LOCATION",
       o.vehicleIdentificationNumber "ORDER VEHICLE NUMBER",
       sm.name                       "SERVICE NAME",
       cm.name                       "CLIENT NAME"
from `Order` o
         JOIN OrderDetails OD on MONTH(o.bookingTime) = 8 AND o.id = OD.orderId and OD.isActive = 1
         JOIN Vendor V on OD.vendorId = V.id
         JOIN ClientMaster cm ON o.clientId = cm.id
         JOIN ServiceMaster sm ON sm.id = o.serviceId
         JOIN Team t ON V.teamId = t.id
         JOIN Shift s ON V.shiftId = s.id
order by o.bookingTime, o.id asc;
