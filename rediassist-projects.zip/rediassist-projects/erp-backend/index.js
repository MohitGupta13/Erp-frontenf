const application = require('./dist');

module.exports = application;

if (require.main === module) {
  const port = process.env.PORT || 3000;
  // Run the application
  const config = {
    rest: {
      basePath: '/api',
      port: port,
      host: process.env.HOST,
      cors: {
        origin: [
          'http://localhost:4200',
          'http://localhost:4000',
          'http://localhost:3000',
          'http://localhost:3001',
          'http://localhost:5000',
          'http://app.readyassist.net',
          'http://dev.readyassist.net',
        ],
        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
        preflightContinue: false,
        optionsSuccessStatus: 204,
        maxAge: 86400,
        credentials: true,
      },
      // The `gracePeriodForClose` provides a graceful close for http/https
      // servers with keep-alive clients. The default value is `Infinity`
      // (don't force-close). If you want to immediately destroy all sockets
      // upon stop, set its value to `0`.
      // See https://www.npmjs.com/package/stoppable
      gracePeriodForClose: 5000, // 5 seconds
      openApiSpec: {
        // useful when used with OpenAPI-to-GraphQsL to locate your application
        setServersFromRequest: true,
      },
      apiExplorer: {
        disabled: true,
      },
    },
    httpServerOptions: {
      basePath: '/',
      port: +(process.env.PORT || 4000),
    }
  };
  application.main(config).catch(err => {
    console.error('Cannot start the application.', err);
    process.exit(1);
  });
}
