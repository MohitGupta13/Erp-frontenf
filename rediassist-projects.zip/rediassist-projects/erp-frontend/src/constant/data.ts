export const transportationTypes = [{
    id: 1,
    name: 'Motorcycle',
    class: 'fas fa-motorcycle',
    selected: true,
  },
  {
    id: 2,
    name: 'Car',
    class: 'fas fa-car-side',
    selected: false,
  },
  {
    id: 3,
    name: 'Truck',
    class: 'fas fa-truck',
    selected: false,
  },
  {
    id: 4,
    name: 'Bicycle',
    class: 'fas fa-bicycle',
    selected: false,
  },
  {
    id: 5,
    name: 'Walking',
    class: 'fas fa-walking',
    selected: false,
  },
];

export const servicesAvailable = {
  RSA: {
    name: 'RSA',
    services: [],
  },
  TOWING: {
    name: 'Towing',
    services: [],
  },
  ON_SPOT_REPAIRS: {
    name: 'On Spot Repairs',
    services: [],
  },
  GS: {
    name: 'GS',
    services: [],
  },
  INSPECTION: {
    name: 'Inspection',
    services: [],
  },
  GENERAL: {
    name: 'General',
    services: [],
  }
};
export const teams = [{
    id: 1,
    name: 'Default Team',
    selected: false,
  },
  {
    id: 2,
    name: 'Team 2',
    selected: false,
  },
  {
    id: 3,
    name: 'Team 3',
    selected: false,
  },
];
export const geoFences = [{
    id: 1,
    name: 'Yes',
    selected: false,
  },
  {
    id: 2,
    name: 'No',
    selected: false,
  },
];
export const tags = [{
    id: 1,
    name: 'Tag 1',
    selected: false,
  },
  {
    id: 2,
    name: 'Tag 2',
    selected: false,
  },
  {
    id: 3,
    name: 'Tag 3',
    selected: false,
  },
];

export const mechanics = [{
    id: 1,
    name: 'Mechanic 1',
    status: 'Idle',
    selected: false,
  },
  {
    id: 2,
    name: 'Mechanic 2',
    status: 'In Transit',
    selected: false,
  },
  {
    id: 3,
    name: 'Mechanic 3',
    status: 'Idle',
    selected: false,
  },
];

export enum vendorTypes {
  MECHANIC = 'MECHANIC',
  GARAGE = 'GARAGE',
  TOWING = 'TOWING'
}

export enum vendorCategories {
  MBG = 'MBG',
  RSA = 'RSA',
  AGG = 'AGG'
}

export enum paymentFrequency {
    DAILY = 'DAILY',
    WEEKLY = 'WEEKLY',
    BIWEEKLY = 'BIWEEKLY',
    MONTHLY = 'MONTHLY',
}

export const fileTypes = ['vendorAgreement', 'drivingLicense', 'panCard', 'aadharCard', 'bankPassbook', 'GSTIN', 'tanCard'];

export const serviceCategory = ['RSA', 'TOWING', 'ON_SPOT_REPAIRS', 'GS', 'INSPECTION'];

export const serviceSubCategory =['TYRE_WORK','BREAKDOWN_SUPPORT','BATTERY_JUMPSTART','FUEL_DELIVERY','KEY_LOCK_ASSISTANCE','TOWING','CUSTODY_SERVICE',];

export const serviceCodes = [
  'ACC_CABLE_REPLACEMENT',
  'ACC_CABLE_REPLACEMENT_ADDON',
  'BAT_JUMP',
  'BAT_RECHARGE',
  'BAT_RECHARGE_ADDON',
  'CARBURETOR_CLEANING',
  'CHAIN_LINK_LOCK',
  'EXTRA_PUN',
  'FLAT_BED_TOWING',
  'FT_TL',
  'FT_TUBE',
  'FUEL_DELI',
  'FUEL_PIPE_CHANGE',
  'KEY_LOCK',
  'LIFT_TOWING',
  'MINOR_REPAIR',
  'MISCELLANEOUS',
  'QUICK_SERVICE',
  'RIM_BEND_FIX',
  'START_PROB',
  'VALVE_NECK_CHANGE',
  'VALVE_PIN_CHANGE',
];
// 'INSPECTION',
export const leadTimes = [30];

export const intervalTimes = [30];

export const taskStatus = {
  1: 'New Order',
  2: 'Mechanic Assigned',
  3: 'Mechanic Acknowledged',
  4: 'Mechanic Started',
  5: 'Mechanic Reached',
  6: 'Work Started',
  7: 'Work Completed',
  8: 'Payment Pending',
  9: 'Order Closed',
  10: 'Successful',
  11: 'Failed',
  12: 'Cancelled',
};

export const cancelOptions = {
  1 : 'CNL - LOCAL HELP',
  2 : 'CNL - VEHICLE STARTED',
  3 : 'CNL - INQUIRY CALL',
  4 : 'CNL - CHARGES HIGH',
  5 : 'CNL - BIKE MAJOR',
  6 : 'CNL - NO UNREACHABLE',
  7 : 'CNL - TOWING UNAVAILABLE',
  8 : 'CNL - QUICK SRVE (ABOVE 150)',
  9 : 'Others',
  10 : 'CNL - UNRELATED CALL',
  11 : 'CNL - ETA',
  12 : 'CNL - LACK OF TECHNICIAN',
  13 : 'CNL - SPARE UNAVAILABLE',
  15 : 'CNL - FUEL DELIVERY',
  16 : 'CNL - COMMERCIAL VEHICLE',
  17 : 'CNL - CAR MAJOR',
  18 : 'CNL - TECHNICIAN FAULT',
  19 : 'CNL - TUBE TYRE',
  20 : 'CNL - DELAY IN CALL',
  21 : 'CNL - DUPLICATE',
  22 : 'CNL - MAJOR ISSUE',
  23 : 'CNL - CURFEW',
  24 : 'CNL - LIFT TOWING UNAVLBL',
  25 : 'CNL - CASH PAYMENT',
  26 : 'CNL - BD RELATED',
  27 : 'CNL - out of Coverage',
  28 : 'CNL - CUST NOT AVAILABLE'
}

export const mechanicStatus = {
  0: 'Idle',
  1: 'In Transit',
  2: 'Busy',
  3: 'On Break',
  4: 'Off Duty'
};

export const dayMapJSONDetails = [];
export const nightMapJSONDetails = [
  {
    elementType: 'geometry',
    stylers: [
      {
        color: '#212121'
      }
    ]
  },
  {
    elementType: 'labels.icon',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [
      {
        color: '#212121'
      }
    ]
  },
  {
    featureType: 'administrative',
    elementType: 'geometry',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    featureType: 'administrative.country',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#9e9e9e'
      }
    ]
  },
  {
    featureType: 'administrative.land_parcel',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#bdbdbd'
      }
    ]
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [
      {
        color: '#181818'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#616161'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.stroke',
    stylers: [
      {
        color: '#1b1b1b'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [
      {
        color: '#2c2c2c'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#8a8a8a'
      }
    ]
  },
  {
    featureType: 'road.arterial',
    elementType: 'geometry',
    stylers: [
      {
        color: '#373737'
      }
    ]
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [
      {
        color: '#3c3c3c'
      }
    ]
  },
  {
    featureType: 'road.highway.controlled_access',
    elementType: 'geometry',
    stylers: [
      {
        color: '#4e4e4e'
      }
    ]
  },
  {
    featureType: 'road.local',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#616161'
      }
    ]
  },
  {
    featureType: 'transit',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [
      {
        color: '#000000'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#3d3d3d'
      }
    ]
  }
];

export const nightMapJSON = [
  {
    elementType: 'geometry',
    stylers: [
      {
        color: '#212121'
      }
    ]
  },
  {
    elementType: 'labels.icon',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [
      {
        color: '#212121'
      }
    ]
  },
  {
    featureType: 'administrative',
    elementType: 'geometry',
    stylers: [
      {
        color: '#757575'
      },
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'administrative.country',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#9e9e9e'
      }
    ]
  },
  {
    featureType: 'administrative.land_parcel',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#bdbdbd'
      }
    ]
  },
  {
    featureType: 'administrative.neighborhood',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'poi',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'poi',
    elementType: 'labels.text',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [
      {
        color: '#181818'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#616161'
      }
    ]
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.stroke',
    stylers: [
      {
        color: '#1b1b1b'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [
      {
        color: '#2c2c2c'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#8a8a8a'
      }
    ]
  },
  {
    featureType: 'road.arterial',
    elementType: 'geometry',
    stylers: [
      {
        color: '#373737'
      }
    ]
  },
  {
    featureType: 'road.arterial',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [
      {
        color: '#3c3c3c'
      }
    ]
  },
  {
    featureType: 'road.highway',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.highway.controlled_access',
    elementType: 'geometry',
    stylers: [
      {
        color: '#4e4e4e'
      }
    ]
  },
  {
    featureType: 'road.local',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.local',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#616161'
      }
    ]
  },
  {
    featureType: 'transit',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'transit',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#757575'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [
      {
        color: '#000000'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'labels.text',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [
      {
        color: '#3d3d3d'
      }
    ]
  }
];

export const dayMapJSON = [
  {
    featureType: 'administrative',
    elementType: 'geometry',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'administrative.neighborhood',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'poi',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'poi',
    elementType: 'labels.text',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.arterial',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.highway',
    elementType: 'labels',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'road.local',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'transit',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  },
  {
    featureType: 'water',
    elementType: 'labels.text',
    stylers: [
      {
        visibility: 'off'
      }
    ]
  }
];


