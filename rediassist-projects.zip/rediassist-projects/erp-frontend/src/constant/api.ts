import {
  environment
} from '../environments/environment';
const baseUrl = environment.baseUrl;
const mapUrl = 'https://maps.googleapis.com/maps/api/distancematrix/json';
export const apiPath = {
  auth: {
    login: baseUrl + '/login'
  },
  clients: {
    list: baseUrl + '/client-masters/',
    count: baseUrl + '/client-masters/count',
  },
  locations: {
    list: baseUrl + '/locations/',
    count: baseUrl + '/locations/count',
    search:  baseUrl + '/ralocations/{lon}/{lat}'
  },
  services: {
    list: baseUrl + '/service-masters?filter=',
    all: baseUrl + '/service-masters',
    count: baseUrl + '/service-masters/count',
    search: baseUrl + '/service-masters?filter[where][name][like]=%25{name}%25',
    uniqueServiceNames: baseUrl + '/service-masters/unique-service-names',
    distinctServiceNames: baseUrl + '/service-masters/distinct-service-names',
  },
  shifts: {
    list: baseUrl + '/shifts/',
    count: baseUrl + '/shifts/count',
  },
  teams: {
    list: baseUrl + '/teams/',
    count: baseUrl + '/teams/count',
  },
  vendorLead: {
    list: baseUrl + '/vendor-leads/',
    create: baseUrl + '/vendor-leads/',
    count: baseUrl + '/vendor-leads/count',
    location: baseUrl + '/vendor-leads/{id}/location',
    shift: baseUrl + '/vendor-leads/{id}/shift',
    team: baseUrl + '/vendor-leads/{id}/team',
  },
  sms: {
    send: baseUrl + '/sendotp/',
    resend: baseUrl + '/resendotp/',
    verify: baseUrl + '/verifyotp',
  },
  vendors: {
    nearMechanic: baseUrl + '/customer/order/mechanic',
    list: baseUrl + '/vendors/',
    count: baseUrl + '/vendors/count',
    create: baseUrl + '/vendors/',
    history: baseUrl + '/vendor-histories/',
    aggregatorServices: baseUrl + '/aggregator-services',
    update : baseUrl + '/vendors/'
  },
  vendorSelfServeMapping:{
    list : baseUrl + '/vendor-self-serve-mappings',
    clientDetails : baseUrl + '/vendor-client-details',
    vendorSelfServeMapping : baseUrl + '/vendor-self-serve-mappings',
    vendorSelfServeMappingArray: baseUrl + '/vendor-self-serve-mappings-array'
  },
  role:{
    list: baseUrl + '/roles'
  },
  file: {
    upload: baseUrl + '/files/upload/{mobile}/vendor?fileType={fileType}',
    download: baseUrl + '/files/download',
    list: baseUrl + '/files?filter[where][isActive]=true&filter[where][vendor]={vendor}',
    patchFile: baseUrl + '/files/{id}',
    get: baseUrl + '/files'
  },
  vehicles: {
    search: baseUrl + '/vehicle-masters?filter[where][or][0][make][like]=%25{make}%25&filter[where][or][1][model][like]=%25{model}%25',
    list: baseUrl + '/vehicle-masters/',
    count: baseUrl + '/vehicle-masters/count',
    number_search: baseUrl + '/registered-vehicles?filter[where][registrationNumber]={number}&filter[include][][relation]=vehicle',
    min_max_cc: baseUrl + '/vehicle-masters/getminmaxcc',
    uniqueVehicleNames: baseUrl + '/vehicle-masters/agg-unique-make-and-model',
    distinctCategories: baseUrl + '/vehicle-masters/distinct-categories',
    distinctMakeModel: baseUrl + '/vehicle-masters/distinct-make-and-model',
  },
  orders: {
    list: baseUrl + '/orders',
    count: baseUrl + '/orders/count',
    search: baseUrl + '/orders/{id}',
    // tslint:disable-next-line:max-line-length
    query: baseUrl + '/orders?filter[limit]=5&filter[where][or][0][custName][like]=%25{custName}%25&filter[where][or][1][custPhoneNumber][like]=%25{custPhoneNumber}%25&filter[where][or][2][id][like]=%25{id}%25',
    // tslint:disable-next-line:max-line-length
    closedQuery: baseUrl + '/orders?filter[limit]=5&filter[where][status][gt]=8&filter[where][or][0][custName][like]=%25{custName}%25&filter[where][or][1][custPhoneNumber][like]=%25{custPhoneNumber}%25&filter[where][or][2][id][like]=%25{id}%25',
    mapPath: mapUrl,
    reassign: baseUrl + '/orders/{id}/reassign',
    unassign: baseUrl + '/orders/{id}/unassign',
    paymentTypes: baseUrl + '/payment-types',
  },
  orderDetails: {
    list: baseUrl + '/order-details/',
    // count: baseUrl + '/order-details/count',
    notes: baseUrl + '/orderhistories',
    history: baseUrl + '/orderhistories?filter[where][orderId]={orderId}&filter[order][0]=id%20DESC',
    invoice: baseUrl + '/invoices/',
    invoice_service: baseUrl + '/invoices-service/{id}',
    invoice_adhoc_service: baseUrl + '/invoices-service/{id}/adhoc',
    transactions: baseUrl + '/transactions',
  },
  customers: {
    search: baseUrl + '/customers?filter[where][mobileNo][like]=%25{mobile}%25',
    list: baseUrl + '/customers/',
    count: baseUrl + '/customers/count',
  },
  discount: {
    list: baseUrl + '/discounts/',
  },
  mechanics: {
    list: baseUrl + '/vendors/',
    view: baseUrl + '/vendors/{id}',
  },
  settings: {
    services: baseUrl + '/services/',
    rates: baseUrl + '/rates/',
  },
};
