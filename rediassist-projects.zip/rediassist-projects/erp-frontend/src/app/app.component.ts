import { Component, HostBinding, OnInit, ChangeDetectorRef, Injector } from '@angular/core';

import { SettingsService } from './core/settings/settings.service';
import { MainService } from './core/services/main/main.service';
import { LoaderService } from './core/services/loader/loader.service';
import { Subscription } from 'rxjs';
import { LoaderState } from './core/services/loader/loader';
import { AuthService } from './core/services/auth/auth.service';
// import {WebsocketService} from './websocket.service';
import {WebsocketService} from 'src/app/websocket.service';
// Firebase App (the core Firebase SDK) is always required and must be listed first
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

    @HostBinding('class.layout-fixed') get isFixed() { return this.settings.getLayoutSetting('isFixed'); }
    @HostBinding('class.aside-collapsed') get isCollapsed() { return this.settings.getLayoutSetting('isCollapsed'); }
    @HostBinding('class.layout-boxed') get isBoxed() { return this.settings.getLayoutSetting('isBoxed'); }
    @HostBinding('class.layout-fs') get useFullLayout() { return this.settings.getLayoutSetting('useFullLayout'); }
    @HostBinding('class.hidden-footer') get hiddenFooter() { return this.settings.getLayoutSetting('hiddenFooter'); }
    @HostBinding('class.layout-h') get horizontal() { return this.settings.getLayoutSetting('horizontal'); }
    @HostBinding('class.aside-float') get isFloat() { return this.settings.getLayoutSetting('isFloat'); }
    @HostBinding('class.offsidebar-open') get offsidebarOpen() { return this.settings.getLayoutSetting('offsidebarOpen'); }
    @HostBinding('class.aside-toggled') get asideToggled() { return this.settings.getLayoutSetting('asideToggled'); }
    @HostBinding('class.create-task') get createTask() { return this.settings.getLayoutSetting('createTask'); }
    @HostBinding('class.aside-collapsed-text') get isCollapsedText() { return this.settings.getLayoutSetting('isCollapsedText'); }

    private subscription: Subscription;
    show: any = false;
    mainService
    constructor(
        private ws:WebsocketService,
        public settings: SettingsService, public main: MainService, public auth: AuthService,
        private loaderService: LoaderService, private cd: ChangeDetectorRef, private injector: Injector) {
        auth.checkToken();
        this.mainService = this.injector.get(MainService);
    }

    ngOnInit() {
        // Socket: notification from server side
        this.ws.getMessage()
        .subscribe((notification: string) => {
            this.mainService.showToast('success',notification);
        });

        // prevent empty links to reload the page
        document.addEventListener('click', e => {
            const target = e.target as HTMLElement;
            if (target.tagName === 'A' && ['', '#'].indexOf(target.getAttribute('href')) > -1) {
                e.preventDefault();
            }
        });
        this.subscription = this.loaderService.loaderState.subscribe((state: LoaderState) => {
            this.show = state.show;
            this.cd.detectChanges();
        });
    }
}
