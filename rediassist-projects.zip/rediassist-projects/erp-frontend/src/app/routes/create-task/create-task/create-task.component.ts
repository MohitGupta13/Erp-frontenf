/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild, ElementRef, NgZone, OnDestroy } from '@angular/core';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { FormGroup, FormBuilder, Validators, FormControl, ValidatorFn } from '@angular/forms';
import { CustomValidators } from 'ngx-custom-validators';
import { MapsAPILoader } from '@agm/core';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { Router } from '@angular/router';
import { servicesAvailable, dayMapJSONDetails, nightMapJSONDetails } from 'src/constant/data';
import { TabsetComponent } from 'ngx-bootstrap/tabs/public_api';
import * as moment from 'moment';
import { Observable, Observer, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead/typeahead-match.class';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import {WebsocketService} from 'src/app/websocket.service'
// import { GoogleMapsAPIWrapper } from '@agm/core';
declare const google: any;
@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.scss']
})
export class CreateTaskComponent implements OnInit, OnDestroy {

  @ViewChild('pickup')
  public pickupElementRef: ElementRef;
  @ViewChild('dropoff')
  public dropoffElementRef: ElementRef;
  @ViewChild('dateSlider') dateSlider: ElementRef;
  @ViewChild('dateTimeTabs', { static: false }) dateTimeTabs: TabsetComponent;
  @ViewChild('timeModal') timeModal: ModalDirective;
  taskForm: FormGroup;
  phone$: Observable<any[]>;
  vehicleRegNumber$: Observable<any[]>;
  vehicleMakeModel$: Observable<any[]>;
  pickup = {
    lat: 0,
    lng: 0
  };
  dropoff = {
    lat: 0,
    lng: 0
  };
  markers: any = [{
    lat: 12.790807,
    lng: 77.835734,
    icon: './assets/img/png/green-marker.png'
  }];
  zoom = 14;
  distance;
  estimatedTime;
  estimatedTrafficTime;
  scrollwheel = true;
  tentativeCost = 0;
  services: any = [];
  serviceType = '';
  locationId;
  bookingTime;
  serviceSelected;
  currentTime = new Date();
  mapJSON = (this.currentTime.getHours() >= 20 || this.currentTime.getHours() <= 7) ? nightMapJSONDetails : dayMapJSONDetails;
  public disabled = false;
  public toggleSlider = true;
  public servicesAvailable = servicesAvailable;
  serviceSlotInterval;
  serviceLeadInterval;
  orderTypes: any = [];
  subscription: any;
  subscription2: any;
  serviceDates: any = [];
  selectedDate = 0;
  selectedTime;
  move = 200;
  view;
  sliderLeftLimit = -650;
  sliderRightLimit = 0;
  currentPosition = 0;
  time = 0;
  timeSlots = {
    0: [],
    1: [],
    2: []
  };
  isTowing = false;
  // private directionsRenderer: any;
  latLong = false;
  constructor(
    private ws:WebsocketService,
    public settings: SettingsService,
    fb: FormBuilder,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private taskService: TasksService,
    public main: MainService,
    private router: Router,
    // private gmapsApi: GoogleMapsAPIWrapper
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.taskForm = fb.group({
      custName: [null, [Validators.required, Validators.pattern(this.main.namePattern)]],
      phone: [null, [Validators.required, Validators.pattern(this.main.mobileNoPattern)]],
      email: [null, Validators.compose([CustomValidators.email])],
      source: ['web', Validators.required],
      order_type: ['1', Validators.required],
      pickup: [null, Validators.required],
      drop: [{ value: null, disabled: true }],
      pickUpLat: ['', Validators.required],
      pickUpLng: ['', Validators.required],
      dropOffLat: [{ value: '', disabled: true }],
      dropOffLng: [{ value: '', disabled: true }],
      vehicle_reg_number: [null, [Validators.required, Validators.pattern(this.main.namePattern)]],
      vehicle_type: [null],
      vehicle_id: [0],
      vehicle_make_model: [null, Validators.required],
      service_type: [null, Validators.required],
      service_time: ['now', Validators.required],
    });

     


    this.subscription = this.main.getServiceList().subscribe((value: any) => {
      this.services = value;
      // console.log(this.services);
      for (const serviceCategory in this.servicesAvailable) {
        if (this.servicesAvailable.hasOwnProperty(serviceCategory)) {
          const serviceType = this.servicesAvailable[serviceCategory];
          serviceType.services = [];
        }
      }
      console.log(this.servicesAvailable);
      for (const service of this.services) {
        // console.log(service);
        // console.log(service.category);
        this.servicesAvailable[service.category].services.push(service);
        // console.log(this.servicesAvailable);
        const today = new Date();
        this.serviceDates = [];
        for ( let i = 0; i < 7; i++) {
          this.serviceDates.push(new Date(today));
          today.setDate(today.getDate() + 1);
        }
      }
    });
    this.subscription2 = this.main.getClientList().subscribe((value: any) => {
      this.orderTypes = value;
    });
  }
  
  //function for order created notification
  publishMessage(data:string){
    console.log(data)
    this.ws.publishMessage(data);
  };

  ngOnInit(): void {
    this.calculateCurrentTime();
    this.setCurrentPosition();
    this.mapsAPILoader.load().then(() => {
      const autocomplete = new google.maps.places.Autocomplete(this.pickupElementRef.nativeElement);
      autocomplete.setComponentRestrictions({ country: ['in'] });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place: google.maps.places.PlaceResult = autocomplete.getPlace();
          // console.log(place);
          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          // set latitude, longitude and zoom
          console.log(place);
          this.taskForm.patchValue({
            pickup: place.formatted_address,
            pickUpLat: place.geometry.location.lat(),
            pickUpLng: place.geometry.location.lng(),
          });
          this.pickup.lat = place.geometry.location.lat();
          this.pickup.lng = place.geometry.location.lng();
          this.markers[0] = {
            lat: this.pickup.lat,
            lng: this.pickup.lng,
            icon: './assets/img/png/green-marker.png'
          };
          // console.log(this.markers);
          this.zoom = 16;
          this.getLocationId();
        });
      });
      const autocomplete1 = new google.maps.places.Autocomplete(this.dropoffElementRef.nativeElement);
      autocomplete1.setComponentRestrictions({ country: ['in'] });
      autocomplete1.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place: google.maps.places.PlaceResult = autocomplete1.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          // set latitude, longitude and zoom
          this.taskForm.patchValue({
            drop: place.formatted_address,
            dropOffLat: place.geometry.location.lat(),
            dropOffLng: place.geometry.location.lng(),
          });
          this.dropoff.lat = place.geometry.location.lat();
          this.dropoff.lng = place.geometry.location.lng();
          this.zoom = 12;
          this.markers[1] = {
            lat: this.dropoff.lat,
            lng: this.dropoff.lng,
            icon: './assets/img/png/red-marker.png'
          };
          this.drawDirectionsRoute();
        });
      });
    });

    this.phone$ = new Observable((observer: Observer<string>) => {
      observer.next(this.taskForm.get('phone').value);
    }).pipe(
      switchMap((query: string) => {
        if (query) {
          return this.taskService.searchCustomer(query);
        }
        return of([]);
      })
    );
    this.vehicleRegNumber$ = new Observable((observer: Observer<string>) => {
      observer.next(this.taskForm.get('vehicle_reg_number').value.replace(/\s+/g, ''));
    }).pipe(
      switchMap((query: string) => {
        if (query) {
          return this.taskService.searchVehicle(query);
        }
        return of([]);
      })
    );
    this.vehicleMakeModel$ = new Observable((observer: Observer<string>) => {
      observer.next(this.taskForm.get('vehicle_make_model').value);
    }).pipe(
      switchMap((query: string) => {
        if (query) {
          return this.taskService.searchVehicle(query).pipe(map((data: any) => {
            data.map(item => {
              item.make_model = item.make + ' ' + item.model;
              return item;
            });
            return data;
          }));
        }
        return of([]);
      })
    );
  }

  getAddressFromLatLong(type) {
    let lat = 0;
    let lng = 0;
    if (type === 'pickUp') {
      lat = this.taskForm.get('pickUpLat').value;
      lng = this.taskForm.get('pickUpLng').value;
    } else {
      lat = this.taskForm.get('dropOffLat').value;
      lng = this.taskForm.get('dropOffLng').value;
    }
    console.log(lat, lng, type);
    if (lat && lng) {
      const geocoder = new google.maps.Geocoder();
      const latlng = new google.maps.LatLng(lat, lng);
      const request = { latLng: latlng };
      geocoder.geocode(request, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          const result = results[0];
          const rsltAdrComponent = result.address_components;
          // const resultLength = rsltAdrComponent.length;
          if (result != null) {
            // this.address = rsltAdrComponent[resultLength - 8].short_name;
            if (type === 'pickUp') {
              this.taskForm.patchValue({ pickup: result.formatted_address });
              this.pickup.lat = lat;
              this.pickup.lng = lng;
              this.markers[0] = {
                lat: this.pickup.lat,
                lng: this.pickup.lng,
                icon: './assets/img/png/green-marker.png'
              };
              // console.log(this.markers);
              this.zoom = 16;
              this.getLocationId();
            } else {
              this.taskForm.patchValue({ drop: result.formatted_address });
              this.dropoff.lat = lat;
              this.dropoff.lng = lng;
              this.zoom = 12;
              this.markers[1] = {
                lat: this.dropoff.lat,
                lng: this.dropoff.lng,
                icon: './assets/img/png/red-marker.png'
              };
              this.drawDirectionsRoute();
            }
          } else {
            alert('No address available!');
          }
        }
      });
    }
  }

  allowLatLong(value: any) {
    this.latLong = value.target.checked ? true : false;
  }

  getLocationId() {
    this.main.getLocations(this.pickup.lat, this.pickup.lng).subscribe(
            (data: any) => {
              // this.services = data;
              if (data.length === 0) {
                this.main.showToast('warning', 'No services available in this area');
                this.main.setServiceList([]);
                return false;
              } else {
                this.locationId = data[0]._id;
                this.checkServiceAvailability();
                if (this.taskForm.get('vehicle_id').value) {
                  this.getServices();
                }
              }
            },
            (error: any) => {
              console.log(error);
            }
          );
  }

  markerDragEnd($event, index) {
    const { lat, lng } = $event.coords;
    console.log(lat, lng);
    const geocoder = new google.maps.Geocoder();
    const latlng = new google.maps.LatLng(lat, lng);
    const request = {
      latLng: latlng
    };
    geocoder.geocode(request, (results, status) => {
      if (!index) {
        this.pickup.lat = lat;
        this.pickup.lng = lng;
        this.markers[0] = {
          lat: this.pickup.lat,
          lng: this.pickup.lng,
          icon: './assets/img/png/green-marker.png'
        };
        this.taskForm.patchValue({ pickup: results[0].formatted_address, pickUpLat: lat, pickUpLng: lng });
        this.getLocationId();
      } else {
        this.dropoff.lat = lat;
        this.dropoff.lng = lng;
        this.markers[1] = {
          lat: this.dropoff.lat,
          lng: this.dropoff.lng,
          icon: './assets/img/png/red-marker.png'
        };
        this.drawDirectionsRoute();
        this.taskForm.patchValue({ drop: results[0].formatted_address, dropOffLat: lat, dropOffLng: lng });
      }
    });
  }

  checkServiceAvailability() {
    if (this.taskForm.get('order_type').value && this.locationId) {
      this.taskService.checkService(this.locationId, parseInt(this.taskForm.get('order_type').value, 10)).subscribe(
      (data: any) => {
        // this.services = data;
        if (data.count === 0) {
          this.main.showToast('warning', 'No services available for this area and client');
          this.main.setServiceList([]);
          return false;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
    }
  }

  getServices() {
    if (!this.locationId) {
      this.main.showToast('warning', 'No services available in this area');
      this.main.setServiceList([]);
    }
    const params = {
      clientId: parseInt(this.taskForm.get('order_type').value, 10),
      locationId: this.locationId,
      vehicleId: parseInt(this.taskForm.get('vehicle_id').value, 10),
    };
    if (params.vehicleId) {
      const filter = `{"where":{"clientId":"${params.clientId}","locationId":${params.locationId},"vehicleId":${params.vehicleId}}}`;
      this.main.getServices(filter).subscribe(
        (data: any) => {
          // this.services = data;
          if (data.length === 0) {
            console.log(data.length);
            this.main.showToast('warning', 'No services available for this vehicle');
            this.main.setServiceList([]);
          } else {
            this.main.setServiceList(data);
          }
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onSelectPhone(event: TypeaheadMatch) {
    const customerData = event.item;
    this.taskForm.patchValue({
      email: customerData.email || '',
      custName: customerData.name || ''
    });
  }

  onSelectVehicleNumber(event: TypeaheadMatch) {
    const vehicleData = event.item;
    this.taskForm.patchValue({
      vehicle_make_model: vehicleData.vehicle_make + ' ' + vehicleData.vehicle_model,
      vehicle_type: vehicleData.vehicle_type,
    });
  }

  onSelectVehicle(event: TypeaheadMatch) {
    const vehicleData = event.item;
    this.taskForm.patchValue({
      vehicle_make_model: vehicleData.make + ' ' + vehicleData.model,
      vehicle_id: vehicleData.id
      // vehicle_type: vehicleData.vehicle_type
    });
    if (this.taskForm.get('pickup').value) {
      this.getServices();
    } else {
      // this.main.showToast('warming', 'Please choose a location');
    }
  }

  getVehicleName() {
    if (!this.taskForm.get('vehicle_make_model').value) {
      this.services = [];
      this.main.setServiceList([]);
      this.taskForm.patchValue({
        vehicle_make_model: '',
        vehicle_id: 0
      });
    } else {
      if (this.taskForm.get('pickup').value) {
        this.getServices();
      } else {
        // this.main.showToast('warning', 'Please choose a location');
      }
    }
  }

  phoneOnBlur(event: any) {
    // console.log(event.item);
  }

  vehicleOnBlur(event: any) {
    // console.log(event.item);
  }

  drawDirectionsRoute() {
    const origin = this.pickup.lat + ',' + this.pickup.lng;
    const destination = this.dropoff.lat + ',' + this.dropoff.lng;
    return new google.maps.DistanceMatrixService().getDistanceMatrix({
      origins: [origin],
      destinations: [destination],
      travelMode: 'DRIVING'
    }, (results: any) => {
        this.distance = results.rows[0].elements[0].distance.text;
        this.estimatedTime = results.rows[0].elements[0].duration.text;
        this.estimatedTrafficTime = results.rows[0].elements[0].duration_in_traffic.text;
    });
  //         // If you'll like to display an info window along the route
  //         // middleStep is used to estimate the midpoint on the route where the info window will appear
  //         // const middleStep = (response.routes[0].legs[0].steps.length / 2).toFixed();
  //         // const infowindow2 = new google.maps.InfoWindow();
  //         // infowindow2.setContent(`${response.routes[0].legs[0].distance.text} <br> ${response.routes[0].legs[0].duration.text}  `);
  //         // infowindow2.setPosition(response.routes[0].legs[0].steps[middleStep].end_location);
  //         // infowindow2.open(map);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.subscription2.unsubscribe();
  }

  setCurrentPosition() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.markers = [{
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          icon: './assets/img/png/green-marker.png'
        }];
      });
    }
  }

  submitForm($ev, value: any) {
    console.log(this.taskForm);
    $ev.preventDefault();
    for (const c in this.taskForm.controls) {
      if (this.taskForm.controls.hasOwnProperty(c)) {
        this.taskForm.controls[c].markAsTouched();
      }
    }
    if (this.taskForm.valid) {
      if (this.tentativeCost === 0) {
        this.main.showToast('warning', 'This service isn\'t available at the selected time, please choose another slot');
        return false;
      }
      const params = {
        // createdAt: new Date().toISOString(),
        // updatedAt: new Date().toISOString(),
        source: 'admin',
        platform: this.taskForm.get('source').value,
        orderAddress: this.taskForm.get('pickup').value,
        dropOffAddress: '',
        custName: this.taskForm.get('custName').value,
        custPhoneNumber: this.taskForm.get('phone').value,
        custEmail: this.taskForm.get('email').value || null,
        notes: 'waiting....',
        status: 1,
        // tag: "string",
        creationGeopoint: { lat: this.pickup.lat, lng: this.pickup.lng },
        taskGeopoint: { lat: this.pickup.lat, lng: this.pickup.lng },
        dropOffGeopoint: {},
        vehicleIdentificationNumber: this.taskForm.get('vehicle_reg_number')
          .value.replace(/\s+/g, ''),
        clientId: parseInt(this.taskForm.get('order_type').value, 10),
        serviceId: this.taskForm.get('service_type').value,
        vehicleId: this.taskForm.get('vehicle_id').value,
        bookingTime: moment.utc(new Date(this.bookingTime)),
        locationId: parseInt(this.locationId, 10)
      };
      if (this.isTowing) {
        params.dropOffAddress = this.taskForm.get('drop').value,
        params.dropOffGeopoint = { lat: this.dropoff.lat, lng: this.dropoff.lng };
      }
      // console.log(params);
      this.taskService.createTask(params)
        .subscribe((response: any) => {
          // console.log(response);
          this.main.showToast('success', `Task #${response.id} Created Successfully`);
          this.publishMessage(response.id);
          this.redirectToHome();
        }, (error: any) => {
          console.log(error);
        });
    } else {
      this.main.showToast('warning', 'Please fill all the required fields');
      return false;
    }
  }

  redirectToHome() {
    this.services = [];
    this.main.setServiceList([]);
    this.taskService.setUpdatedTasks(true);
    this.router.navigate(['home']);
  }

// If time is 1 and only day service is to be selected, we can't do that as no timeslots available for the night.
  // If we disable , we can't pick later,
  // If we enable and check later, we explicitly need to force Later option.



  selectService(serviceSelected, type) {
    // console.log(type);
    // console.log(serviceSelected);
    if (type.indexOf('TOWING') > -1 || serviceSelected.serviceCode.indexOf('TOWING') > -1) {
      this.isTowing = true;
      this.taskForm.get('drop').enable();
      this.taskForm.get('dropOffLat').enable();
      this.taskForm.get('dropOffLng').enable();
    } else {
      this.isTowing = false;
      this.distance = '';
      this.estimatedTrafficTime = '';
      this.estimatedTime = '';
      this.taskForm.patchValue({ drop: '', dropOffLat: '', dropOffLng: '' });
      this.dropoff = {
        lat: 0,
        lng: 0
      };
      if (this.markers[1]) {
        delete this.markers[1];
      }
      this.taskForm.get('drop').disable();
      this.taskForm.get('dropOffLat').disable();
      this.taskForm.get('dropOffLng').disable();
    }
    this.taskForm.patchValue({ service_type: serviceSelected.id });
    this.serviceSelected = serviceSelected;
    // booking time generated to immediate time and slots generated for today.
    this.generateTimeSlots();
    // mark service as selected and rest as non-selected
    for (const key in this.servicesAvailable) {
      if (this.servicesAvailable.hasOwnProperty(key)) {
        const serviceType = this.servicesAvailable[key];
        // console.log(serviceType);
        if (key === type) {
          serviceType.services = serviceType.services.map((service) => {
            return service.id === serviceSelected.id
              ? { ...service, selected: true }
              : { ...service, selected: false };
          });
        } else {
          serviceType.services = serviceType.services.map((service) => {
            return { ...service, selected: false };
          });
        }
        this.servicesAvailable[key] = serviceType;
      }
    }
  }

  updateBookingTime() {
    this.selectedDate = 0;
    this.selectedTime = '';
    this.generateTimeSlots();
  }

  calculateCurrentTime() {
    let current;
    let today8PM;
    let today8AM;
    if (this.bookingTime) {
      current = new Date(this.bookingTime);
      today8AM = new Date(this.bookingTime);
      today8PM = new Date(this.bookingTime);
    } else {
      current = new Date();
      today8AM = new Date();
      today8PM = new Date();
    }
    today8AM.setHours(8, 0, 0);
    today8PM.setHours(20, 0, 0);
    if (current.getTime() >= today8AM.getTime() && current.getTime() < today8PM.getTime()) {
      this.time = 0;
    } else {
      this.time = 1;
    }
    if (this.serviceSelected) {
      this.calculateCost();
    }
  }

  calculateCost() {
    let cost;
    if (this.time === 0) {
      cost = this.serviceSelected.dayCharge;
    } else {
      cost = this.serviceSelected.nightCharge;
    }
    cost += (cost * this.serviceSelected.tax) / 100;
    this.tentativeCost = cost;
  }

  generateTimeSlots() {
    const interval = this.serviceSelected.intervalTime;
    const leadTime = this.serviceSelected.leadTime;
    const startTime = new Date(this.serviceDates[this.selectedDate]);
    if (this.selectedDate === 0) {
      startTime.setMinutes(startTime.getMinutes() + leadTime);
      if (startTime.getMinutes() < 30) {
        startTime.setMinutes(30, 0);
      } else {
        startTime.setHours(startTime.getHours() + 1);
        startTime.setMinutes(0, 0);
      }
      this.bookingTime = new Date(startTime);
    } else {
      startTime.setHours(0, 0, 0);
    }
    this.calculateCurrentTime();
    const endTime = new Date(this.serviceDates[this.selectedDate]);
    endTime.setHours(23, 59, 59);
    const dayStart = new Date(this.serviceDates[this.selectedDate]);
    dayStart.setHours(8, 0, 0);
    const dayEnd = new Date(this.serviceDates[this.selectedDate]);
    dayEnd.setHours(19, 59, 59);
    this.timeSlots[0] = [];
    this.timeSlots[1] = [];
    this.timeSlots[2] = [];
    while (startTime.getTime() <= endTime.getTime()) {
      if (startTime.getTime() < dayStart.getTime() && this.serviceSelected.nightCharge) {
        this.timeSlots[0].push(moment(startTime).format('HH:mm'));
      } else if (startTime.getTime() >= dayStart.getTime() && startTime.getTime() < dayEnd.getTime() && this.serviceSelected.dayCharge) {
        this.timeSlots[1].push(moment(startTime).format('HH:mm'));
      } else if (startTime.getTime() >= dayEnd.getTime() && this.serviceSelected.nightCharge) {
        this.timeSlots[2].push(moment(startTime).format('HH:mm'));
      }
      startTime.setMinutes(startTime.getMinutes() + interval);
    }
  }

  toggleAssignSlider(val: boolean) {
    this.toggleSlider = !val;
    console.log(val);
    const status = {
      show: val,
      mode: 0,
      task: {}
    };
    this.main.setAssignSliderStatus(status);
  }

  openTimeslotModal() {
    this.timeModal.show();
    this.initModal();
  }

  initModal() {
    this.view = this.dateSlider.nativeElement;
  }
  moveDate(mode: any) {
    let moveTo;
    if (mode === 'left') {
      // Clicked on Left, so slider will move towards Right
      if (this.currentPosition < this.sliderRightLimit) {
        moveTo = (this.currentPosition + this.move);
        this.animate(moveTo);
        this.currentPosition += this.move;
      }
    } else {
      // Clicked on Right, so slider will move towards Left
      if (this.currentPosition >= this.sliderLeftLimit) {
        moveTo = (this.currentPosition - this.move);
        this.animate(moveTo);
        this.currentPosition -= this.move;
      }
    }
  }

  animate(moveTo) {
    this.view.animate(
      [
        { transform: 'translateX(' + this.currentPosition + 'px)' },
        { transform: 'translateX(' + moveTo + 'px)' },
      ],
      {
        duration: 400,
        delay: 0,
        fill: 'both',
        easing: 'ease-in-out'
      }
    );
  }

  selectDate(index: number) {
    this.selectedDate = index;
    this.generateTimeSlots();
  }

  selectTimeSlot(slot) {
    this.selectedTime = slot;
    this.timeModal.hide();
    const time = slot.split(':');
    const startTime = new Date(this.serviceDates[this.selectedDate]);
    startTime.setHours(parseInt(time[0], 10), parseInt(time[1], 10), 0);
    this.bookingTime = startTime;
    this.calculateCurrentTime();
  }

  findCustomer() {
    const customer = this.taskForm.get('phone').value;
    if (customer) {
      this.taskService.searchCustomer(customer)
        .subscribe((data: any) => {
          // console.log(data);
          const customerData = data[0];
          if (customerData) {
            this.taskForm.patchValue({
              email: customerData.email || '',
              custName: customerData.name || ''
            });
          } else {
            this.taskForm.patchValue({
              email: '',
              custName: ''
            });
          }
        }, (error: any) => {
          console.log(error);
        });
    }
  }
  findVehicle() {
    const vehicle = this.taskForm.get('vehicle_reg_number').value.replace(/\s+/g, '');
    if (vehicle) {
      this.taskService.searchVehicleNumber(vehicle)
        .subscribe((data: any) => {
          const vehicleData = data[0];
          this.taskForm.patchValue({
              service_type: null
          });
          if (vehicleData?.vehicle) {
            this.taskForm.get('vehicle_make_model').disable();
            this.taskForm.patchValue({
              vehicle_make_model: vehicleData.vehicle.make + ' ' + vehicleData.vehicle.model,
              vehicle_id: vehicleData.vehicle.id
              // vehicle_type: vehicleData.vehicle_type
            });
            if (this.taskForm.get('pickup').value) {
              this.getServices();
            }
          } else {
            this.taskForm.get('vehicle_make_model').enable();
            this.taskForm.patchValue({
              vehicle_make_model: ''
            });
            this.services = [];
            this.serviceSelected = {};
          }
        }, (error: any) => {
          console.log(error);
        });
    }
  }
}
