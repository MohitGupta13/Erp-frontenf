import { Component, OnInit, ViewChild } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ServicesService } from 'src/app/core/services/services/services.service';
import { serviceCategory,serviceSubCategory, serviceCodes, leadTimes, intervalTimes } from 'src/constant/data';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { Observable, Observer, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { VehiclesService } from 'src/app/core/services/vehicles/vehicles.service';
@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockServiceModal') blockUnblockServiceModal: ModalDirective;
  @ViewChild('addEditServiceModal') addEditServiceModal: ModalDirective;
  table = {
    currentPage: 1,
    numPages: 0
  };
  serviceColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true },
    { headerName: 'Name', field: 'name', sortable: true, filter: true },
    { headerName: 'Description', field: 'description', sortable: true, filter: true },
    { headerName: 'Client', field: 'clientId', sortable: true, filter: true },
    { headerName: 'Location', field: 'locationId', sortable: true, filter: true },
    { headerName: 'Vehicle', field: 'vehicleId', sortable: true, filter: true },
    { headerName: 'Service Code', field: 'serviceCode', sortable: true, filter: true },
    { headerName: 'Category', field: 'category', sortable: true, filter: true },
    { headerName: 'SubCategory', field: 'subCategory', sortable: true, filter: true },
    { headerName: 'Display To Customer', field: 'displayToCustomer', sortable: true, filter: true },
    { headerName: 'Lead Time (mins)', field: 'leadTime', sortable: true, filter: true },
    { headerName: 'Interval Time (mins)', field: 'intervalTime', sortable: true, filter: true },
    { headerName: 'Day Charge (Rs)', field: 'dayCharge', sortable: true, filter: true },
    { headerName: 'Night Charge (Rs)', field: 'nightCharge', sortable: true, filter: true },
    { headerName: 'Tax (%)', field: 'tax', sortable: true, filter: true },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editService: this.editService.bind(this),
        blockService: this.blockService.bind(this),
        unblockService: this.unblockService.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  serviceForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  serviceRows = [];
  addMode = 'Add';
  service;
  serviceRowsCount = 0;
  serviceSubCategory = serviceSubCategory;
  serviceCategory = serviceCategory;
  serviceCodes = serviceCodes;
  leadTimes = leadTimes;
  intervalTimes = intervalTimes;
  clientSubscription;
  clients = [];
  locationSubscription;
  locations = [];
  vehicleMakeModel$: Observable<any[]>;
  skip = 0;
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public servicesService: ServicesService,
    public taskService: TasksService,
    public vehicleService: VehiclesService,
    fb: FormBuilder,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.serviceForm = fb.group({
      name: ['', [Validators.required, Validators.pattern(this.main.namePattern), Validators.minLength(3),Validators.maxLength(30)]],
      description: ['',[ Validators.required, Validators.pattern(this.main.namePattern), Validators.minLength(3)]],
      category: ['', Validators.required],
      subCategory: ['', Validators.required],
      serviceCode: ['', Validators.required],
      leadTime: [this.leadTimes[0], Validators.required],
      intervalTime: [this.intervalTimes[0], Validators.required],
      dayCharge: [0, Validators.required],
      nightCharge: [0, Validators.required],
      tax: [0, Validators.required],
      clientId: [null, Validators.required],
      locationId: [null, Validators.required],
      vehicleId: [null, Validators.required],
      vendorId: [null],
      isActive: [false, Validators.required],
      displayToCustomer: [false, Validators.required],
      vehicle_make_model: ['']
    });
  }

  ngOnInit(): void {
    this.getServicesCount();
    this.getServices(this.skip);
    this.clientSubscription = this.main.getClientList().subscribe((value: any) => {
      this.clients = value;
    });
    this.locationSubscription = this.main.getLocationList().subscribe((value: any) => {
      this.locations = value;
    });
    this.vehicleMakeModel$ = new Observable((observer: Observer<string>) => {
      observer.next(this.serviceForm.get('vehicle_make_model').value);
    }).pipe(
      switchMap((query: string) => {
        if (query) {
          return this.taskService.searchVehicle(query).pipe(map((data: any) => {
            data.map(item => {
              item.make_model = item.make + ' ' + item.model;
              return item;
            });
            return data;
          }));
        }
        return of([]);
      })
    );
  }

  addService() {
    // this.servicesService.setModalFlag(true);
    this.formReset();
    this.addEditServiceModal.show();
  }

  getServices(skip = 0) {
    this.skip = skip;
    this.servicesService.serviceList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.serviceRows = data;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getServicesCount() {
    this.servicesService.serviceCount().subscribe(
      (data: any) => {
        this.serviceRowsCount = data.count;
        this.table.numPages = Math.ceil(this.serviceRowsCount / 10);
        if (this.serviceRowsCount % 10 > 0) {
          this.table.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getServices(skip);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitServiceForm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.serviceForm);
    this.saveService();
  }

  saveService() {
    if (this.serviceForm.valid) {
      let params = {
        name: this.serviceForm.get('name').value,
        description: this.serviceForm.get('description').value,
        category: this.serviceForm.get('category').value,
        subCategory: this.serviceForm.get('subCategory').value,
        clientId: this.serviceForm.get('clientId').value ? parseInt(this.serviceForm.get('clientId').value, 10) : 0,
        dayCharge: this.serviceForm.get('dayCharge').value,
        displayToCustomer: this.serviceForm.get('displayToCustomer').value,
        intervalTime: this.serviceForm.get('intervalTime').value,
        leadTime: this.serviceForm.get('leadTime').value,
        locationId: this.serviceForm.get('locationId').value ? parseInt(this.serviceForm.get('locationId').value, 10) : 0,
        nightCharge: this.serviceForm.get('nightCharge').value,
        serviceCode: this.serviceForm.get('serviceCode').value,
        tax: this.serviceForm.get('tax').value,
        vehicleId: this.serviceForm.get('vehicleId').value ? parseInt(this.serviceForm.get('vehicleId').value, 10) : 0,
        // vendorId: null,
        isActive: true
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.servicesService.createService(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getServicesCount();
          this.getServices(this.skip);
          this.main.showToast('success', 'Service Created Successfully');
          this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Service name exists already');
          }
        });
      } else {
        params = { ...params, isActive: this.service.isActive };
        this.servicesService.editService(params, this.service.id).subscribe(
        (response: any) => {
            this.getServices(this.skip);
            this.main.showToast('success', 'Service Saved Successfully');
            this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Service name exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  closeModal() {
    this.addEditServiceModal.hide();
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.serviceForm.patchValue({
      name: '',
      description: '',
      category: '',
      subCategory: '',
      clientId: null,
      dayCharge: 0,
      displayToCustomer: false,
      intervalTime: this.intervalTimes[0],
      isActive: false,
      leadTime: this.leadTimes[0],
      locationId: null,
      nightCharge: 0,
      serviceCode: '',
      tax: 0,
      vehicleId: null,
      vendorId: null
    });
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        form.controls[c].markAsPristine();
      }
    }
  }

  editService(rowData, mode = 1) {
    this.serviceForm.enable();
    this.service = rowData;
    this.serviceForm.patchValue({
      name: this.service.name,
      description: this.service.description,
      category: this.service.category,
      subCategory: this.service.subCategory,
      clientId: this.service.clientId,
      dayCharge: this.service.dayCharge,
      displayToCustomer: this.service.displayToCustomer,
      intervalTime: this.service.intervalTime,
      isActive: this.service.isActive,
      leadTime: this.service.leadTime,
      locationId: this.service.locationId,
      nightCharge: this.service.nightCharge,
      serviceCode: this.service.serviceCode,
      tax: this.service.tax,
      vehicleId: this.service.vehicleId,
      vendorId: this.service.vendorId,
    });
    this.addEditServiceModal.show();
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.serviceForm.disable();
    }
    this.vehicleService.getVehicle(this.service.vehicleId).subscribe(
      (data: any) => {
        const item = data;
        this.serviceForm.patchValue({
          vehicle_make_model: item.make + ' ' + item.model
        });
        },
        (error: any) => {
          console.log(error);
        });
  }

  blockService(rowData) {
    this.blockMode = 'Block';
    this.service = rowData;
    this.blockUnblockServiceModal.show();
  }

  unblockService(rowData) {
    this.blockMode = 'Unblock';
    this.service = rowData;
    this.blockUnblockServiceModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.service = {};
    this.blockUnblockServiceModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
        // notes: this.blockForm.get('notes').value,
        // activationDate: null
      };
      // if (params.isActive) {
      //   params.activationDate = moment.utc(new Date());
      // } else {
      //   delete params.activationDate;
      // }
      this.servicesService.blockUnblockConfirm(params, this.service.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockServiceModal.hide();
          this.getServices(this.skip);
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editService(data, 1);
        case 'block':
          return this.blockService(data);
        case 'unblock':
          return this.unblockService(data);
        case null:
          return this.editService(data, 2);
      }
    }
  }

  onSelectVehicle(event: TypeaheadMatch) {
    const vehicleData = event.item;
    this.serviceForm.patchValue({
      vehicleId: vehicleData.id
    });
  }

  getVehicleName() {
    if (!this.serviceForm.get('vehicle_make_model').value) {
      this.serviceForm.patchValue({
        vehicleId: 0
      });
    }
  }

}
