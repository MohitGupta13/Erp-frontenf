import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicesComponent } from './services/services.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActionCellComponent } from './action-cell/action-cell.component';

const routes: Routes = [
  { path: '', component: ServicesComponent },
];


@NgModule({
  declarations: [ServicesComponent, ActionCellComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
  ],
  exports: [
    RouterModule
  ]
})
export class ServicesModule { }
