import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslatorService } from '../core/translator/translator.service';
import { MenuService } from '../core/menu/menu.service';
import { SharedModule } from '../shared/shared.module';

import { menu } from './menu';
import { routes } from './routes';
import { PagesModule } from './pages/pages.module';
import { InterceptorService } from '../core/services/interceptor/interceptor.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import {WebsocketService} from '../websocket.service'

@NgModule({
    imports: [
        SharedModule,
        PagesModule,
        RouterModule.forRoot(routes)
    ],
    declarations: [],
    exports: [
        RouterModule
    ],
    providers: [
        WebsocketService,
        {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    }]
})

export class RoutesModule {
    constructor(public menuService: MenuService, tr: TranslatorService) {
        menuService.addMenu(menu);
    }
}
