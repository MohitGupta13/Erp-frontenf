
const Home = {
    text: 'Home',
    link: '/home',
    icon: 'icon-home'
};

const Vendors = {
    text: 'Vendors',
    link: '/vendors',
    icon: 'icon-people'
};

const Clients = {
    text: 'Clients',
    link: '/clients',
    icon: 'icon-people'
};

const Teams = {
    text: 'Teams',
    link: '/teams',
    icon: 'icon-organization'
};

const Customers = {
    text: 'Customers',
    link: '/customers',
    icon: 'icon-user'
};

const Vehicles = {
    text: 'Vehicles',
    link: '/vehicles',
    icon: 'icon-disc'
};

const Services = {
    text: 'Services',
    link: '/services',
    icon: 'icon-list'
};

const Locations = {
    text: 'Locations',
    link: '/locations',
    icon: 'icon-location-pin'
};

// export const menu = [
//     // headingMain,
//     Home,
//     Vendors,
//     Clients,
//     Teams,
//     Customers,
//     Vehicles,
//     Services,
//     Locations
// ];

export const menu = [
    // headingMain,
    Home,
    Vendors,
];
