import { Component, OnInit, ViewChild } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { TeamsService } from 'src/app/core/services/teams/teams.service';
@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.scss']
})
export class TeamsComponent implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockTeamModal') blockUnblockTeamModal: ModalDirective;
  @ViewChild('addEditTeamModal') addEditTeamModal: ModalDirective;
  table = {
    currentPage: 1,
    numPages: 0
  };
  teamColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true },
    { headerName: 'Name', field: 'name', sortable: true, filter: true },
    { headerName: 'Description', field: 'description', sortable: true, filter: true },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editTeam: this.editTeam.bind(this),
        blockTeam: this.blockTeam.bind(this),
        unblockTeam: this.unblockTeam.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  teamForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  teamRows = [];
  addMode = 'Add';
  team;
  teamRowsCount = 0;
  skip = 0;
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public teamsService: TeamsService,
    fb: FormBuilder,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.teamForm = fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.getTeamsCount();
    this.getTeams(this.skip);
  }

  addTeam() {
    // this.teamsService.setModalFlag(true);
    this.formReset();
    this.addEditTeamModal.show();
  }

  getTeams(skip = 0) {
    this.skip = skip;
    this.teamsService.teamList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.teamRows = data;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getTeamsCount() {
    this.teamsService.teamCount().subscribe(
      (data: any) => {
        this.teamRowsCount = data.count;
        this.table.numPages = Math.ceil(this.teamRowsCount / 10);
        if (this.teamRowsCount % 10 > 0) {
          this.table.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getTeams(skip);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitTeamForm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.teamForm);
    this.saveTeam();
  }

  saveTeam() {
    if (this.teamForm.valid) {
      let params = {
        name: this.teamForm.get('name').value,
        description: this.teamForm.get('description').value,
        isActive: true
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.teamsService.createTeam(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getTeamsCount();
          this.getTeams(this.skip);
          this.main.showToast('success', 'Team Created Successfully');
          this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Team name exists already');
          }
        });
      } else {
        params = { ...params, isActive: this.team.isActive };
        this.teamsService.editTeam(params, this.team.id).subscribe(
        (response: any) => {
            this.getTeams(this.skip);
            this.main.showToast('success', 'Team Saved Successfully');
            this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Team name exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  closeModal() {
    this.addEditTeamModal.hide();
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.teamForm.patchValue({
      name: '',
      description: ''
    });
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        form.controls[c].markAsPristine();
      }
    }
  }

  editTeam(rowData, mode = 1) {
    this.teamForm.enable();
    this.team = rowData;
    this.teamForm.patchValue({
      name: this.team.name,
      description: this.team.description,
    });
    this.addEditTeamModal.show();
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.teamForm.disable();
    }
  }

  blockTeam(rowData) {
    this.blockMode = 'Block';
    this.team = rowData;
    this.blockUnblockTeamModal.show();
  }

  unblockTeam(rowData) {
    this.blockMode = 'Unblock';
    this.team = rowData;
    this.blockUnblockTeamModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.team = {};
    this.blockUnblockTeamModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
        // notes: this.blockForm.get('notes').value,
        // activationDate: null
      };
      // if (params.isActive) {
      //   params.activationDate = moment.utc(new Date());
      // } else {
      //   delete params.activationDate;
      // }
      this.teamsService.blockUnblockConfirm(params, this.team.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockTeamModal.hide();
          this.getTeams(this.skip);
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editTeam(data, 1);
        case 'block':
          return this.blockTeam(data);
        case 'unblock':
          return this.unblockTeam(data);
        case null:
          return this.editTeam(data, 2);
      }
    }
  }

}
