import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TeamsComponent } from './teams/teams.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActionCellComponent } from './action-cell/action-cell.component';

const routes: Routes = [
  { path: '', component: TeamsComponent },
];


@NgModule({
  declarations: [TeamsComponent, ActionCellComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
  ],
  exports: [
    RouterModule
  ]
})
export class TeamsModule { }
