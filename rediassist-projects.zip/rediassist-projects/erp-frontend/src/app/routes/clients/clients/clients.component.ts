import { Component, OnInit, ViewChild } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ClientsService } from 'src/app/core/services/clients/clients.service';
@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.scss']
})
export class ClientsComponent implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockClientModal') blockUnblockClientModal: ModalDirective;
  @ViewChild('addEditClientModal') addEditClientModal: ModalDirective;
  table = {
    currentPage: 1,
    numPages: 0
  };
  clientColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true },
    { headerName: 'Name', field: 'name', sortable: true, filter: true },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editClient: this.editClient.bind(this),
        blockClient: this.blockClient.bind(this),
        unblockClient: this.unblockClient.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  clientForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  clientRows = [];
  addMode = 'Add';
  client;
  clientRowsCount = 0;
  skip = 0;
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public clientsService: ClientsService,
    fb: FormBuilder,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.clientForm = fb.group({
      name: ['', [Validators.required, Validators.pattern(this.main.namePattern), Validators.minLength(3),Validators.maxLength(30)]]
    });
  }

  ngOnInit(): void {
    this.getClientsCount();
    this.getClients(this.skip);
  }

  addClient() {
    // this.clientsService.setModalFlag(true);
    this.formReset();
    this.addEditClientModal.show();
  }

  getClients(skip = 0) {
    this.skip = skip;
    this.clientsService.clientList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.clientRows = data;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getClientsCount() {
    this.clientsService.clientCount().subscribe(
      (data: any) => {
        this.clientRowsCount = data.count;
        this.table.numPages = Math.ceil(this.clientRowsCount / 10);
        if (this.clientRowsCount % 10 > 0) {
          this.table.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getClients(skip);
  }  

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitClientForm($ev) {
    $ev.preventDefault();
    this.saveClient();
  }

  saveClient() {
    this.resetFormControls(this.clientForm);
    if (this.clientForm.valid) {
      let params = {
        name: this.clientForm.get('name').value,
        isActive: true
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.clientsService.createClient(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getClients(this.skip);
          this.getClientsCount();
          this.main.showToast('success', 'Client Created Successfully');
          this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Client name exists already, please enter a unique name');
          }
        });
      } else {
        params = { ...params, isActive: this.client.isActive };
        this.clientsService.editClient(params, this.client.id).subscribe(
        (response: any) => {
            this.getClients(this.skip);
            this.main.showToast('success', 'Client Saved Successfully');
            this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Client name exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  closeModal() {
    this.addEditClientModal.hide();
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.clientForm.patchValue({
      name: ''
    });
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        // form.controls[c].markAsPristine();
      }
    }
  }

  editClient(rowData, mode = 1) {
    this.clientForm.enable();
    this.client = rowData;
    this.clientForm.patchValue({
      name: this.client.name
    });
    this.addEditClientModal.show();
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.clientForm.disable();
    }
  }

  blockClient(rowData) {
    this.blockMode = 'Block';
    this.client = rowData;
    this.blockUnblockClientModal.show();
  }

  unblockClient(rowData) {
    this.blockMode = 'Unblock';
    this.client = rowData;
    this.blockUnblockClientModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.client = {};
    this.blockUnblockClientModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
      };
      this.clientsService.blockUnblockConfirm(params, this.client.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockClientModal.hide();
          this.getClients(this.skip);
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editClient(data, 1);
        case 'block':
          return this.blockClient(data);
        case 'unblock':
          return this.unblockClient(data);
        case null:
          return this.editClient(data, 2);
      }
    }
  }

}
