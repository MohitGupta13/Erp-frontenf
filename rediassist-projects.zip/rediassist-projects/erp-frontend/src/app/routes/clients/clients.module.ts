import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientsComponent } from './clients/clients.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActionCellComponent } from './action-cell/action-cell.component';

const routes: Routes = [
  { path: '', component: ClientsComponent },
];


@NgModule({
  declarations: [ClientsComponent, ActionCellComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
  ],
  exports: [
    RouterModule
  ]
})
export class ClientsModule { }
