import { Component } from '@angular/core';
import { AgRendererComponent } from 'ag-grid-angular';

@Component({
  selector: 'app-action-cell',
  templateUrl: './action-cell.component.html',
  styleUrls: ['./action-cell.component.scss']
})
export class ActionCellComponent implements AgRendererComponent {

  data: any;
  params: any;
  constructor() {}

  agInit(params) {
    this.params = params;
    this.data = params.data;
  }

  refresh(params: any): boolean {
    return false;
  }

  editClient() {
    this.params.editClient(this.data);
  }

  blockClient() {
    this.params.blockClient(this.data);
  }

  unblockClient() {
    this.params.unblockClient(this.data);
  }
}
