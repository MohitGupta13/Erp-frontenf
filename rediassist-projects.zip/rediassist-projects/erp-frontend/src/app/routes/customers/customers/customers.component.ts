import { Component, OnInit, ViewChild } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { CustomersService } from 'src/app/core/services/customers/customers.service';
import { CustomValidators } from 'ngx-custom-validators';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockCustomerModal') blockUnblockCustomerModal: ModalDirective;
  @ViewChild('addEditCustomerModal') addEditCustomerModal: ModalDirective;
  table = {
    currentPage: 1,
    numPages: 0
  };
  customerColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true },
    { headerName: 'Name', field: 'name', sortable: true, filter: true },
    { headerName: 'Email', field: 'email', sortable: true, filter: true },
    { headerName: 'Mobile Number', field: 'mobileNo', sortable: true, filter: true },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editCustomer: this.editCustomer.bind(this),
        blockCustomer: this.blockCustomer.bind(this),
        unblockCustomer: this.unblockCustomer.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  customerForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  customerRows = [];
  addMode = 'Add';
  customer;
  customerRowsCount = 0;
  skip = 0;
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public customersService: CustomersService,
    fb: FormBuilder,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.customerForm = fb.group({
      name: ['', [Validators.required, Validators.pattern(this.main.namePattern)]],
      mobileNo: ['', [Validators.required, Validators.pattern(this.main.mobileNoPattern)]],
      email: ['', [Validators.required,Validators.pattern(this.main.emailPattern)]],
    });
  }

  ngOnInit(): void {
    this.getCustomersCount();
    this.getCustomers(this.skip);
  }

  addCustomer() {
    // this.customersService.setModalFlag(true);
    this.formReset();
    this.addEditCustomerModal.show();
  }

  getCustomers(skip = 0) {
    this.skip = skip;
    this.customersService.customerList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.customerRows = data;
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getCustomersCount() {
    this.customersService.customerCount().subscribe(
      (data: any) => {
        this.customerRowsCount = data.count;
        this.table.numPages = Math.ceil(this.customerRowsCount / 10);
        if (this.customerRowsCount % 10 > 0) {
          this.table.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getCustomers(skip);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitCustomerForm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.customerForm);
    this.saveCustomer();
  }

  saveCustomer() {
    if (this.customerForm.valid) {
      let params = {
        name: this.customerForm.get('name').value,
        email: this.customerForm.get('email').value,
        mobileNo: this.customerForm.get('mobileNo').value,
        isActive: true
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.customersService.createCustomer(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getCustomersCount();
          this.getCustomers(this.skip);
          this.main.showToast('success', 'Customer Created Successfully');
          this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Customer name exists already');
          }
        });
      } else {
        params = { ...params, isActive: this.customer.isActive };
        this.customersService.editCustomer(params, this.customer.id).subscribe(
        (response: any) => {
            this.getCustomers(this.skip);
            this.main.showToast('success', 'Customer Saved Successfully');
            this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Customer name exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  closeModal() {
    this.addEditCustomerModal.hide();
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.customerForm.patchValue({
      name: '',
      email: '',
      mobileNo: '',
    });
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        form.controls[c].markAsPristine();
      }
    }
  }

  editCustomer(rowData, mode = 1) {
    this.customerForm.enable();
    this.customer = rowData;
    this.customerForm.patchValue({
      name: this.customer.name,
      email: this.customer.email,
      mobileNo: this.customer.mobileNo,
    });
    this.addEditCustomerModal.show();
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.customerForm.disable();
    }
  }

  blockCustomer(rowData) {
    this.blockMode = 'Block';
    this.customer = rowData;
    this.blockUnblockCustomerModal.show();
  }

  unblockCustomer(rowData) {
    this.blockMode = 'Unblock';
    this.customer = rowData;
    this.blockUnblockCustomerModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.customer = {};
    this.blockUnblockCustomerModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
        // notes: this.blockForm.get('notes').value,
        // activationDate: null
      };
      // if (params.isActive) {
      //   params.activationDate = moment.utc(new Date());
      // } else {
      //   delete params.activationDate;
      // }
      this.customersService.blockUnblockConfirm(params, this.customer.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockCustomerModal.hide();
          this.getCustomers(this.skip);
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editCustomer(data, 1);
        case 'block':
          return this.blockCustomer(data);
        case 'unblock':
          return this.unblockCustomer(data);
        case null:
          return this.editCustomer(data, 2);
      }
    }
  }

}
