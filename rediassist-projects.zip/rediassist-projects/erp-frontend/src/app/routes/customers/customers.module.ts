import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './customers/customers.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActionCellComponent } from './action-cell/action-cell.component';

const routes: Routes = [
  { path: '', component: CustomersComponent },
];

@NgModule({
  declarations: [CustomersComponent, ActionCellComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
  ],
  exports: [
    RouterModule
  ]
})

export class CustomersModule { }
