/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild } from '@angular/core';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { dayMapJSON, dayMapJSONDetails, nightMapJSON, nightMapJSONDetails, cancelOptions } from 'src/constant/data';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { ModalDirective, BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

declare const google: any;
import * as moment from 'moment';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
import { Task } from '../../../shared/interfaces/tasks.interface';
import { WebsocketService } from 'src/app/websocket.service';

import { AssignMechanicComponent } from 'src/app/layout/assign-mechanic/assign-mechanic.component';
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    providers: [NgbModal]
})
export class HomeComponent implements OnInit {
    task: Task;
    map;
    defaultLat = 12.9716;
    defaultLng = 77.5946;
    lat = 12.9716;
    lng = 77.5946;
    zoom = 12;
    fitBounds = true;
    scrollwheel = true;
    taskMarkers = [];
    mechanicMarkers = [];
    markersBackup = {
        taskMarkers: [],
        mechanicMarkers: []
    };
    currentTask;
    status;
    currentTime = new Date();
    mapJSON = (this.currentTime.getHours() >= 20 || this.currentTime.getHours() <= 7) ? nightMapJSON : dayMapJSON;
    mapJSONDetails = (this.currentTime.getHours() >= 20 || this.currentTime.getHours() <= 7) ? nightMapJSONDetails : dayMapJSONDetails;
    cancelOptions = cancelOptions;
    bookingTimeChange = false;
    @ViewChild('statusChangeModal') statusChangeModal: ModalDirective;
    @ViewChild('cancelOrderModel') cancelOrderModel: ModalDirective;
    @ViewChild('bookingTimeChangeModal') bookingTimeChangeModal: ModalDirective;
    statusForm: FormGroup;
    mechanicSubscription: Subscription;
    showPath = false;
    bookingTime;
    serviceSubscription;
    services = [];
    serviceSelected;
    serviceSlotInterval;
    serviceLeadInterval;
    serviceDates = [];
    selectedDate = 0;
    selectedTime;
    move = 200;
    view;
    sliderLeftLimit = -650;
    sliderRightLimit = 0;
    currentPosition = 0;
    time = 0;
    selectedCancelOption = null;
    timeSlots = {
        0: [],
        1: [],
        2: []
    };
    tentativeCost = 0;
    oldStatus = null;

    constructor(public settings: SettingsService, public main: MainService, public taskService: TasksService, fb: FormBuilder,
        private modal: BsModalService, public mechanicService: MechanicsService, private ws: WebsocketService,
        private modalService: NgbModal) {
        this.settings.setLayoutSetting('offsidebarOpen', true);
        this.settings.setLayoutSetting('isCollapsed', false);
        this.main.getTaskMarkers().subscribe((data: any) => {
            this.taskMarkers = data;
            this.adjustZoom(this.defaultLat, this.defaultLng, 12);
        });
        this.main.getMechanicMarkers().subscribe((data: any) => {
            this.mechanicMarkers = data;
            this.adjustZoom(this.defaultLat, this.defaultLng, 12);
        });
        this.taskService.getCurrentTask().subscribe((task: any) => {
            console.log("get crnt task in model ---", task);
            if (Object.keys(task).length !== 0) {
                var lat, lng;
                if (task && task.taskGeopoint) {
                    console.log("task geopoint find--------", task.taskGeopoint);
                    lat = task.taskGeopoint.lat;
                    lng = task.taskGeopoint.lng;
                }

                this.currentTask = task;
                this.bookingTime = this.currentTask.bookingTime;
                let icon = '';
                let mechIcon = '';
                switch (task.status) {
                    case 1:
                        icon = './assets/img/png/yellow-marker.png';
                        break;
                    case 2:
                        icon = './assets/img/png/orange-marker.png';
                        mechIcon = './assets/img/png/orange_circle.png';
                        break;
                    case 9:
                    case 10:
                    case 11:
                    case 12:
                        icon = './assets/img/png/gray-marker.png';
                        mechIcon = '';
                        break;
                    default:
                        icon = './assets/img/png/blue-marker.png';
                        mechIcon = './assets/img/png/blue_circle.png';
                        break;
                }
                if (lat && lng) {
                    this.markersBackup = {
                        taskMarkers: this.taskMarkers,
                        mechanicMarkers: this.mechanicMarkers
                    };
                    this.taskMarkers = [{
                        lat,
                        lng,
                        icon
                    }];
                    this.fitBounds = false;
                    this.adjustZoom(this.lat, this.lng, 16);
                }
                if (task.vendor && task.status > 1 && task.status < 9) {
                    this.mechanicSubscription = this.main.getVendorLocation(task.vendor.id)
                        .subscribe((data: any) => {
                            // console.log(data);
                            if (data) {
                                this.mechanicMarkers = [{
                                    lat: data.Locations.latitude,
                                    lng: data.Locations.longitude,
                                    icon: mechIcon
                                }];
                            }
                        }, (error: any) => {
                            // console.log(error);
                        });
                } else {
                    // TODO: Show all near by mechanics - To be implemented
                    // this.mechanicMarkers = [];
                }
            } else {
                if (this.mechanicSubscription) {
                    this.mechanicSubscription.unsubscribe();
                }
                this.taskMarkers = this.markersBackup.taskMarkers;
                this.mechanicMarkers = this.markersBackup.mechanicMarkers;
                this.fitBounds = true;
                this.adjustZoom(this.defaultLat, this.defaultLng, 14);
            }
        });
        this.taskService.getTaskStatus().subscribe((data: any) => {
            this.status = parseInt(data, 10);
            console.log("ststaus----", this.status);
            // console.log(data);

            setTimeout(() => {
                if (this.statusChangeModal && !this.statusChangeModal.isShown && this.status && this.status !== 1 && this.status !== 2 && this.status !== 12) {
                    console.log("----- Status Change Model Open ---------", this.statusChangeModal.isShown);
                    this.statusChangeModal.show();

                    this.statusForm.controls['cancelstatus'].clearValidators();
                    this.statusForm.controls['cancelstatus'].updateValueAndValidity();
                }

                if (this.cancelOrderModel && !this.cancelOrderModel.isShown && this.status === 12) {
                    console.log("----- Status Change Model Open ---------", this.cancelOrderModel.isShown);
                    this.cancelOrderModel.show();
                    this.statusForm.controls['cancelstatus'].setValidators([Validators.required]);
                    this.statusForm.controls['cancelstatus'].updateValueAndValidity();
                }

                if (this.statusChangeModal && !this.statusChangeModal.isShown && this.status === 2) {
                    const status = {
                        show: true,
                        mode: 1,
                        task: this.currentTask,
                        assignMode: 0
                    };
                    this.main.setAssignSliderStatus(status);
                }
            }, 300);
        });
        this.taskService.getBookingTimePopUp().subscribe((data: any) => {
            this.bookingTimeChange = data;
            // console.log(data);
            if (this.bookingTimeChangeModal && this.bookingTimeChange) {
                const filter = `{"where":{"id":"${this.currentTask.serviceId}"}}`;
                this.serviceSubscription = this.main.getServices(filter).subscribe((response: any) => {
                    this.serviceSelected = response[0];
                    console.log(this.serviceSelected);
                    const today = new Date();
                    this.serviceDates = [];
                    for (let i = 0; i < 7; i++) {
                        this.serviceDates.push(new Date(today));
                        today.setDate(today.getDate() + 1);
                    }
                    // this.serviceSelected = serviceSelected;
                    // booking time generated to immediate time and slots generated for today.
                    this.generateTimeSlots();
                    this.bookingTimeChangeModal.show();
                });
            } else {
                if (this.serviceSubscription) {
                    this.serviceSubscription.unsubscribe();
                }
            }
        });
        this.taskService.getTaskPath().subscribe((data: any) => {
            // console.log(data);
            this.showPath = data;
        });
        this.statusForm = fb.group({
            notes: ['', Validators.required],
            cancelstatus: ['', Validators.required]
        });
    }


    Bookingrescheduled(data: string) {
        this.ws.Bookingrescheduled(data);
    }
    cancelorder(data: string) {
        this.ws.cancelorder(data)
    };

    mechanicSelected(event, marker) {
        if (this.currentTask && this.currentTask.id) {
            const modalRef = this.modalService.open(AssignMechanicComponent, {size:'sm'});
            modalRef.componentInstance.data = {
                taskId: this.currentTask.id,
                mechanicDetails: marker.details
            };
        }
    }

    ngOnInit() {
        this.selectedCancelOption = '';
    }

    adjustZoom(lat, lng, zoom) {
        if (this.taskMarkers.length === 0) {
            this.fitBounds = false;
        } else {
            this.fitBounds = true;
        }
        setTimeout(() => {
            this.lat = lat;
            this.lng = lng;
            this.zoom = zoom;
        });
    }

    mapReady(event) {
        this.map = event;
        if (this.taskMarkers.length) {
            const bounds = new google.maps.LatLngBounds();
            for (const task of this.taskMarkers) {
                bounds.extend(new google.maps.LatLng(task.lat, task.lng));
            }
            this.map.fitBounds(bounds);
        }
    }

    cancelStatusChange() {
        this.taskService.getTaskPrevStatus().subscribe((status) => {
            console.log("get previous status -----", status);
            // this.taskService.setTaskPrevStatus(status);
            this.taskService.setTaskStatus(status);
        })

        this.selectedCancelOption = '';

        if (this.statusChangeModal) {
            this.statusChangeModal.hide();
        }
        if (this.cancelOrderModel) {
            this.cancelOrderModel.hide();
        }
        if (this.bookingTimeChangeModal) {
            this.bookingTimeChangeModal.hide()
        }

        this.modal.hide(1);
        // this.statusForm.patchValue({
        //     notes:'',
        //     cancelstatus:null
        // })  
        this.statusForm.reset();
    }

    onStatusChange(event) {
        this.selectedCancelOption = event.target.value;

        if (this.selectedCancelOption == 'Others') {
            this.statusForm.controls['notes'].setValidators([Validators.required]);
            this.statusForm.controls['notes'].updateValueAndValidity();
        } else {
            this.statusForm.controls['notes'].clearValidators();
            this.statusForm.controls['notes'].updateValueAndValidity();
        }
    }

    onStatusChangeConfirm($ev) {

        $ev.preventDefault();
        for (const c in this.statusForm.controls) {
            if (this.statusForm.controls.hasOwnProperty(c)) {
                this.statusForm.controls[c].markAsTouched();
            }
        }

        // this.statusForm.get('notes').clearValidators();

        if (this.statusForm.valid) {
            console.log("clicked confirm ---", $ev);
            var nt = '';
            if (this.statusForm.get('cancelstatus').value) {
                if (this.selectedCancelOption == 'Others') {
                    nt = this.statusForm.get('notes').value
                }
                else {
                    nt = this.statusForm.get('cancelstatus').value
                }
            }
            else {
                nt = this.statusForm.get('notes').value
            }
            if (this.status > -1) {
                console.log("task status > -1 -----", this.status);
                const params = {
                    status: parseInt(this.status, 10),
                    notes: nt
                };
                this.taskService.updateOrderStatus(this.currentTask.id, params)
                    .subscribe((response: any) => {
                        this.statusChangeModal.hide();
                        this.cancelOrderModel.hide();
                        this.cancelorder(this.currentTask.id);
                        this.modal.hide(1);
                        setTimeout(() => {
                            this.reloadTasks();
                        });
                        // this.statusForm.patchValue({
                        //     notes:'',
                        //     cancelstatus:null
                        // }) 
                        this.statusForm.reset();
                    }, (error: any) => {
                        console.log(error);
                    });
            } else {
                this.taskService.unassignMechanic(this.currentTask.id).subscribe(
                    (data: any) => {
                        if (data.statusCode === 500) {
                            this.main.showToast('error', data.message);
                        } else {
                            //
                            this.statusChangeModal.hide();
                            this.cancelOrderModel.hide();
                            this.modal.hide(1);
                            this.reloadTasks();
                        }
                    },
                    (error: any) => {
                        console.log(error);
                    });
            }
        }

    }

    calculateCurrentTime() {
        let current;
        let today8PM;
        let today8AM;
        if (this.bookingTime) {
            current = new Date(this.bookingTime);
            today8AM = new Date(this.bookingTime);
            today8PM = new Date(this.bookingTime);
        } else {
            current = new Date();
            today8AM = new Date();
            today8PM = new Date();
        }
        today8AM.setHours(8, 0, 0);
        today8PM.setHours(20, 0, 0);
        if (current.getTime() >= today8AM.getTime() && current.getTime() < today8PM.getTime()) {
            this.time = 0;
        } else {
            this.time = 1;
        }
        // if (this.serviceSelected) {
        this.calculateCost();
        // }
    }

    calculateCost() {
        let cost;
        if (this.time === 0) {
            cost = this.serviceSelected.dayCharge;
        } else {
            cost = this.serviceSelected.nightCharge;
        }
        cost += (cost * this.serviceSelected.tax) / 100;
        this.tentativeCost = cost;
    }

    generateTimeSlots() {
        const interval = this.serviceSelected.intervalTime;
        const leadTime = this.serviceSelected.leadTime;
        const startTime = new Date(this.serviceDates[this.selectedDate]);
        if (this.selectedDate === 0) {
            startTime.setMinutes(startTime.getMinutes() + leadTime);
            if (startTime.getMinutes() < 30) {
                startTime.setMinutes(30, 0);
            } else {
                startTime.setHours(startTime.getHours() + 1);
                startTime.setMinutes(0, 0);
            }
            this.bookingTime = new Date(startTime);
        } else {
            startTime.setHours(0, 0, 0);
        }
        this.calculateCurrentTime();
        const endTime = new Date(this.serviceDates[this.selectedDate]);
        endTime.setHours(23, 59, 59);
        const dayStart = new Date(this.serviceDates[this.selectedDate]);
        dayStart.setHours(8, 0, 0);
        const dayEnd = new Date(this.serviceDates[this.selectedDate]);
        dayEnd.setHours(19, 59, 59);
        this.timeSlots[0] = [];
        this.timeSlots[1] = [];
        this.timeSlots[2] = [];
        while (startTime.getTime() <= endTime.getTime()) {
            if (startTime.getTime() < dayStart.getTime() && this.serviceSelected.nightCharge) {
                this.timeSlots[0].push(moment(startTime).format('HH:mm'));
            } else if (startTime.getTime() >= dayStart.getTime() && startTime.getTime() < dayEnd.getTime()
                && this.serviceSelected.dayCharge) {
                this.timeSlots[1].push(moment(startTime).format('HH:mm'));
            } else if (startTime.getTime() >= dayEnd.getTime() && this.serviceSelected.nightCharge) {
                this.timeSlots[2].push(moment(startTime).format('HH:mm'));
            }
            startTime.setMinutes(startTime.getMinutes() + interval);
        }
    }

    moveDate(mode: any) {
        let moveTo;
        if (mode === 'left') {
            // Clicked on Left, so slider will move towards Right
            if (this.currentPosition < this.sliderRightLimit) {
                moveTo = (this.currentPosition + this.move);
                this.animate(moveTo);
                this.currentPosition += this.move;
            }
        } else {
            // Clicked on Right, so slider will move towards Left
            if (this.currentPosition >= this.sliderLeftLimit) {
                moveTo = (this.currentPosition - this.move);
                this.animate(moveTo);
                this.currentPosition -= this.move;
            }
        }
    }

    animate(moveTo) {
        this.view.animate(
            [
                { transform: 'translateX(' + this.currentPosition + 'px)' },
                { transform: 'translateX(' + moveTo + 'px)' },
            ],
            {
                duration: 400,
                delay: 0,
                fill: 'both',
                easing: 'ease-in-out'
            }
        );
    }

    selectDate(index: number) {
        this.selectedDate = index;
        this.generateTimeSlots();
    }

    selectTimeSlot(slot) {
        this.selectedTime = slot;
        const time = slot.split(':');
        const startTime = new Date(this.serviceDates[this.selectedDate]);
        startTime.setHours(parseInt(time[0], 10), parseInt(time[1], 10), 0);
        this.bookingTime = startTime;
        this.calculateCurrentTime();
        this.saveBookingTime();
    }

    saveBookingTime() {
        console.log(this.bookingTime);
        const params = {
            bookingTime: moment.utc(new Date(this.bookingTime))
        };
        this.taskService.updateTaskBookingTime(params, this.currentTask.id)
            .subscribe((response: any) => {
                this.selectedDate = 0;
                this.selectedTime = undefined;
                this.sliderLeftLimit = -650;
                this.sliderRightLimit = 0;
                this.currentPosition = 0;
                this.time = 0;
                this.timeSlots = {
                    0: [],
                    1: [],
                    2: []
                };
                this.tentativeCost = 0;
                this.bookingTimeChangeModal.hide();
                this.Bookingrescheduled(this.currentTask.id)
                this.main.showToast('success', `Task #${this.currentTask.id} - Booking time updated`);
                this.reloadTasks();
            }, (error: any) => {
                console.log(error);
            });
    }

    reloadTasks() {
        setTimeout(() => {
            this.taskService.clearCurrentTask();
            this.taskService.clearTaskDetails();
            this.taskService.setCurrentTask({});
            this.taskService.setUpdatedTasks(true);
            this.mechanicService.setRefresh(true);
        });
    }

    clickedMarker(marker) {
        console.log(marker);
        setTimeout(() => {
            this.taskService.setTaskDetails(marker.task);
        });
    }
}
