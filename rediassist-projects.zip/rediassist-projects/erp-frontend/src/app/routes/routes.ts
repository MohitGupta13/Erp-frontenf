import { Routes } from '@angular/router';
import { LayoutComponent } from '../layout/layout.component';
import { VendorLayoutComponent } from '../layout/vendor-layout/vendor-layout.component';
import { AuthGuard } from '../core/guards/auth.guard';
import { LoginComponent } from './pages/login/login.component';
export const routes: Routes = [

    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'home', pathMatch: 'full' },
            { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule), canActivate: [AuthGuard] },
            { path: 'create-task',
                loadChildren: () => import('./create-task/create-task.module').then(m => m.CreateTaskModule), canActivate: [AuthGuard] }
        ]
    },
    {
        path: '',
        component: VendorLayoutComponent,
        children: [
            { path: '', redirectTo: 'vendors', pathMatch: 'full' },
            {
                path: 'vendors',
                loadChildren: () => import('./vendors/vendors.module').then(m => m.VendorsModule), canActivate: [AuthGuard]
            },
            {
                path: 'clients',
                loadChildren: () => import('./clients/clients.module').then(m => m.ClientsModule), canActivate: [AuthGuard]
            },
            {
                path: 'customers',
                loadChildren: () => import('./customers/customers.module').then(m => m.CustomersModule), canActivate: [AuthGuard]
            },
            {
                path: 'teams',
                loadChildren: () => import('./teams/teams.module').then(m => m.TeamsModule), canActivate: [AuthGuard]
            },
            {
                path: 'vehicles',
                loadChildren: () => import('./vehicles/vehicles.module').then(m => m.VehiclesModule), canActivate: [AuthGuard]
            },
            {
                path: 'services',
                loadChildren: () => import('./services/services.module').then(m => m.ServicesModule), canActivate: [AuthGuard]
            },
            {
                path: 'locations',
                loadChildren: () => import('./locations/locations.module').then(m => m.LocationsModule), canActivate: [AuthGuard]
            }
        ]
    },

    // Not found
    { path: 'login', component: LoginComponent },
    { path: '**', redirectTo: 'login' }
    // { path: 'forgot', component: ForgotComponent },
    // // Not found
    // { path: '**', redirectTo: 'login' }

];
