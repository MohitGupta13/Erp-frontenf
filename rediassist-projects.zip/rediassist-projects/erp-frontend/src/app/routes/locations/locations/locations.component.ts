/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { LocationsService } from 'src/app/core/services/locations/locations.service';
import { nightMapJSONDetails, dayMapJSONDetails } from 'src/constant/data';
import { MapsAPILoader } from '@agm/core';
declare const google: any;
@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.scss']
})
export class LocationsComponent implements OnInit {

  @ViewChild('mapLocation')
  public mapLocationElementRef: ElementRef;
  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockLocationModal') blockUnblockLocationModal: ModalDirective;
  table = {
    currentPage: 1,
    numPages: 0
  };
  locationColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true, width: 70 },
    { headerName: 'Name', field: 'name', sortable: true, filter: true, width: 150 },
    { headerName: 'Shortcode', field: 'shortCode', sortable: true, filter: true, width: 120 },
    // { headerName: 'Updated At', field: 'updatedAt', sortable: true, filter: true, width: 250 },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editLocation: this.editLocation.bind(this),
        blockLocation: this.blockLocation.bind(this),
        unblockLocation: this.unblockLocation.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  locationForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  locationRows = [];
  addMode = 'Add';
  location;
  locationRowsCount = 0;
  skip = 0;
  currentTime = new Date();
  mapJSON = (this.currentTime.getHours() >= 20 || this.currentTime.getHours() <= 7) ? nightMapJSONDetails : dayMapJSONDetails;
  zoom = 10;
  scrollWheel = true;
  fitBounds = true;
  current = {
    lat: 12.9716,
    lng: 77.5946,
  };
  map: google.maps.Map;
  geoFenceArray = [];
  drawingManager;
  polygon;
  allOverlays = [];
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public locationsService: LocationsService,
    fb: FormBuilder,
    private ngZone: NgZone,
    private mapsAPILoader: MapsAPILoader,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.locationForm = fb.group({
      name: ['', Validators.required],
      shortCode: ['', Validators.required],
      mapLocation: [''],
      geofence: [null, Validators.required]
    });
    console.log(this.current);
  }

  ngOnInit(): void {
    this.getLocationsCount();
    this.getLocations(this.skip);
    this.mapsAPILoader.load().then(() => {
      const autocomplete = new google.maps.places.Autocomplete(this.mapLocationElementRef.nativeElement);
      autocomplete.setComponentRestrictions({ country: ['in'] });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place: google.maps.places.PlaceResult = autocomplete.getPlace();
          // console.log(place);
          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          // set latitude, longitude and zoom
          console.log(place);
          this.locationForm.patchValue({
            mapLocation: place.formatted_address,
          });
          this.current.lat = place.geometry.location.lat();
          this.current.lng = place.geometry.location.lng();
          console.log(this.current);
          // console.log(this.markers);
          this.zoom = 10;
        });
      });
    });
  }

  onMapReady(map: google.maps.Map) {
    this.map = map;
    this.initDrawingManager(map);
  }

  initDrawingManager(map: any) {
    const options = {
      drawingControl: true,
      drawingControlOptions: {
        drawingModes: ['polygon']
      },
      polygonOptions: {
        draggable: true,
        editable: true
      },
      drawingMode: google.maps.drawing.OverlayType.POLYGON
    };
    this.allOverlays = [];
    this.drawingManager = new google.maps.drawing.DrawingManager(options);
    this.drawingManager.setMap(map);
    google.maps.event.addListener(this.drawingManager, 'overlaycomplete', (e) => {
        this.allOverlays.push(e);
    });
    google.maps.event.addListener(this.drawingManager, 'polygoncomplete',  (polygon) => {
      const len = polygon.getPath().getLength();
      const polyArrayLatLng = [];
      for (let i = 0; i < len; i++) {
        const vertex = polygon.getPath().getAt(i);
        const vertexLatLng = [vertex.lng(), vertex.lat()];
        polyArrayLatLng.push(vertexLatLng);
      }
      // the last point of polygon should be always the same as the first point (math rule)
      polyArrayLatLng.push(polyArrayLatLng[0]);
      this.updatelatlong(polyArrayLatLng);
      console.log('coordinates', polyArrayLatLng);
      return polyArrayLatLng;
    });
  }
  updatelatlong(coords) {
    console.log(coords);
    // const paths = [];
    // for (const pathArray of coords) {
    //   const path = [];
    //   for (const latLong of pathArray) {
    //     path.push({ lat: latLong[1], lng: latLong[0]});
    //   }
    //   paths.push(path);
    // }
    // console.log("paths", paths);
    this.geoFenceArray = [coords];
    console.log("GeoFence", this.geoFenceArray);
    this.locationForm.patchValue({
      geofence: JSON.stringify(this.geoFenceArray)
    });
  }

  drawPolygon(geofence) {
    // tslint:disable-next-line:max-line-length
    const coords = JSON.parse(geofence);
    console.log(coords);
    const paths = [];
    for (const pathArray of coords) {
      const path = [];
      for (const latLong of pathArray) {
        path.push({ lat: latLong[1], lng: latLong[0]});
      }
      paths.push(path);
    }
    console.dir(paths);
    this.polygon = new google.maps.Polygon({
      paths,
      editable: true,
      draggable: false,
    });
    this.polygon.setMap(this.map);
    google.maps.event.addListener(this.polygon, 'coordinates_changed', (polygon) => {
      // Polygon object: yourPolygon
      console.log('coordinates_changed');
      const len = this.polygon.getPath().getLength();
      const polyArrayLatLng = [];
      for (let i = 0; i < len; i++) {
        const vertex = this.polygon.getPath().getAt(i);
        const vertexLatLng = [vertex.lng(), vertex.lat()];
        polyArrayLatLng.push(vertexLatLng);
      }
      polyArrayLatLng.push(polyArrayLatLng[0]);
      console.log('coordinates', polyArrayLatLng);
      this.updatelatlong(polyArrayLatLng);
    });
    // const place_polygon_path = this.polygon.getPath();
    var polygon = this.polygon;
    var isBeingDragged = false;
    var triggerCoordinatesChanged = function () {
      // Broadcast normalized event
      google.maps.event.trigger(polygon, 'coordinates_changed');
    };
    google.maps.event.addListener(polygon, "dragstart", function () {
      isBeingDragged = true;
    });
    google.maps.event.addListener(polygon, "dragend", function () {
      triggerCoordinatesChanged();
      isBeingDragged = false;
    });
    const polygonPaths = this.polygon.getPaths();
    polygonPaths.forEach(function (path, i) {
      google.maps.event.addListener(path, "insert_at", function () {
        triggerCoordinatesChanged();
      });
      google.maps.event.addListener(path, "set_at", function () {
        if (!isBeingDragged) {
          triggerCoordinatesChanged();
        }
      });
      google.maps.event.addListener(path, "remove_at", function () {
        triggerCoordinatesChanged();
      });
    });
    if (this.location?.geofence.length) {
      const bounds = new google.maps.LatLngBounds();
      for (const pathArray of coords) {
        for (const latLong of pathArray) {
          const lat = latLong[1];
          const lng = latLong[0];
          bounds.extend(new google.maps.LatLng(lat, lng));
        }
      }
      this.map.fitBounds(bounds);
    }
  }

  // polygonChanged() {
  //   const len = this.polygon.getPath().getLength();
  //   const polyArrayLatLng = [];
  //   for (let i = 0; i < len; i++) {
  //     const vertex = this.polygon.getPath().getAt(i);
  //     const vertexLatLng = [vertex.lng(), vertex.lat()];
  //     polyArrayLatLng.push(vertexLatLng);
  //   }
  //   polyArrayLatLng.push(polyArrayLatLng[0]);
  //   this.updatelatlong(polyArrayLatLng);
  //   console.log('coordinates', polyArrayLatLng);
  // }

  addLocation() {
    this.formReset();
  }

  getLocations(skip = 0) {
    this.skip = skip;
    this.locationsService.locationList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.locationRows = rows.map(row => {
          row.updatedAt = row.updatedAt ? moment(row.updatedAt).format('LLLL') : '';
          return row;
        });
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getLocationsCount() {
    this.locationsService.locationCount().subscribe(
      (data: any) => {
        this.locationRowsCount = data.count;
        this.table.numPages = Math.ceil(this.locationRowsCount / 10);
        if (this.locationRowsCount % 10 > 0) {
          this.table.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getLocations(skip);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitLocationForm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.locationForm);
    this.saveLocation();
  }

  saveLocation() {
    if (this.locationForm.valid) {
      let params = {
        name: this.locationForm.get('name').value,
        shortCode: this.locationForm.get('shortCode').value,
        geofence: this.locationForm.get('geofence').value,
        isActive: true
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.locationsService.createLocation(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getLocationsCount();
          this.getLocations(this.skip);
          this.main.showToast('success', 'Location Created Successfully');
          this.cancelLocation();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Location name exists already');
          }
        });
      } else {
        params = { ...params, isActive: this.location.isActive };
        this.locationsService.editLocation(params, this.location.id).subscribe(
        (response: any) => {
            this.getLocations(this.skip);
            this.main.showToast('success', 'Location Saved Successfully');
            this.cancelLocation();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Location name/shortCode exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  cancelLocation() {
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.locationForm.patchValue({
      name: '',
      shortCode: '',
      geofence: [],
      id: null,
      mapLocation: ''
    });
    this.geoFenceArray = [];
    this.locationForm.enable();
    this.resetFormControls(this.locationForm);
    this.polygon?.setMap(null);
    if (this.allOverlays.length) {
      for (const overlay of this.allOverlays) {
        overlay.overlay.setMap(null);
      }
      this.allOverlays = [];
    }
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        form.controls[c].markAsPristine();
      }
    }
  }

  editLocation(rowData, mode = 1) {
    this.formReset();
    this.locationForm.enable();
    this.location = rowData;
    this.locationForm.patchValue({
      name: this.location.name,
      shortCode: this.location.shortCode,
      geofence: this.location.geofence,
      id: this.location.id
    });
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.locationForm.disable();
    }
    this.geoFenceArray = JSON.parse(this.location.geofence);
    console.log("GeoFence", this.geoFenceArray);
    this.drawPolygon(this.location.geofence);
  }

  blockLocation(rowData) {
    this.blockMode = 'Block';
    this.location = rowData;
    this.blockUnblockLocationModal.show();
  }

  unblockLocation(rowData) {
    this.blockMode = 'Unblock';
    this.location = rowData;
    this.blockUnblockLocationModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.location = {};
    this.blockUnblockLocationModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
      };
      this.locationsService.blockUnblockConfirm(params, this.location.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockLocationModal.hide();
          this.getLocations(this.skip);
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editLocation(data, 1);
        case 'block':
          return this.blockLocation(data);
        case 'unblock':
          return this.unblockLocation(data);
        case null:
          return this.editLocation(data, 2);
      }
    }
  }

}
