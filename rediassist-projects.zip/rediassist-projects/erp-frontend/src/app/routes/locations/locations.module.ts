import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationsComponent } from './locations/locations.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActionCellComponent } from './action-cell/action-cell.component';

const routes: Routes = [
  { path: '', component: LocationsComponent },
];


@NgModule({
  declarations: [LocationsComponent, ActionCellComponent],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule,
  ],
  exports: [
    RouterModule
  ]
})
export class LocationsModule { }
