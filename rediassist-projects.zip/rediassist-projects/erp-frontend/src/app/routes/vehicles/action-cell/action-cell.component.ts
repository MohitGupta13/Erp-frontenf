import { Component } from '@angular/core';
import { AgRendererComponent } from 'ag-grid-angular';

@Component({
  selector: 'app-action-cell',
  templateUrl: './action-cell.component.html',
  styleUrls: ['./action-cell.component.scss']
})
export class ActionCellComponent implements AgRendererComponent {

  data: any;
  params: any;
  constructor() {}

  agInit(params) {
    this.params = params;
    this.data = params.data;
  }

  refresh(params: any): boolean {
    return false;
  }

  editVehicle() {
    this.params.editVehicle(this.data);
  }

  blockVehicle() {
    this.params.blockVehicle(this.data);
  }

  unblockVehicle() {
    this.params.unblockVehicle(this.data);
  }
}
