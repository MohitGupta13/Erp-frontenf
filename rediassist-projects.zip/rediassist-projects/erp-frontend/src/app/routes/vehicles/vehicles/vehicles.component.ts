import { Component, OnInit, ViewChild } from '@angular/core';
import { ActionCellComponent } from '../action-cell/action-cell.component';
import { AgGridAngular } from 'ag-grid-angular';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { VehiclesService } from 'src/app/core/services/vehicles/vehicles.service';
import * as moment from 'moment';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';

@Component({
  selector: 'app-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.scss']
})
export class VehiclesComponent implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridAngular;
  @ViewChild('blockUnblockVehicleModal') blockUnblockVehicleModal: ModalDirective;
  @ViewChild('addEditVehicleModal') addEditVehicleModal: ModalDirective;
  bikeTable = {
    currentPage: 1,
    numPages: 0
  };
  carTable = {
    currentPage: 1,
    numPages: 0
  };
  vehicleColumns = [
    { headerName: 'ID', field: 'id', sortable: true, filter: true },
    { headerName: 'Date Added', field: 'createdAt', sortable: true, filter: true },
    { headerName: 'Type', field: 'type', sortable: true, filter: true },
    { headerName: 'Category', field: 'category', sortable: true, filter: true },
    { headerName: 'Make', field: 'make', sortable: true, filter: true },
    { headerName: 'Model', field: 'model', sortable: true, filter: true },
    { headerName: 'Version', field: 'version', sortable: true, filter: true },
    { headerName: 'CC', field: 'cc', sortable: true, filter: true },
    { headerName: 'Status', field: 'statusName', sortable: true, filter: true },
    {
      headerName: 'Actions', field: 'action', sortable: false,
      filter: false, cellRendererFramework: ActionCellComponent, cellRendererParams: {
        editVehicle: this.editVehicle.bind(this),
        blockVehicle: this.blockVehicle.bind(this),
        unblockVehicle: this.unblockVehicle.bind(this)
      }
    }
  ];
  gridColumnApi;
  gridApi;
  defaultColDef = { resizable: true };
  vehicleForm: FormGroup;
  blockForm: FormGroup;
  blockMode;
  addMode = 'Add';
  vehicle;
  bikeRows = [];
  bikeRowsCount = 0;
  carRows = [];
  carRowsCount = 0;
  vehicleCategories = [];
  bikeSkip = 0;
  carSkip = 0;
  constructor(
    public settings: SettingsService,
    public main: MainService,
    public vehiclesService: VehiclesService,
    public vendorsService: VendorsService,
    fb: FormBuilder,
  ) {
    this.settings.setLayoutSetting('offsidebarOpen', false);
    this.settings.setLayoutSetting('isCollapsed', true);
    this.blockForm = fb.group({
      notes: ['']
    });
    this.vehicleForm = fb.group({
      type: ['', Validators.required],
      make: ['', Validators.required],
      model: ['', Validators.required],
      category: ['', Validators.required],
      version: [''],
      cc: ['', Validators.required],
      isActive: [true],
      id: [null]
    });
  }

  ngOnInit(): void {
    this.getVehicles();
  }

  getVehicles() {
    this.getBikes(this.bikeSkip);
    this.getBikeCount();
    this.getCars(this.carSkip);
    this.getCarCount();
  }

  getVehicleCategories(edit = 0) {
    let type = this.vehicleForm.get('type').value;
    if (!type) {
      type = 'BIKE';
    }
    const payload = {
      type
    };
    this.vendorsService.getVehicleCategories(payload).subscribe(
      (data: any) => {
        this.vehicleCategories = data;
        if (edit) {
          this.vehicleForm.patchValue({
            category: this.vehicle.category
          });
          this.addEditVehicleModal.show();
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  addVehicle() {
    // this.vehiclesService.setModalFlag(true);
    this.formReset();
    this.getVehicleCategories();
    this.addEditVehicleModal.show();
  }

  getBikes(skip = 0) {
    this.bikeSkip = skip;
    this.vehiclesService.bikeList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.bikeRows = rows.map(row => {
          row.createdAt = row.createdAt ? moment(row.createdAt).format('LLLL') : '';
          row.statusName = row.isActive ? 'Active' : 'Inactive';
          return row;
        });
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getBikeCount() {
    this.vehiclesService.bikeCount().subscribe(
      (data: any) => {
        this.bikeRowsCount = data.count;
        this.bikeTable.numPages = Math.ceil(this.bikeRowsCount / 10);
        if (this.bikeRowsCount % 10 > 0) {
          this.bikeTable.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  bikePageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getBikes(skip);
  }

  getCars(skip = 0) {
    this.carSkip = skip;
    this.vehiclesService.carList(skip).subscribe(
      (data: any) => {
        const rows = data || [];
        this.carRows = rows.map(row => {
          row.createdAt = row.createdAt ? moment(row.createdAt).format('LLLL') : '';
          row.statusName = row.isActive ? 'Active' : 'Inactive';
          return row;
        });
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getCarCount() {
    this.vehiclesService.carCount().subscribe(
      (data: any) => {
        this.carRowsCount = data.count;
        this.carTable.numPages = Math.ceil(this.carRowsCount / 10);
        if (this.carRowsCount % 10 > 0) {
          this.carTable.numPages++;
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  carPageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    const skip = (event.page - 1) * event.itemsPerPage;
    this.getCars(skip);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    const allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach((column) => {
      allColumnIds.push(column.colId);
    });
  }

  submitVehicleForm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.vehicleForm);
    this.saveVehicle();
  }

  saveVehicle() {
    if (this.vehicleForm.valid) {
      let params = {
        type: this.vehicleForm.get('type').value,
        make: this.vehicleForm.get('make').value,
        model: this.vehicleForm.get('model').value,
        category: this.vehicleForm.get('category').value,
        version: this.vehicleForm.get('version').value || '',
        cc: this.vehicleForm.get('cc').value.toString(),
        isActive: true,
      };
      if (this.addMode === 'Add') {
        params = { ...params, isActive: true};
        this.vehiclesService.createVehicle(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getVehicles();
          this.main.showToast('success', 'Vehicle Created Successfully');
          this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Vehicle name exists already');
          }
        });
      } else {
        params = { ...params, isActive: this.vehicle.isActive };
        this.vehiclesService.editVehicle(params, this.vehicle.id).subscribe(
        (response: any) => {
            this.getVehicles();
            this.main.showToast('success', 'Vehicle Saved Successfully');
            this.closeModal();
        },
        (error: any) => {
          console.log(error);
          if (error?.error?.error?.code === 'ER_DUP_ENTRY') {
            this.main.showToast('error', 'Vehicle name exists already');
          }
        });
      }
    } else {
      this.main.showToast('warning', 'Please fill the required fields');
      return false;
    }
  }

  closeModal() {
    this.addEditVehicleModal.hide();
    setTimeout(() => {
      this.formReset();
    }, 500);
  }

  formReset() {
    this.addMode = 'Add';
    this.vehicleForm.patchValue({
      name: '',
      description: ''
    });
  }

  resetFormControls(form: FormGroup) {
    for (const c in form.controls) {
      if (form.controls.hasOwnProperty(c)) {
        form.controls[c].markAsUntouched();
        form.controls[c].markAsPristine();
      }
    }
  }

  editVehicle(rowData, mode = 1) {
    this.vehicleForm.enable();
    this.vehicle = rowData;
    console.log(this.vehicle);
    this.vehicleForm.patchValue({
      type: this.vehicle.type,
      make: this.vehicle.make,
      model: this.vehicle.model,
      category: this.vehicle.category,
      cc: this.vehicle.cc,
      version: this.vehicle.version,
      isActive: this.vehicle.isActive,
      id: this.vehicle.id
    });
    if (mode === 1) {
      this.addMode = 'Edit';
    } else {
      this.addMode = 'View';
      this.vehicleForm.disable();
    }
    this.getVehicleCategories(1);
  }

  blockVehicle(rowData) {
    this.blockMode = 'Block';
    this.vehicle = rowData;
    this.blockUnblockVehicleModal.show();
  }

  unblockVehicle(rowData) {
    this.blockMode = 'Unblock';
    this.vehicle = rowData;
    this.blockUnblockVehicleModal.show();
  }

  cancelBlockUnblock() {
    this.blockMode = '';
    this.vehicle = {};
    this.blockUnblockVehicleModal.hide();
  }

  blockUnblockConfirm($ev) {
    $ev.preventDefault();
    this.resetFormControls(this.blockForm);
    if (this.blockForm.valid) {
      const params = {
        isActive: this.blockMode === 'Block' ? false : true,
        // notes: this.blockForm.get('notes').value,
        // activationDate: null
      };
      // if (params.isActive) {
      //   params.activationDate = moment.utc(new Date());
      // } else {
      //   delete params.activationDate;
      // }
      this.vehiclesService.blockUnblockConfirm(params, this.vehicle.id).subscribe(
        (data: any) => {
          this.blockMode = '';
          this.blockUnblockVehicleModal.hide();
          this.getVehicles();
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  onRowClick(e) {
    if (e.event.target !== undefined) {
      const data = e.data;
      const actionType = e.event.target.getAttribute('data-action-type');
      switch (actionType) {
        case 'edit':
          return this.editVehicle(data, 1);
        case 'block':
          return this.blockVehicle(data);
        case 'unblock':
          return this.unblockVehicle(data);
        case null:
          return this.editVehicle(data, 2);
      }
    }
  }

}
