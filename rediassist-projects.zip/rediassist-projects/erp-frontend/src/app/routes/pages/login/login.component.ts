import { Component, OnInit } from '@angular/core';
import { SettingsService } from '../../../core/settings/settings.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MainService } from 'src/app/core/services/main/main.service';
import { apiPath } from 'src/constant/api';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth/auth.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    loginForm: FormGroup;

    constructor(public settings: SettingsService, fb: FormBuilder, public main: MainService,
                private router: Router, private auth: AuthService) {

        this.loginForm = fb.group({
            mobile: [null, Validators.required],
            password: [null, Validators.required]
        });

    }

    submitForm($ev) {
        $ev.preventDefault();
        for (const c in this.loginForm.controls) {
            if (this.loginForm.controls.hasOwnProperty(c)) {
                this.loginForm.controls[c].markAsTouched();
            }
        }
        if (this.loginForm.valid) {
            const payload = {
                mobileNo: this.loginForm.get('mobile').value,
                password: this.loginForm.get('password').value
            };
            this.auth.login(payload);
        } else {
            this.main.showToast('warning', 'Please fill all the fields');
        }
    }

    ngOnInit() {

    }

}
