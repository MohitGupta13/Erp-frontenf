import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { ToastrModule } from 'ngx-toastr';
import { AgmCoreModule } from '@agm/core';
import { AgmDirectionModule } from 'agm-direction';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { NgxSelectModule } from 'ngx-select-ex';
import { AgGridModule } from 'ag-grid-angular';
import { ColorsService } from './colors/colors.service';
import { NowDirective } from './directives/now/now.directive';
import { StringReplacePipe } from './pipes/string-replace.pipe';
import { SafePipe } from './pipes/safe-url.pipe';
import { ReadableCasePipe } from './pipes/readable-case.pipe';
import { AssignSliderComponent } from './components/assign-slider/assign-slider.component';
import { TaskCardComponent } from './components/task-card/task-card.component';
import { MechanicCardComponent } from './components/mechanic-card/mechanic-card.component';
import { MinutesToHours } from './pipes/minutes-hours.pipe';

import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { environment } from 'src/environments/environment';
import { LightboxModule } from "ngx-lightbox";
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot(),
    TabsModule.forRoot(),
    TypeaheadModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    ToastrModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: environment.mapApi,
      libraries: ["places", "drawing"],
    }),
    AgmDirectionModule,
    NgxSelectModule,
    AgGridModule.withComponents([]),
    LightboxModule,
  ],
  providers: [
    ColorsService,
    StringReplacePipe,
    SafePipe,
    ReadableCasePipe,
    MinutesToHours,
  ],
  declarations: [
    NowDirective,
    StringReplacePipe,
    SafePipe,
    ReadableCasePipe,
    MinutesToHours,
    AssignSliderComponent,
    TaskCardComponent,
    MechanicCardComponent,
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    RouterModule,
    CollapseModule,
    BsDropdownModule,
    ModalModule,
    PaginationModule,
    TabsModule,
    TypeaheadModule,
    NgMultiSelectDropDownModule,
    ToastrModule,
    NowDirective,
    AgmCoreModule,
    AgmDirectionModule,
    NgxSelectModule,
    AgGridModule,
    StringReplacePipe,
    SafePipe,
    ReadableCasePipe,
    MinutesToHours,
    AssignSliderComponent,
    TaskCardComponent,
    MechanicCardComponent,
  ],
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
    };
  }
}
