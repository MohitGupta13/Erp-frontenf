import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'm2h'
})
export class MinutesToHours implements PipeTransform {
    transform(value: number) {
        if (value >= 0) {
            const hours = Math.floor(value / 60);
            const minutes = Math.floor(value % 60);
            if (hours) {
                return ' - ' + hours + ' hrs ' + minutes + ' mins';
            } else {
                return ' - ' + minutes + ' mins';
            }
        } else {
            return value;
        }
  }
}
