import { StringReplacePipe } from './string-replace.pipe';

describe('StringReplacePipe', () => {
  it('create an instance', () => {
    const pipe = new StringReplacePipe();
    expect(pipe).toBeTruthy();
  });
});
