export interface Mechanic {
    id: number;
    name: string;
    mobile: string;
    profilePic1: string;
    latlon:  string;
    mechanic_name: string;
    mechanic_photo?: string;
    mechanic_pri_phone: string;
    mechanic_work_status: string;
    mechanic_team?: string;
    mechanic_rating?: number;
    mechanic_tags?: string;
}