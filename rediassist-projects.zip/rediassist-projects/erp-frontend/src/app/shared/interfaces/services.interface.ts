export interface Service {
    id: number;
    category: string;
    clientId: number;
    createdAt: string;
    dayCharge: number;
    description: string;
    displayToCustomer: boolean;
    intervalTime: number;
    isActive: boolean;
    leadTime: number;
    locationId: number;
    name: string;
    nightCharge: number;
    serviceCode: string;
    tax: number;
    updatedAt: string;
    vehicleId: number;
}
