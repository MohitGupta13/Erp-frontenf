export interface Task {
  id: number;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
  source: string;
  platform: string;
  orderAddress: string;
  dropOffAddress?: string;
  custName: string;
  custPhoneNumber: string;
  custEmail?: string;
  notes: string;
  status: number;
  statusName?: string;
  tag: string;
  creationGeopoint: {
    lat: number,
    lng: number
  };
  taskGeopoint: {
    lat: number,
    lng: number
  };
  vehicleIdentificationNumber: string;
  clientId: number;
  serviceId: number;
  serviceName: string;
  vehicleId: number;
  vehicleName: string;
  assigned_mechanic?;
  bookingTime?: string;
  invoiceId?: number;
  vehicle?: any;
  vendor?: any;
}
