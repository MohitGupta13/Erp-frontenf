import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { MainService } from 'src/app/core/services/main/main.service';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { Mechanic } from '../../interfaces/mechanics.interface';

@Component({
  selector: 'app-mechanic-card',
  templateUrl: './mechanic-card.component.html',
  styleUrls: ['./mechanic-card.component.scss']
})
export class MechanicCardComponent implements OnInit {

  @Input() mechanic;
  constructor(public main: MainService, public vendorService: VendorsService, public taskService: TasksService) { }

  ngOnInit(): void {
    this.getImageFromUrl(this.mechanic.profilePic1);
  }

  getImageFromUrl(id) {
    this.vendorService.downloadFile(id).subscribe(
      (data: any) => {
        const b = new Blob([data], { type: 'image/jpeg' });
        const imageUrl = window.URL.createObjectURL(b);
        this.mechanic.profilePic = imageUrl;
    },
      (error: any) => {
      }
    );
  }

  // openTaskDetails() {
  //   const emit: any = {
  //     val: true,
  //     task: this.task
  //   };
  //   this.toggleTaskDetails.emit(emit);
  // }

  // openAssignSlider() {
  //   const emit: any = {
  //     val: true,
  //     task: this.task
  //   };
  //   this.toggleAssignSlider.emit(emit);
  // }
}
