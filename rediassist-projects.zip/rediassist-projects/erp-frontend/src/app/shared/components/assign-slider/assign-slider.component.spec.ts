import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignSliderComponent } from './assign-slider.component';

describe('AssignSliderComponent', () => {
  let component: AssignSliderComponent;
  let fixture: ComponentFixture<AssignSliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignSliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
