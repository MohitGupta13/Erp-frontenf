/// <reference types="@types/googlemaps" />
import { Component, OnInit, ViewChild, ElementRef, Input, ChangeDetectorRef } from '@angular/core';
import { mechanicStatus, tags, geoFences, teams } from 'src/constant/data';
import { MainService } from 'src/app/core/services/main/main.service';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { Observable, Subscription } from 'rxjs';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { startWith, map, concatAll, filter } from 'rxjs/operators';
import { ModalDirective, BsModalService } from 'ngx-bootstrap/modal';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
declare const google: any;
import * as moment from 'moment';
import { WebsocketService } from 'src/app/websocket.service';
@Component({
  selector: 'app-assign-slider',
  templateUrl: './assign-slider.component.html',
  styleUrls: ['./assign-slider.component.scss']
})
export class AssignSliderComponent implements OnInit {

  @ViewChild('assignSlider') assignSlider: ElementRef;
  @Input() mode: number;
  public teams;
  public geoFences = geoFences;
  public tags = tags;
  public mechanics = [];
  notification:string;
  assignMode = 0;
  mechanicStatus = mechanicStatus;
  showSlider = false;
  currentTask;
  currentMechanic;
  selectedTeam = -1;
  selectedGeo = -1;
  selectedTag = -1;
  filter = {
    team: '',
    geo: '',
    tag: '',
  };
  loading = false;
  filteredTeams: Observable<any[]>;
  filteredMechanics: Observable<any[]>;
  teamCtrl = new FormControl();
  mechanicCtrl = new FormControl();
  orderDetails: any;
  statusForm: FormGroup;
  vendorSubscription: Subscription;
  @ViewChild('statusChangeModal') statusChangeModal: ModalDirective;
  constructor(public main: MainService, public vendor: VendorsService, public task: TasksService,private ws:WebsocketService,
              private cdRef: ChangeDetectorRef, fb: FormBuilder, private modal: BsModalService, public mechanicService: MechanicsService) {
    this.main.getAssignSliderStatus().subscribe((status: any) => {
      // tslint:disable-next-line:no-shadowed-variable
      const { show, mode, task, assignMode } = status;
      this.showSlider = show;
      this.mode = mode;
      this.assignMode = assignMode;
      this.currentTask = task;
      // console.log(this.currentTask);
      if (this.showSlider) {
        console.log("show slider in assign slider----",this.showSlider);
        this.getMechanics();
        if (this.assignMode) {
          this.getOrderDetails();
        }
      } else {
        if (this.vendorSubscription) {
          this.vendorSubscription.unsubscribe();
        }
      }
    });
    this.statusForm = fb.group({
      notes: ['', Validators.required]
    });
  }

  unassignedmechanic(){
    this.ws.unassignedmechanic(this.notification);
    this.notification=''
  }

  ngOnInit(): void {
    this.getTeams();
  }

  private team_filter(value: any): string[] {
    if (typeof (value) === 'string') {
      const filterValue = value.toLowerCase();
      return this.teams.filter(item => item.name.toLowerCase().indexOf(filterValue) === 0);
    }
  }
  private mechanic_filter(value: any): string[] {
    if (typeof (value) === 'string') {
      const filterValue = value.toLowerCase();
      return this.mechanics.filter(item => item.name.toLowerCase().indexOf(filterValue) === 0);
    }
  }

  getOrderDetails() {
    // currentTask.id
    this.task.taskDetailsById(this.currentTask.id).subscribe(
      (data: any) => {
        this.orderDetails = data[0];
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getTeams() {
    this.vendor.teamsList().subscribe(
      (data: any) => {
        this.teams = data;
        this.filteredTeams = this.teamCtrl.valueChanges.pipe(
        startWith(null),
          map((item: any) => item ? this.team_filter(item) : this.teams.slice()));
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getMechanics1() {
    this.loading = true;
    this.vendor.getVendorsToAssign(this.filter,this.currentTask.id).subscribe(
      (data: any) => {
        console.log("data getVendorsToAssign in assign_slider.component-----",data);
        this.loading = false;
        const rows = data || [];
        rows.map((row) => {
          row.mechanicStatus = mechanicStatus[row.status];
        });
        this.mechanics = rows;
        console.log(this.mechanics);
        const taskLatLng = `${this.currentTask?.taskGeopoint?.lat},${this.currentTask?.taskGeopoint?.lng}`;
        const vendorIds = rows.map(({ id }) => id);
        // console.log(vendorIds);
        this.vendorSubscription = this.main.getAllVendorLocation(vendorIds)
        // tslint:disable-next-line:no-shadowed-variable
        .subscribe((data: any) => {
          // console.log("near vendor -----------",JSON.stringify(data));
          const vendorsWithLocations = data;
          const mechLatLng = '';
          const destinationRequest = data.map(vendor => {
            return new google.maps.LatLng(vendor.data.Locations.latitude, vendor.data.Locations.longitude);
              // `${vendor.data.Locations.latitude},${vendor.data.Locations.longitude}`;
          });
          // console.log(destinationRequest);
          this.main.getDistance(destinationRequest, taskLatLng)
            // tslint:disable-next-line:no-shadowed-variable
            .subscribe((results: any) => {
              // overwrite DB's status with FB's status
              console.log(results);
              vendorsWithLocations.forEach((vendor, index) => {
                const VendorStatus = vendor.data.vs || vendor.data.VendorStatus;
                if (vendor.data.ts) {
                  console.log("Firebase TS ::-----",vendor.data.ts)
                  vendor.ts = vendor.data.ts;
                  const tsdate = vendor.ts.toDate();
                  const ts = moment.utc(new Date(tsdate));
                  const cts = moment.utc(new Date());
                  const duration = cts.diff(ts, 'minutes');
                  // console.log(duration);
                  duration > 5 ? vendor.stale = true : vendor.stale = false;
                }
                // console.log(vendor);
                // console.log(VendorStatus);
                if (VendorStatus) {
                  switch (VendorStatus) {
                    case 'ON DUTY':
                      vendor.status = 0;
                      break;
                    case 'Transit':
                      vendor.status = 1;
                      break;
                    case 'Busy':
                      vendor.status = 2;
                      break;
                    case 'On Break':
                      vendor.status = 3;
                      break;
                    case 'Not On Duty':
                      vendor.status = 4;
                      break;
                    default:
                      break;
                  }
                }
                vendor.distance = results.rows[index].elements[0].distance?.text || '';
                vendor.distanceValue = results.rows[index].elements[0].distance?.value || 1000000;
                vendor.duration = results.rows[index].elements[0].duration?.text || '';
                console.log(vendor.id);
                const obj = this.mechanics.find(item => item.id === parseInt(vendor.id, 10));
                // console.log(obj);
                let indexArray = this.mechanics.indexOf(obj);
                if (obj) {
                  obj.distance = vendor.distance;
                  obj.distanceValue = vendor.distanceValue;
                  obj.duration = vendor.duration;
                  obj.status = vendor.status;
                  obj.stale = vendor.stale;
                  obj.mechanicStatus = mechanicStatus[obj.status];
                  this.mechanics.fill(obj, indexArray, indexArray++);
                }
              });
              this.mechanics.sort((a, b) => {
                return a.status < b.status ? -1 : (a.status > b.status ? 1 : 0);
              });
              const free = this.mechanics.filter(item => item.status === 0);
              const onBreak = this.mechanics.filter(item => item.status === 3);
              const busy = this.mechanics.filter(item => {
                return item.status === 1 || item.status === 2;
              });
              free.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              busy.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              onBreak.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              console.log(free, busy, onBreak);
              this.mechanics = [...free, ...busy, ...onBreak];
              console.log(this.mechanics);
              this.filteredMechanics = this.mechanicCtrl.valueChanges.pipe(
              startWith(null),
                map((item: any) => item ? this.mechanic_filter(item) : this.mechanics.slice()));
            }, (error: any) => {
              console.log(error);
            });
          }, (error: any) => {
            console.log(error);
        });
        this.mechanicService.setRefresh(true);
    },
      (error: any) => {
        this.loading = false;
        console.log(error);
      }
    );
  }

  getMechanics() {
    this.loading = true;
    this.vendor.getVendorsToAssign(this.filter,this.currentTask.id).subscribe(
      (data: any) => {
        this.loading = false;
        const rows = data || [];
        rows.map((row) => {
          row.mechanicStatus = mechanicStatus[row.status];
        });
        this.mechanics = rows;        
        const taskLatLng = `${this.currentTask?.taskGeopoint?.lat},${this.currentTask?.taskGeopoint?.lng}`;

        let destinationRequest = []

        for(var i =0; i < data.length; i++){
          if(i < 3){
            let latlong = data[i].latlon.split(',');
            let lat = latlong[0];
            let long = latlong[1];
            let nw_latLong =  new google.maps.LatLng(lat, long)
            destinationRequest.push(nw_latLong)
          }
        }
        let destinationLength = destinationRequest.length

        this.main.getDistance(destinationRequest, taskLatLng)
            .subscribe((results: any) => {             
              data.forEach((vendor, index) => {
                if (vendor.firebaseData.ts) {
                  vendor.ts = moment(vendor.firebaseData.ts.seconds).utc()
                  const tsdate = vendor.ts.toDate();
                  const ts = moment.utc(new Date(tsdate));
                  const cts = moment.utc(new Date());
                  const duration = cts.diff(ts, 'minutes');
                  // console.log(duration);
                  duration > 5 ? vendor.stale = true : vendor.stale = false;
                }
                
                if(index < destinationLength){
                  vendor.distance = results.rows[index].elements[0].distance?.text || '';
                  vendor.distanceValue = results.rows[index].elements[0].distance?.value || 1000000;
                  vendor.duration = results.rows[index].elements[0].duration?.text || '';
                }else{
                  vendor.distance = vendor.firebaseData.dist.toFixed(1) + 'km';
                  vendor.distanceValue = 1000000;
                  vendor.duration = '';
                }
                const obj = this.mechanics.find(item => item.id === parseInt(vendor.id, 10));
                // console.log(obj);
                let indexArray = this.mechanics.indexOf(obj);
                if (obj) {
                  obj.distance = vendor.distance;
                  obj.distanceValue = vendor.distanceValue;
                  obj.duration = vendor.duration;
                  obj.status = vendor.status;
                  obj.stale = vendor.stale;
                  obj.mechanicStatus = mechanicStatus[obj.status];
                  this.mechanics.fill(obj, indexArray, indexArray++);
                }
              });

              this.mechanics.sort((a, b) => {
                return a.status < b.status ? -1 : (a.status > b.status ? 1 : 0);
              });
              const free = this.mechanics.filter(item => item.status === 0);
              const onBreak = this.mechanics.filter(item => item.status === 3);
              const busy = this.mechanics.filter(item => {
                return item.status === 1 || item.status === 2;
              });
              free.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              busy.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              onBreak.sort((a, b) => {
                return a.distanceValue < b.distanceValue ? -1 : (a.distanceValue > b.distanceValue ? 1 : 0);
              });
              console.log(free, busy, onBreak);
              this.mechanics = [...free, ...busy, ...onBreak];
              console.log(this.mechanics);
              this.filteredMechanics = this.mechanicCtrl.valueChanges.pipe(
              startWith(null),
                map((item: any) => item ? this.mechanic_filter(item) : this.mechanics.slice()));
            },error => {
              console.log(error)
            });
      this.mechanicService.setRefresh(true);
    },
      (error: any) => {
        this.loading = false;
        console.log(error);
      }
    );
  }

  selectMechanic(mechanic) {
    console.log(mechanic);
  }
  selectTeam(team, i) {
    this.selectedTeam = i;
    this.filter = {
      ...this.filter,
      team: team.id || null
    };
    this.getMechanics();
  }
  selectGeo(geo, i) {
    this.selectedGeo = i;
    this.filter = {
      ...this.filter,
      geo: geo.id
    };
    this.getMechanics();
  }
  selectTag(tag, i) {
    this.selectedTag = i;
    this.filter = {
      ...this.filter,
      tag: tag.id
    };
    this.getMechanics();
  }

  cancelStatusChange() {
      this.statusChangeModal.hide();
      this.modal.hide(1);
  }

  onStatusChangeConfirm($ev) {
      $ev.preventDefault();
      for (const c in this.statusForm.controls) {
        if (this.statusForm.controls.hasOwnProperty(c)) {
          this.statusForm.controls[c].markAsTouched();
        }
      }
      if (this.statusForm.valid) {
          const params = {
              status: 2
          };
          this.task.updateOrderStatus(this.currentTask.id, params)
              .subscribe((response: any) => {
                console.log(response);
                this.statusChangeModal.hide();
                this.modal.hide(1);
                this.reassignFn();
                setTimeout(() => {
                    this.task.clearCurrentTask();
                    this.task.clearTaskDetails();
                    this.task.setCurrentTask({});
                    this.task.setUpdatedTasks(true);
                });
              }, (error: any) => {
                  console.log(error);
              });
      }
  }

  assignMechanic() {
    if (!this.assignMode) {
      const params = {
        isActive: true,
        internalRating: 0,
        customerRating: 0,
        orderId: this.currentTask.id,
        vendorId: this.currentMechanic.id
      };
      this.task.assignMechanic(params).subscribe(
        (data: any) => {
          if (data.statusCode === 500) {
            this.main.showToast('error', data.message);
          } else {
            this.resetSlider();
          }
      },
      (error: any) => {
        console.log(error);
      }
      );
    } else {
      this.statusChangeModal.show();
    }
  }

  reassignFn() {
    const params = {
        isActive: this.orderDetails.isActive,
        internalRating: this.orderDetails.internalRating,
        customerRating: this.orderDetails.customerRating,
        orderId: this.orderDetails.orderId,
        vendorId: this.currentMechanic.id
      };
    this.task.reassignMechanic(this.currentTask.id, params).subscribe(
        (data: any) => {
          if (data.statusCode === 500) {
            this.main.showToast('error', data.message);
          } else {
            this.resetSlider();
          }
      },
      (error: any) => {
        console.log(error);
      }
      );
  }

  closeSlider() {
    const status = {
      show: false,
      mode: -1,
      task: {}
    };
    this.main.setAssignSliderStatus(status);
    this.mechanicService.setRefresh(true);
    this.unassignedmechanic();
  }

  resetSlider() {
    const status = {
      show: false,
      mode: -1,
      task: {}
    };
    this.selectedTeam = -1;
    this.selectedGeo = -1;
    this.selectedTag = -1;
    this.currentTask = {};
    this.currentMechanic = {};
    this.assignMode ? this.main.showToast('success', 'Vendor Reassigned Successfully')
        : this.main.showToast('success', 'Vendor Assigned Successfully');
    this.main.setAssignSliderStatus(status);
    this.task.setUpdatedTasks(true);
    this.task.clearCurrentTask();
    this.task.clearTaskDetails();
    this.task.setCurrentTask({});
    this.mechanicService.setRefresh(true);
  }

}
