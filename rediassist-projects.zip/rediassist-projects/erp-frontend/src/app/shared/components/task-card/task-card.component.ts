import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { MainService } from 'src/app/core/services/main/main.service';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { Task } from '../../interfaces/tasks.interface';

@Component({
  selector: 'app-task-card',
  templateUrl: './task-card.component.html',
  styleUrls: ['./task-card.component.scss']
})
export class TaskCardComponent implements OnInit {

  @Input() task: Task;
  @Output() toggleTaskDetails = new EventEmitter();
  @Output() toggleAssignSlider = new EventEmitter();
  constructor(public main: MainService, public vendorService: VendorsService, public taskService: TasksService) { }

  ngOnInit(): void {
  }

  openTaskDetails() {
    const emit: any = {
      val: true,
      task: this.task
    };
    this.toggleTaskDetails.emit(emit);
  }

  openAssignSlider(assignMode: number) {
    const emit: any = {
      val: true,
      task: this.task,
      assignMode
    };
    this.toggleAssignSlider.emit(emit);
  }

}
