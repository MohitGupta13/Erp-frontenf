import { Injectable } from '@angular/core';

const themeDefault = require('../../shared/styles/themes/theme-default.scss');
const themeDark = require('../../shared/styles/themes/theme-dark.scss');

@Injectable()
export class ThemesService {

    styleTag: any;
    defaultTheme = 'Default';

    constructor() {
        this.createStyle();
        this.setTheme(this.defaultTheme);
    }

    private createStyle() {
        const head = document.head || document.getElementsByTagName('head')[0];
        this.styleTag = document.createElement('style');
        this.styleTag.type = 'text/css';
        this.styleTag.id = 'appthemes';
        head.appendChild(this.styleTag);
    }

    setTheme(name) {
        switch (name) {
            case 'Default':
                this.injectStylesheet(themeDefault);
                break;
            case 'Dark':
                this.injectStylesheet(themeDark);
                break;
            default:
                this.injectStylesheet(themeDark);
                break;
        }
    }

    // since v9, content is available in 'default'
    injectStylesheet(css) {
        this.styleTag.innerHTML = css.default;
    }

    getDefaultTheme() {
        return this.defaultTheme;
    }

}
