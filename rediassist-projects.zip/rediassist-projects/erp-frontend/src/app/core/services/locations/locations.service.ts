import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { apiPath } from 'src/constant/api';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LocationsService {

  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(public main: MainService, private http: HttpClient) { }

  createLocation(payload) {
    return this.main.postRequests(apiPath.locations.list, payload);
  }

  editLocation(payload, id) {
    return this.main.patchRequests(`${apiPath.locations.list}${id}`, payload);
  }

  locationList(skip = 0) {
    const filter = {
      skip,
      limit: 10
    };
    return this.main.getRequests(apiPath.locations.list + '?filter=' + JSON.stringify(filter), 1);
  }

  locationCount() {
    // const where = {
    //     isActive: true
    // };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.locations.count, 1);
  }

  blockUnblockConfirm(payload, id) {
    return this.main.patchRequests(`${apiPath.locations.list}${id}`, payload, 1);
  }
}
