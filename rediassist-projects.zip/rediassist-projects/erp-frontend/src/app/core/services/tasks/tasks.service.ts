import { Injectable } from '@angular/core';
import { apiPath } from 'src/constant/api';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: "root",
})
export class TasksService {
  private selectedTask = new BehaviorSubject<any>({});
  private currentTask = new BehaviorSubject<any>({});
  private tasks = new BehaviorSubject<any>(false);
  private showPath = new BehaviorSubject<any>(false);
  private status = new BehaviorSubject<any>(0);
  public prvStatus = new BehaviorSubject<any>(0);
  private cancelStatus = new BehaviorSubject<any>(0);
  private bookingTimePopUp = new BehaviorSubject<any>(false);
  private taskFilter = new BehaviorSubject<any>({
    time: 4,
    client: 1,
    team: 1,
    location: 1,
  });
  headers: any = new HttpHeaders({ "Content-Type": "application/json" });
  constructor(public main: MainService, private http: HttpClient) {}

  getOrderList() {
    const filter = {
      order: ["bookingTime ASC"],
      include: [
        {
          relation: "vehicle",
        },
      ],
    };
    return this.main.getRequests(
      apiPath.orders.list + "?filter=" + JSON.stringify(filter)
    );
  }

  getStatusOrderList(status, taskFilter) {
    let where: any;
    where = {
      status,
    };
    const filter = {
      order: ["bookingTime ASC"],
      where,
      include: [
        {
          relation: "vehicle",
        },
        {
          relation: "location",
        },
      ],
    };
    if (status === 3) {
      filter.where = { status: { inq: [3, 4, 5, 6, 7, 8] } };
    }
    if (status === 9) {
      const ONE_DAY = 2 * 24 * 60 * 60 * 1000;
      filter.where = {
        status: { inq: [9, 10, 11, 12] },
        updatedAt: { gt: Date.now() - ONE_DAY },
      };
    }
    filter.where = {
      ...filter.where,
      clientId: taskFilter.client,
      locationId: taskFilter.location,
    };
    const timeStart = new Date();
    const timeEnd = new Date();
    timeEnd.setHours(23, 59, 59, 0);
    switch (taskFilter.time) {
      case 0:
        // today
        timeStart.setHours(0, 0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 1:
        // last 7 days
        timeStart.setDate(timeStart.getDate() - 7);
        timeStart.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 2:
        // last 30 days
        timeStart.setDate(timeStart.getDate() - 30);
        timeStart.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 3:
        // Future
        timeStart.setDate(timeStart.getDate() + 1);
        timeStart.setHours(0, 0, 0);
        timeEnd.setDate(timeEnd.getDate() + 8);
        timeEnd.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 4:
        // All
        filter.where = {
          ...filter.where,
        };
        delete filter.where.bookingTime;
        break;
      default:
        break;
    }
    return this.main.getTapRequests(
      apiPath.orders.list + "?filter=" + JSON.stringify(filter)
    );
  }

  getStatusOrderCounts(status, taskFilter) {
    let where: any;
    where = {
      status,
    };
    const filter = {
      where,
      // include: [{
      //     relation: 'vehicle'
      // }]
    };
    if (status === 3) {
      filter.where = { status: { inq: [3, 4, 5, 6, 7, 8] } };
    }
    if (status === 9) {
      const ONE_DAY = 2 * 24 * 60 * 60 * 1000;
      filter.where = {
        status: { inq: [9, 10, 11, 12] },
        updatedAt: { gt: Date.now() - ONE_DAY },
      };
    }
    filter.where = {
      ...filter.where,
      clientId: taskFilter.client,
      locationId: taskFilter.location,
    };
    const timeStart = new Date();
    const timeEnd = new Date();
    timeEnd.setHours(23, 59, 59, 0);
    switch (taskFilter.time) {
      case 0:
        // today
        timeStart.setHours(0, 0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 1:
        // last 7 days
        timeStart.setDate(timeStart.getDate() - 7);
        timeStart.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 2:
        // last 30 days
        timeStart.setDate(timeStart.getDate() - 30);
        timeStart.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 3:
        // Future
        timeStart.setDate(timeStart.getDate() + 1);
        timeStart.setHours(0, 0, 0);
        timeEnd.setDate(timeEnd.getDate() + 8);
        timeEnd.setHours(0, 0, 0);
        filter.where = {
          ...filter.where,
          bookingTime: {
            between: [timeStart, timeEnd],
          },
        };
        break;
      case 4:
        // All
        filter.where = {
          ...filter.where,
        };
        delete filter.where.bookingTime;
        break;
      default:
        break;
    }
    return this.main.getTapRequests(
      apiPath.orders.count + "?where=" + JSON.stringify(filter.where)
    );
  }

  getOrderAssignDetails(orderIDs) {
    const filter = {
      where: {
        orderId: {
          inq: [...orderIDs],
        },
      },
      include: [
        {
          relation: "vendor",
        },
      ],
    };
    return this.main.getRequests(
      apiPath.orderDetails.list + "?filter=" + JSON.stringify(filter)
    );
  }

  createTask(params) {
    return this.main.postRequests(apiPath.orders.list, params);
  }

  updateTaskBookingTime(params, id) {
    return this.main.patchRequests(`${apiPath.orders.list}/${id}`, params);
  }

  assignMechanic(params) {
    return this.main.postRequests(apiPath.orderDetails.list, params);
  }
  reassignMechanic(id, params) {
    return this.main.patchRequests(
      apiPath.orders.reassign.replace("{id}", id),
      params
    );
  }
  unassignMechanic(id) {
    return this.main.patchRequests(
      apiPath.orders.unassign.replace("{id}", id),
      {}
    );
  }
  taskDetails(id: number) {
    return this.main.getRequests(apiPath.orderDetails.list + id);
  }
  taskDetailsById(id: number) {
    const filter = {
      where: {
        orderId: id,
      },
    };
    return this.main.getRequests(
      apiPath.orderDetails.list + "?filter=" + JSON.stringify(filter)
    );
  }
  taskHistory(id: number) {
    return this.main.getRequests(
      apiPath.orderDetails.history.replace("{orderId}", id.toString())
    );
  }
  getFiles(ids) {
    const filter = {
      where: {
        id: { inq: ids },
        isActive: true,
      },
    };
    return this.main.getRequests(
      `${apiPath.file.get}?filter=${JSON.stringify(filter)}`
    );
  }
  downloadFile(id) {
    // return this.main.getRequests(`${apiPath.file.download}/${id}`);
    return this.http
      .get<any>(`${apiPath.file.download}/${id}`, {
        responseType: "blob" as "json",
      })
      .pipe(
        map((res: Response) => {
          return res;
        }),
        catchError((error: any) => {
          return throwError(error);
        })
      );
  }
  taskInvoice(id: number) {
    return this.main.getRequests(apiPath.orderDetails.invoice + id);
  }
  addServiceInvoice(params, id) {
    return this.main.patchRequests(
      apiPath.orderDetails.invoice_service.replace("{id}", id),
      params
    );
  }
  addAdhocServiceInvoice(params, id) {
    return this.main.patchRequests(
      apiPath.orderDetails.invoice_adhoc_service.replace("{id}", id),
      params
    );
  }
  addOrderNote(params) {
    return this.main.postRequests(apiPath.orderDetails.notes, params);
  }
  deleteServiceInvoice(serviceId, invoiceId) {
    // return this.main.deleteRequests(apiPath.orderDetails.invoice_service.replace('{id}', invoiceId), serviceId);
    const options = {
      headers: this.headers,
      body: serviceId,
    };
    return this.http
      .delete<any>(
        apiPath.orderDetails.invoice_service.replace("{id}", invoiceId),
        options
      )
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          return throwError(error);
        })
      );
  }
  deleteAdhocServiceInvoice(serviceName, invoiceId) {
    return this.main.deleteRequests(
      `${apiPath.orderDetails.invoice_adhoc_service.replace(
        "{id}",
        invoiceId
      )}/${serviceName}`
    );
  }
  checkService(locationId: number, clientId: number) {
    const filter = `?[where][clientId]=${clientId}&[where][locationId]=${locationId}`;
    return this.main.getRequests(apiPath.services.count + filter);
  }
  updateOrderStatus(id, params) {
    return this.main.patchRequests(
      apiPath.orders.search.replace("{id}", id),
      params
    );
  }
  
  manualTransaction(params) {
    return this.main.postRequests(apiPath.orderDetails.transactions, params);
  }

  searchCustomer(text: string) {
    return this.main.getRequests(
      apiPath.customers.search.replace("{mobile}", text)
    );
  }
  searchVehicle(text: string) {
    const space = /\s/g.test(text);
    if (!space) {
      return this.main.getRequests(
        apiPath.vehicles.search.replace("{make}", text).replace("{model}", text)
      );
    } else {
      const words = text.split(" ");
      const make = words[0];
      const model = words.slice(1).join(" ");
      return this.main.getRequests(
        apiPath.vehicles.search
          .replace("[or]", "[and]")
          .replace("{make}", make)
          .replace("{model}", model)
      );
    }
  }
  searchVehicleNumber(text: string) {
    return this.main.getRequests(
      apiPath.vehicles.number_search.replace("{number}", text)
    );
  }
  searchOrder(text: string) {
    return this.main.getRequests(
      apiPath.orders.query
        .replace("{custPhoneNumber}", text)
        .replace("{custName}", text)
        .replace("{id}", text)
    );
  }
  searchClosedOrder(text: string) {
    return this.main.getRequests(
      apiPath.orders.closedQuery
        .replace("{custPhoneNumber}", text)
        .replace("{custName}", text)
        .replace("{id}", text)
    );
  }
  searchInvoiceService(text: string) {
    return this.main.getRequests(
      apiPath.services.search.replace("{name}", text)
    );
  }

  getTaskDetails(): Observable<any> {
    return this.selectedTask.asObservable();
  }

  setTaskDetails(task: any) {
    console.log(task);
    this.selectedTask.next(task);
  }

  clearTaskDetails() {
    this.selectedTask.next({});
  }

  getCurrentTask(): Observable<any> {
    return this.currentTask.asObservable();
  }

  setCurrentTask(task: any) {
    this.currentTask.next(task);
  }

  clearCurrentTask() {
    this.currentTask.next({});
  }

  getUpdatedTasks(): Observable<any> {
    return this.tasks.asObservable();
  }

  setUpdatedTasks(flag: any) {
    this.tasks.next(flag);
  }

  clearUpdatedTasks() {
    this.tasks.next(false);
  }

  getTaskStatus(): Observable<any> {
    return this.status.asObservable();
  }

  setTaskStatus(status: any) {
    console.log("---------Calling Set Status ------");
    this.status.next(status);
  }

  clearTaskStatus() {
    this.status.next(0);
  }

  getTaskPrevStatus(): Observable<any> {
    return this.prvStatus.asObservable();
  }

  setTaskPrevStatus(prvStatus: any) {
    this.prvStatus.next(prvStatus);
  }

  clearTaskPrevStatus() {
    this.prvStatus.next(0);
  }

  getTaskCancelStatus(): Observable<any> {
    return this.cancelStatus.asObservable();
  }

  setTaskCancelStatus(cancelStatus: any) {
    this.cancelStatus.next(cancelStatus);
  }

  clearTaskCancelStatus() {
    this.cancelStatus.next(0);
  }

  getBookingTimePopUp(): Observable<any> {
    return this.bookingTimePopUp.asObservable();
  }

  setBookingTimePopUp(status: any) {
    this.bookingTimePopUp.next(status);
  }

  getTaskFilter(): Observable<any> {
    return this.taskFilter.asObservable();
  }

  setTaskFilter(filter: any) {
    this.taskFilter.next(filter);
  }

  getTaskPath(): Observable<any> {
    return this.showPath.asObservable();
  }

  setTaskPath(status: any) {
    this.showPath.next(status);
  }
}
