/// <reference types="@types/googlemaps" />
import { Injectable, TemplateRef, Injector } from '@angular/core';
import { HttpClient, HttpHeaders,  } from '@angular/common/http';
import { URLSearchParams } from '@angular/http';
import { Router, NavigationEnd } from '@angular/router';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Observable, throwError, Subject, BehaviorSubject } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { apiPath } from '../../../../constant/api';
import { SettingsService } from '../../settings/settings.service';
import { AuthService } from '../auth/auth.service';
import { environment } from '../../../../environments/environment';
import * as firebase from 'firebase';
declare var $: any;
declare const google: any;
declare var moment: any;

@Injectable({
  providedIn: 'root',
})
export class MainService {
  private serviceSubject = new BehaviorSubject<any>([]);
  private allServiceSubject = new BehaviorSubject<any>([]);
  private vehicleSubject = new BehaviorSubject<any>([]);
  private clientSubject = new BehaviorSubject<any>([]);
  private locationSubject = new BehaviorSubject<any>([]);
  private paymentTypeSubject = new BehaviorSubject<any>([]);
  private taskMarkers = new BehaviorSubject<any>([]);
  private mechanicMarkers = new BehaviorSubject<any>([]);
  private assignSlider = new BehaviorSubject<any>({});
  public firebaseDB;
  public jwt;
  public data;
  public services;
  public rates;
  public clients;
  public vehicles;
  public emailPattern = /^[a-z0-9]+[a-z0-9.+_]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  public namePattern = /^[a-zA-Z 0-9]*$/;
  public mobileNoPattern = /^(\+?\d{1,4}[\s-])?(?!0+\s+,?$)\d{10}\s*,?$/;
  public amountPattern = /^\d+(\.\d{1,2})?$/;
  public hitInProgress: any;
  public searchString: any;
  public toaster: any = this.toasterService;
  public toast;
  public loading;
  public config: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-center',
    animation: 'fade',
    limit: 5,
  });
  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  modalRef: BsModalRef;
  auth;
  orderETA: Observable<any>;
  constructor(
    public settings: SettingsService,
    private http: HttpClient,
    private router: Router,
    public toasterService: ToasterService,
    private modalService: BsModalService,
    private injector: Injector
  ) {
    // this.checkToken();
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) { /* Your code goes here on every router change */
        const status = {
          show: false,
          mode: -1,
          task: {}
        };
        this.setAssignSliderStatus(status);
      }
    });
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) { /* Your code goes here on every router change */
        const status = {
          show: false,
          mode: -1,
          task: {}
        };
        this.setAssignSliderStatus(status);
      }
    });
  }

  init() {
    this.auth = this.injector.get(AuthService);

  }

  getGlobalData() {
    this.getAllServices()
      .subscribe((data: any) => {
        this.services = data;
        this.setAllServiceList(data);
      }, (error: any) => {
        console.log(error);
      });
    this.getClients().subscribe(
      (data: any) => {
        // this.clients = data;
        console.log('client data-----------',data);
        this.setClientList(data);
        
      },
      (error: any) => {
        console.log(error);
      }
    );
    this.getAllLocations().subscribe(
      (data: any) => {
        // this.locations = data;
        this.setLocationList(data);
      },
      (error: any) => {
        console.log(error);
      }
    );
    this.getPaymentTypes().subscribe(
      (data: any) => {
        // this.clients = data;
        this.setPaymentTypeList(data);
      },
      (error: any) => {
        console.log(error);
      }
    );
    this.getVehicles().subscribe(
      (data: any) => {
        this.vehicles = data;
        this.setVehicleList(data);
      },
      (error: any) => {
        console.log(error);
      }
    );
    if (firebase.apps.length === 0) {
        firebase.initializeApp(environment.firebaseConfig);
    }
    this.firebaseDB = firebase.firestore();
    // this.getVendorLocation();
  }

  getVendorLocation(vendorId): Observable<any> {
    return new Observable((observer) => {
      this.firebaseDB.collection('vendor').doc(vendorId.toString())
        .onSnapshot((doc) => {
          console.log('Latest FireBase data: ', doc.data());
          observer.next(doc.data());
      });
    });
  }


  getAllVendorLocation(vendorIds): Observable<any> {    
    return new Observable((observer) => {
      // this.firebaseDB.FieldPath.documentId()
      // vendorIds
      this.firebaseDB.collection('vendor')
        .where('vs', 'in', ['ON DUTY', 'Busy'])
        // , 'Busy', 'Transit', 'On Break'
        // .where('VendorStatus', 'in', ['ON DUTY', 'Busy', 'Idle', 'On Break'])
        .get()
        .then((querySnapshot) => {
          const vendorLocations = [];
          querySnapshot.forEach((doc) => {
            
              // doc.data() is never undefined for query doc snapshots
            // console.log(doc.id, doc.data());
              for(let i = 0;i < vendorIds.length ; i++){
                 if(doc.id == vendorIds[i]){
                  vendorLocations.push({ id: doc.id, data: doc.data() });
                }
              }            
          });
          observer.next(vendorLocations);
        })
        .catch((error) => {
            console.log('Error getting documents: ', error);
        });
        // .get().then((res) => {
        //   console.log(res);
        //   res.forEach((doc) => {
        //     console.log({ id: doc.id, data: doc.data() });
        //     doc = { id: doc.id, data: doc.data() };
        //   });
        //   console.log(res);
        //   observer.next(res);
        // });

    });
  }

  getDistance(origin, destination): Observable<any> {
    console.log(origin);
    console.log(destination);

    return new Observable((observer) => {
      let distanceResults = {
        rows: [],
        originAddresses: [],
        destinationAddresses: []
      };
      const n = 25 //tweak this to add more items per line
      const result = new Array(Math.ceil(origin.length / n))
      .fill(0)
      .map(_ => origin.splice(0, n));
      const resultArray = new Array(result.length);
      result.forEach((element, index) => {
        return new google.maps.DistanceMatrixService().getDistanceMatrix({
          origins: element,
          destinations: [destination],
          travelMode: 'DRIVING'
        }, (results: any) => {
            console.log(results);
            resultArray[index] = {
              rows: results.rows,
              originAddresses: results.originAddresses,
              destinationAddresses: results.destinationAddresses
            }
          // distanceResults = {
          //   rows: distanceResults.rows.concat(results.rows),
          //   originAddresses: distanceResults.originAddresses.concat(results.originAddresses),
          //   destinationAddresses: results.destinationAddresses,
          // }
        });
      });

      setTimeout(() => {
        for (const resultObj of resultArray) {
          distanceResults = {
            rows: distanceResults.rows.concat(resultObj.rows),
            originAddresses: distanceResults.originAddresses.concat(resultObj.originAddresses),
            destinationAddresses: resultObj.destinationAddresses,
          }
        }
        observer.next(distanceResults);
      }, result.length*1000);
    });
  }

  urlParams(data: any) {
    const body = new URLSearchParams();
    Object.keys(data).forEach((key) => {
      body.set(key, data[key]);
    });
    return body.toString();
  }

  openModal(template: TemplateRef<any>, className: any) {
    this.modalRef = this.modalService.show(template, { class: className });
  }

  showToast = (type, message) => {
    if (this.toast) {
      this.toaster.clear(this.toast.toastId, this.toast.toastContainerId);
    }
    this.toast = this.toaster.pop(type, message);
    // this.toaster.pop(type, message, pos);
  }

  getLocations(lat, lon): Observable<any> {
    return this.getRequests(apiPath.locations.search.replace('{lat}', lat).replace('{lon}', lon));
  }


  getServices(filter): Observable<any> {
    return this.getRequests(apiPath.services.list + filter);
  }
  getAllServices(): Observable<any> {
    return this.getRequests(apiPath.services.all);
  }
  // getRates(): Observable<any> {
  //   return this.getRequests(apiPath.services.list);
  // }

  getPaymentTypes(): Observable<any> {
    return this.getRequests(apiPath.orders.paymentTypes);
  }

  getClients(): Observable<any> {
    return this.getRequests(apiPath.clients.list);
  }

  getAllLocations(): Observable<any> {
    return this.getRequests(apiPath.locations.list);
  }

  getVehicles(): Observable<any> {
    return this.getRequests(apiPath.vehicles.list);
  }

  setServiceList(services: any) {
    this.serviceSubject.next(services);
  }

  clearServiceList() {
    this.serviceSubject.next([]);
  }

  getServiceList(): Observable<any> {
    return this.serviceSubject.asObservable();
  }

  setAllServiceList(services: any) {
    this.allServiceSubject.next(services);
  }

  clearAllServiceList() {
    this.allServiceSubject.next([]);
  }

  getAllServiceList(): Observable<any> {
    return this.allServiceSubject.asObservable();
  }


  setVehicleList(vehicles: any) {
    this.vehicleSubject.next(vehicles);
  }

  clearVehicleList() {
    this.vehicleSubject.next([]);
  }

  getVehicleList(): Observable<any> {
    return this.vehicleSubject.asObservable();
  }

  // setRateList(services: any) {
  //   this.rateSubject.next(services);
  // }

  // clearRateList() {
  //   this.rateSubject.next([]);
  // }

  // getRateList(): Observable<any> {
  //   return this.rateSubject.asObservable();
  // }

  setClientList(services: any) {
    this.clientSubject.next(services);
  }

  clearClientList() {
    this.clientSubject.next([]);
  }

  getClientList(): Observable<any> {
    return this.clientSubject.asObservable();
  }

  setLocationList(locations: any) {
    this.locationSubject.next(locations);
  }

  clearLocationList() {
    this.locationSubject.next([]);
  }

  getLocationList(): Observable<any> {
    return this.locationSubject.asObservable();
  }

  setPaymentTypeList(services: any) {
    this.paymentTypeSubject.next(services);
  }

  clearPaymentTypeList() {
    this.paymentTypeSubject.next([]);
  }

  getPaymentTypeList(): Observable<any> {
    return this.paymentTypeSubject.asObservable();
  }

  setTaskMarkers(markers: any) {
    this.taskMarkers.next(markers);
  }

  clearTaskMarkers() {
    this.taskMarkers.next([]);
  }

  getTaskMarkers(): Observable<any> {
    return this.taskMarkers.asObservable();
  }

  setMechanicMarkers(markers: any) {
    this.mechanicMarkers.next(markers);
  }

  clearMechanicMarkers() {
    this.mechanicMarkers.next([]);
  }

  getMechanicMarkers(): Observable<any> {
    return this.mechanicMarkers.asObservable();
  }

  setAssignSliderStatus(status: any) {
    this.assignSlider.next(status);
  }

  getAssignSliderStatus(): Observable<any> {
    return this.assignSlider.asObservable();
  }

  getRequests(url: string, auth = 0) {
    return this.http
      .get<any>(url, { headers: this.headers})
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          console.log(error);
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }

  getTapRequests(url: string, auth = 0) {
    return this.http
      .get<any>(url, { headers: this.headers})
      .pipe(
        tap((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          console.log(error);
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }

  postRequests(url: string, payload: any, auth = 0) {
    return this.http
      .post<any>(url, payload, { headers: this.headers})
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }

  putRequests(url: string, payload: any, auth = 0) {
    return this.http
      .put<any>(url, payload, { headers: this.headers})
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }

  patchRequests(url: string, payload: any, auth = 0) {
    return this.http
      .patch<any>(url, payload, { headers: this.headers})
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }

  deleteRequests(url: string, auth = 0) {
    return this.http
      .delete<any>(url, { headers: this.headers})
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          if (error.status === 401) {
            this.auth.logoutRedirect();
            this.showToast('error', 'Authentication failed, please login again');
          }
          if (error.status === 403) {
            this.auth.logoutRedirect();
            this.showToast('error', 'You are not authorized for this action');
          }
          return throwError(error);
        })
      );
  }
}
