import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { apiPath } from 'src/constant/api';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ClientsService {

  // private openModal = new BehaviorSubject<boolean>(false);
  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(public main: MainService, private http: HttpClient) { }

  // getModalFlag(): Observable<any> {
  //   return this.openModal.asObservable();
  // }

  // setModalFlag(flag: any) {
  //   this.openModal.next(flag);
  // }

  createClient(payload) {
    return this.main.postRequests(apiPath.clients.list, payload);
  }

  editClient(payload, id) {
    return this.main.putRequests(`${apiPath.clients.list}${id}`, payload);
  }

  clientList(skip = 0) {
    const filter = {
      skip,
      limit: 10
    };
    return this.main.getRequests(apiPath.clients.list + '?filter=' + JSON.stringify(filter), 1);
  }

  clientCount() {
    // const where = {
    //     isActive: true
    // };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.clients.count, 1);
  }

  blockUnblockConfirm(payload, id) {
    return this.main.patchRequests(`${apiPath.clients.list}${id}`, payload, 1);
  }

  addClient(payload){
    return this.http.post<any>(apiPath.clients.list, payload,{ headers: this.headers })
      .pipe(
        map((data: any) => {
          return data;
        }),
        catchError((error: any) => {
          return throwError(error);
        })
      );
  }
}
