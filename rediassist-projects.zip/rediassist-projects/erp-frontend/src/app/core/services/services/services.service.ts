import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { apiPath } from 'src/constant/api';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  // private openModal = new BehaviorSubject<boolean>(false);
  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(public main: MainService, private http: HttpClient) { }

  createService(payload) {
    return this.main.postRequests(apiPath.services.all, payload);
  }

  editService(payload, id) {
    return this.main.putRequests(`${apiPath.services.all}/${id}`, payload);
  }

  serviceList(skip = 0) {
    const filter = {
      skip,
      limit: 10,
      // include: [{
      //     relation: 'vehicle'
      // }]
    };
    return this.main.getRequests(apiPath.services.all + '?filter=' + JSON.stringify(filter), 1);
  }

  serviceCount() {
    // const where = {
    //     isActive: true
    // };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.services.count, 1);
  }

  blockUnblockConfirm(payload, id) {
    return this.main.patchRequests(`${apiPath.services.all}/${id}`, payload, 1);
  }
}
