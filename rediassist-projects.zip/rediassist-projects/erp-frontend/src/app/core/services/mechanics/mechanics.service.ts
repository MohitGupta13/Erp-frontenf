import { Injectable } from '@angular/core';
import { apiPath } from 'src/constant/api';
import { HttpClient } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MechanicsService {

  private refresh = new BehaviorSubject<any>(false);
  constructor(public main: MainService, private http: HttpClient) { }

  getMechanicList() {
    const filter = {
      where: {        
        isActive: true
      },
      include: [{
          relation: 'team'
      }, {
          relation: 'shift'
      }]
    };
    return this.main.getRequests(apiPath.mechanics.list + '?filter=' + JSON.stringify(filter));
  }


  getRefresh(): Observable<any> {
    return this.refresh.asObservable();
  }

  setRefresh(refresh: any) {
    this.refresh.next(refresh);
  }
}
