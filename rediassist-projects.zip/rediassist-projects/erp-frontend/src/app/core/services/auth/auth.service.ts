import { Injectable, Injector } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
import { MainService } from '../main/main.service';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { apiPath } from 'src/constant/api';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  jwt;
  headers: any = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' });
  private token = new BehaviorSubject<any>([]);
  mainService;
  constructor(public http: HttpClient, public router: Router, private injector: Injector) {
    this.getToken().subscribe((value: any) => {
      this.jwt = value;
      this.headers = new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + this.jwt
      });
    });
    this.mainService = this.injector.get(MainService);
  }

  public isAuthenticated() {
    if (!localStorage.getItem('token') || localStorage.getItem('token') == null) {
      return false;
    } else {
      return true;
      //   const data = {
      //     access_token: localStorage.getItem('token'),
      //     device_type: 0,
      //     app_type: 1,
      //     app_version: 103,
      //     device_id: localStorage.getItem('user')
      //   };

      //   this.http.post(`${environment.baseUrl}`, this.mainService.urlParams(data), { headers: this.headers })
      //     .subscribe((response: any) => {
      //       this.mainService.showToast('success', response);
      //     }, (error: any) => {
      //       this.mainService.showToast('error', error);
      //     });
      //   return true;
      // }
    }
  }

  login(payload: any) {
    // const params = this.mainService.urlParams(payload);
    return this.mainService.postRequests(apiPath.auth.login, payload).subscribe(
                (data: any) => {
                    localStorage.setItem('token', data.token);
                    this.setToken(data.token);
                    this.mainService.showToast('success', 'Login Successfully');
                    this.checkToken();
                    this.router.navigate(['home']);
                },
                (error: any) => {
                    console.log(error);
                    const err = error.error;
                    this.mainService.showToast('error', err.error.message);
                }
            );
  }

  logoutRedirect() {
    localStorage.removeItem('token');
    this.clearToken();
    this.router.navigate(['login']);
  }
  checkToken() {
    this.mainService.init();
    if (
      !localStorage.getItem('token') ||
      localStorage.getItem('token') == null
    ) {
      this.logoutRedirect();
      return false;
    } else {
      this.setToken(localStorage.getItem('token'));
      this.mainService.getGlobalData();
    }
  }

  setToken(jwt: any) {
    this.token.next(jwt);
  }

  clearToken() {
    this.token.next([]);
  }

  getToken(): Observable<any> {
    return this.token.asObservable();
  }
}
