import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { apiPath } from 'src/constant/api';
@Injectable({
  providedIn: 'root'
})
export class VehiclesService {

  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(public main: MainService, private http: HttpClient) { }

  createVehicle(payload) {
    return this.main.postRequests(apiPath.vehicles.list, payload);
  }

  editVehicle(payload, id) {
    return this.main.putRequests(`${apiPath.vehicles.list}${id}`, payload);
  }

  getVehicle(id) {
    return this.main.getRequests(`${apiPath.vehicles.list}${id}`);
  }

  vehicleList(skip = 0) {
    const filter = {
      skip,
      limit: 10
    };
    return this.main.getRequests(apiPath.vehicles.list + '?filter=' + JSON.stringify(filter), 1);
  }

  vehicleCount() {
    // const where = {
    //     isActive: true
    // };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.vehicles.count, 1);
  }

  blockUnblockConfirm(payload, id) {
    return this.main.patchRequests(`${apiPath.vehicles.list}${id}`, payload, 1);
  }

  bikeList(skip = 0) {
    const filter = {
      skip,
      limit: 10,
      where: {
        type: 'BIKE'
      }
    };
    return this.main.getRequests(apiPath.vehicles.list + '?filter=' + JSON.stringify(filter), 1);
  }

  bikeCount() {
    const where = {
      type: 'BIKE'
    };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.vehicles.count + '?where=' + JSON.stringify(where), 1);
  }

  carList(skip = 0) {
    const filter = {
      skip,
      limit: 10,
      where: {
        type: 'CAR'
      }
    };
    return this.main.getRequests(apiPath.vehicles.list + '?filter=' + JSON.stringify(filter), 1);
  }

  carCount() {
    const where = {
      type: 'CAR'
    };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.vehicles.count + '?where=' + JSON.stringify(where), 1);
  }


}
