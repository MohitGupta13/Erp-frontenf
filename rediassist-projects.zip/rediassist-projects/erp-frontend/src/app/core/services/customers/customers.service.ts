import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MainService } from '../main/main.service';
import { apiPath } from 'src/constant/api';
@Injectable({
  providedIn: 'root'
})

export class CustomersService {

  headers: any = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(public main: MainService, private http: HttpClient) { }

  createCustomer(payload) {
    return this.main.postRequests(apiPath.customers.list, payload);
  }

  editCustomer(payload, id) {
    return this.main.putRequests(`${apiPath.customers.list}${id}`, payload);
  }

  customerList(skip = 0) {
    const filter = {
      skip,
      limit: 10
    };
    return this.main.getRequests(apiPath.customers.list + '?filter=' + JSON.stringify(filter), 1);
  }

  customerCount() {
    // const where = {
    //     isActive: true
    // };
    //  + '?where=' + JSON.stringify(where)
    return this.main.getRequests(apiPath.customers.count, 1);
  }

  blockUnblockConfirm(payload, id) {
    return this.main.patchRequests(`${apiPath.customers.list}${id}`, payload, 1);
  }
}
