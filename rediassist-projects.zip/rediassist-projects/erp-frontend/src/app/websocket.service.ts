import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private url = 'http://localhost:4000';
  private socket;    

  constructor() {
      this.socket = io(this.url);
  }

  public publishMessage(data){
   this.socket.emit('alert',`Order #${data} was successfully Created`)
  }

  public vendorcreated(data){
    this.socket.emit('alert',`Vendor ${data} was successfully Created`)
   }

  public vendorupdated(data){
    this.socket.emit('alert',`Vendor Id:${data} Updated`)
  } 

  public vendorblocked(data,name){
    this.socket.emit('alert',`Vendor Id:${data}(${name}) blocked`)
  }

  public Bookingrescheduled(data){
    this.socket.emit('alert',`Task #${data} Booking Rescheduled`)
  }

  public unassignedmechanic(notification){
    this.socket.emit('alert', "UnAssigned Mechanic",notification)
  }

  public cancelorder(data){
    this.socket.emit('alert',`Order #${data} Cancelled`)
  }

  public getMessage = () => {
    return Observable.create((observer) => {
    this.socket.on('alert', (notification) => {
    console.log(notification)
    observer.next(notification);
    });
    });
  }
}