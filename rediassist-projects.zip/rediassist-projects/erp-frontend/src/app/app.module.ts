import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // this is needed!
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { AppComponent } from './app.component';

import { CoreModule } from './core/core.module';
import { LayoutModule } from './layout/layout.module';
import { SharedModule } from './shared/shared.module';
import { RoutesModule } from './routes/routes.module';
import { AuthGuard } from './core/guards/auth.guard';
import { MainService } from './core/services/main/main.service';
import { LoaderInterceptorService } from './core/services/loader/intercepter';
import { ToasterModule } from 'angular2-toaster';
import { AuthService } from './core/services/auth/auth.service';
import {WebsocketService} from './websocket.service';
import {SocketIoModule,SocketIoConfig} from 'ngx-socket-io';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'

// https://github.com/ocombe/ng2-translate/issues/218
export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

const config: SocketIoConfig = { url: 'http://localhost:4000', options: {} };

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        HttpClientModule,
        BrowserAnimationsModule, // required for ng2-tag-input
        CoreModule,
        LayoutModule,
        SocketIoModule.forRoot(config),
        SharedModule.forRoot(),
        RoutesModule,
        ToasterModule.forRoot(),
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        NgbModule
    ],
    providers: [
        WebsocketService,
        AuthGuard,
        MainService,
        AuthService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: LoaderInterceptorService,
            multi: true
        }],
    bootstrap: [AppComponent]
})
export class AppModule { }
