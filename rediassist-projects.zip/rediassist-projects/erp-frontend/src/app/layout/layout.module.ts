import { NgModule } from '@angular/core';

import { LayoutComponent } from './layout.component';
import { HeaderComponent } from './header/header.component';
import { NavsearchComponent } from './header/navsearch/navsearch.component';
import { MechanicSidebarComponent } from './mechanic-sidebar/mechanic-sidebar.component';
import { TasksSidebarComponent } from './tasks-sidebar/tasks-sidebar.component';

import { SharedModule } from '../shared/shared.module';
import { TaskDetailsComponent } from './task-details/task-details.component';
import { VendorLayoutComponent } from './vendor-layout/vendor-layout.component';
import { DocumentComponent } from './document/document.component';
import { AssignMechanicComponent } from './assign-mechanic/assign-mechanic.component';

@NgModule({
    imports: [
        SharedModule
    ],
    providers: [
    ],
    declarations: [
        LayoutComponent,
        HeaderComponent,
        NavsearchComponent,
        TasksSidebarComponent,
        MechanicSidebarComponent,
        TaskDetailsComponent,
        VendorLayoutComponent,
        DocumentComponent,
        AssignMechanicComponent
    ],
    exports: [
        LayoutComponent,
        HeaderComponent,
        NavsearchComponent
    ]
})
export class LayoutModule { }
