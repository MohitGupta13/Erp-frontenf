import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { MainService } from 'src/app/core/services/main/main.service';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
import { NgbModalConfig, NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-assign-mechanic',
  templateUrl: './assign-mechanic.component.html',
  styleUrls: ['./assign-mechanic.component.scss'],
  // add NgbModalConfig and NgbModal to the component providers
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.None
})
export class AssignMechanicComponent implements OnInit {

  profilePic: string;
  assignMode = 0;

  @Input()
  data: any;

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public vendorService: VendorsService,
    public main: MainService,
    public task: TasksService,
    public mechanicService: MechanicsService) { 
    // customize default values of modals used by this component tree
    config.backdrop = 'static';
    config.keyboard = false;
  }

  openAssignMechanicPopup(content) {
    this.modalService.open(content);
  }

  ngOnInit(): void {
    const { mechanicDetails } = this.data;
    this.getImageFromUrl(mechanicDetails.profilePic1);
  }

  assignMechanic() {
    const { taskId, mechanicDetails } = this.data;
    const params = {
      isActive: true,
      internalRating: 0,
      customerRating: 0,
      orderId: taskId,
      vendorId: mechanicDetails.id
    };
    this.task.assignMechanic(params).subscribe(
      (data: any) => {
        if (data.statusCode === 500) {
          this.main.showToast('error', data.message);
        } else {
          this.resetSlider();
        }
    },
    (error: any) => {
      console.log(error);
    }
    );
  }

  resetSlider() {
    const status = {
      show: false,
      mode: -1,
      task: {}
    };
    this.assignMode ? this.main.showToast('success', 'Vendor Reassigned Successfully')
        : this.main.showToast('success', 'Vendor Assigned Successfully');
    this.main.setAssignSliderStatus(status);
    this.task.setUpdatedTasks(true);
    this.task.clearCurrentTask();
    this.task.clearTaskDetails();
    this.task.setCurrentTask({});
    this.mechanicService.setRefresh(true);
    this.cancel();
  }

  cancel () {
    this.activeModal.close('Close click');
  }

  getImageFromUrl(id) {
    this.vendorService.downloadFile(id).subscribe(
      (data: any) => {
        const b = new Blob([data], { type: 'image/jpeg' });
        const imageUrl = window.URL.createObjectURL(b);
        this.profilePic = imageUrl;
    },
      (error: any) => {
      }
    );
  }

}
