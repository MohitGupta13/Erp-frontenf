import { Component, OnInit, Input } from '@angular/core';
import { Lightbox } from 'ngx-lightbox';
import { LightboxConfig } from "ngx-lightbox";
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { DomSanitizer } from "@angular/platform-browser";
@Component({
  selector: "app-document",
  templateUrl: "./document.component.html",
  styleUrls: ["./document.component.scss"],
})
export class DocumentComponent implements OnInit {
  @Input() document: any;
  isLoading: boolean;
  imageFound: boolean;
  imageUrl;
  lightBoxImageUrl;
  constructor(
    public taskService: TasksService,
    private _lightbox: Lightbox,
    private _lightboxConfig: LightboxConfig,
    private sanitizer: DomSanitizer
  ) {
    _lightboxConfig.centerVertically = true;
    _lightboxConfig.fitImageInViewPort = true;
  }

  ngOnInit(): void {
    this.isLoading = true;
    this.taskService.downloadFile(this.document.id).subscribe(
      (data: any) => {
        console.log(data);
        if (data.type !== "application/pdf") {
          this.isLoading = false;
          this.imageFound = true;
          const b = new Blob([data], { type: "image/jpeg" });
          const imageUrl = window.URL.createObjectURL(b);
          this.lightBoxImageUrl = this.sanitizer.bypassSecurityTrustUrl(
            window.URL.createObjectURL(b)
          );
          this.imageUrl = imageUrl;
        } else {
          this.isLoading = false;
          this.imageFound = true;
          this.imageUrl = "assets/img/svg/pdf.svg";
        }
        console.log(this.imageUrl);
      },
      (error: any) => {
        this.imageFound = false;
        this.isLoading = false;
      }
    );
  }

  public getSantizeUrl(url: string) {
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  open(): void {
    // open lightbox
    console.log(this.sanitizer.bypassSecurityTrustUrl(this.imageUrl));
    const image = {
      src: this.lightBoxImageUrl,
      caption:
        this.document.fileType === "PreOrder"
          ? "Pre Order Pic"
          : "Post Order Pic",
      thumb: null
    };
    const imageArr = [image];
    this._lightbox.open(imageArr);
  }

  close(): void {
    this._lightbox.close();
  }
}
