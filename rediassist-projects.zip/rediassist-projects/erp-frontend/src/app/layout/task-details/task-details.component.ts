/// <reference types="@types/googlemaps" />
import { Component, OnInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { Task } from '../../shared/interfaces/tasks.interface';
import { FormGroup, FormBuilder, Validators, FormControl, ValidatorFn } from '@angular/forms';
import { CustomValidators } from 'ngx-custom-validators';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { Observable, Observer, of, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { taskStatus } from 'src/constant/data';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Service } from 'src/app/shared/interfaces/services.interface';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
declare const google: any;
@Component({
  selector: "app-task-details",
  templateUrl: "./task-details.component.html",
  styleUrls: ["./task-details.component.scss"],
})

export class TaskDetailsComponent implements OnInit {
  @ViewChild("detailsSlider") detailsSlider: ElementRef;
  @ViewChild("detailsTabs", { static: false }) detailsTabs: TabsetComponent;
  @Output() closeDetails = new EventEmitter();
  @Output() toggleAssignSlider = new EventEmitter();
  task: Task;
  taskDetails;
  preOrderFiles;
  postOrderFiles;
  notesForm: FormGroup;
  paymentForm: FormGroup;
  invoiceForm: FormGroup;
  discountForm: FormGroup;
  items = [];
  adhocItems = [];
  services;
  history;
  isEnable: boolean;
  notes = [];
  invoice;
  subTotal = 0;
  tax = 0;
  finalAmount = 0;
  paid = 0;
  due = 0;
  discount = {
    coupon: "",
    amount: 0,
  };
  taxLabel = [];
  transactionDetails: any = [];
  taskStatus = taskStatus;
  service$: Observable<any[]>;
  serviceObj = {
    category: "",
    clientId: 0,
    createdAt: "",
    dayCharge: 0,
    description: "",
    displayToCustomer: false,
    id: 0,
    intervalTime: 0,
    isActive: false,
    leadTime: 0,
    locationId: 0,
    name: "",
    nightCharge: 0,
    serviceCode: "",
    tax: 0,
    updatedAt: "",
    vehicleId: 0,
  };
  newData;
  transactionCount;
  selectedService: Service = this.serviceObj;
  status;
  currentTime;
  changedBy;
  eta;
  locationSubscription: Subscription;
  showPathStatus = false;
  paymentTypes: any = [];
  subscription;
  constructor(
    public fb: FormBuilder,
    public taskService: TasksService,
    public main: MainService,
    public mechanicService: MechanicsService
  ) {
    this.notesForm = fb.group({
      note: [null, Validators.required],
      note_type: ["Internal", Validators.required],
    });
    this.invoiceForm = fb.group({
      service: [null, Validators.required],
      quantity: [null, Validators.required],
      tax: [null, Validators.required],
      rate: [null, Validators.required],
      amount: [null],
      id: [null],
    });
    this.discountForm = fb.group({
      coupon: [null, Validators.required],
    });
    this.paymentForm = fb.group({
      mode: ["", Validators.required],
      amount: [null, Validators.required],
      refNumber: ["", Validators.required],
    });
    this.main.getAllServiceList().subscribe((value: any) => {
      this.services = value;
    });
    this.taskService.getCurrentTask().subscribe((task: any) => {
      if (Object.keys(task).length === 0) {
        if (
          this.detailsSlider?.nativeElement.classList.contains(
            "showDetailsSlider"
          )
        ) {
          this.detailsSlider?.nativeElement.classList.remove(
            "showDetailsSlider"
          );
          this.closeDetails.emit(true);
          this.taskService.setUpdatedTasks(true);
          this.mechanicService.setRefresh(true);
          if (this.subscription) {
            this.subscription.unsubscribe();
          }
        }
      }
    });

    // this.taskService.getTaskStatus().subscribe((sts) => {
    //   let chngStatus = sts;         
    //   this.taskService.getCurrentTask().subscribe((task: any) => {
    //     if(chngStatus){
    //       task.status = chngStatus;
    //     }
    //   })
    // })

    this.taskService.getTaskStatus().subscribe((sts) => {
      let chngStatus = sts;   
      console.log("Prev Status---",this.taskService.prvStatus.value);
      // console.log("change status:-:-:-::::",chngStatus)    
      this.taskService.getCurrentTask().subscribe((task: any) => {
        if(chngStatus) {
          console.log("Before Task :::---",task)
          task.status = chngStatus;
          console.log("After Task :::---",task)
        }
      })
    })

    this.taskService.getTaskPath().subscribe((data: any) => {
      this.showPathStatus = !data;
    });
    this.subscription = this.main
      .getPaymentTypeList()
      .subscribe((value: any) => {
        this.paymentTypes = value;
      });
  }

  ngOnInit(): void {
    // console.log("types",this.paymentTypes)
    this.service$ = new Observable((observer: Observer<string>) => {
      observer.next(this.invoiceForm.get("service").value);
    }).pipe(
      switchMap((query: string) => {
        if (query) {
          return this.taskService.searchInvoiceService(query);
        }
        return of([]);
      })
    );

  }

  init() {
    const dt = new Date(this.task.bookingTime);
    const hr = dt.getHours();
    // console.log(dt, hr);
    this.currentTime = hr >= 20 || hr < 8 ? 1 : 0;
    // console.log(this.currentTime);
    this.getTaskHistory();
    this.getTaskInvoice();
    this.getTaskDetails();
    console.log("status in init()---",this.task);
    if (this.task.status > 1 && this.task.status < 5) {
      this.getTaskETA();
    } else {
      this.eta = "";
    }
  }

  getTaskDetails() {
    this.taskService.taskDetailsById(this.task.id).subscribe(
      (data: any) => {
        console.log("task details on init-----",data);
        this.taskDetails = data[0];

          if(this.taskDetails && this.taskDetails.files){
              this.getTaskFiles(this.taskDetails.files);
          }    
       },
      (error: any) => {
      }
    );
    // console.log(this.task.id)
  }

  getTaskFiles(files) {

    // this.taskFiles = files;
    this.taskService.getFiles(files).subscribe(
      (data: any) => {
        // console.log(data);
        this.postOrderFiles = data.filter(doc => doc.fileType === 'PostOrder');
        this.preOrderFiles = data.filter(doc => doc.fileType === 'PreOrder');
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  async getTaskETA() {
    const taskLatLng = `${this.task?.taskGeopoint?.lat},${this.task?.taskGeopoint?.lng}`;
    const vendor = await this.main.firebaseDB
      .collection("vendor")
      .doc(this.task?.vendor.id.toString())
      .get();
    const data = vendor.data();
    console.log("Current doc data for ETA: ", data);
    this.eta = "";
    const mechLatLng = `${data.Locations?.latitude},${data.Locations?.longitude}`;
    return new google.maps.DistanceMatrixService().getDistanceMatrix(
      {
        origins: [mechLatLng],
        destinations: [taskLatLng],
        travelMode: "DRIVING",
      },
      (results: any) => {
        this.eta = results.rows[0].elements[0];
      }
    );
  }

  getTaskHistory() {
    this.history = [];
    if (this.task.id) {
      this.changedBy = undefined;
      this.taskService.taskHistory(this.task.id).subscribe(
        (data: any) => {
          this.history = data;
          this.history.forEach((history) => {            
            if(history.recordingUrl){
              var au = document.createElement('audio');             
              au.src = history.recordingUrl;
              au.addEventListener('loadedmetadata', function(){                  
                  var duration = au.duration;                  
                  history.duration = Math.floor(duration / 60)+':'+Math.floor(duration % 60);                  
              },false);
            }
            if (history.orderJson.status === this.task.status) {
              this.changedBy = history.changedBy;
              if (this.changedBy) {
                this.changedBy.createdAt = history.createdAt;
              }
              return;
            }
          });
          // console.log(this.task);
        },
        (error: any) => {
          // console.log(error);
        }
      );
    }
  }
  getTaskInvoice() {
    if (this.task.invoiceId) {
      this.taskService.taskInvoice(this.task.invoiceId).subscribe(
        (data: any) => {
          this.invoice = data;
          //console.log('nagoo',this.invoice);
          this.items = [];
          this.adhocItems = [];
          this.subTotal = 0;
          this.tax = 0;
          this.discount = {
            coupon: "",
            amount: 0,
          };
          this.paid = this.invoice.paid;
          this.transactionDetails = this.invoice.transactions; //transactions
          this.transactionCount = this.transactionDetails.length;
          this.finalAmount = this.invoice.amount - this.discount.amount;
          this.due = this.invoice.due;
          this.invoice.services.forEach((service) => {
            const serviceId = parseInt(Object.keys(service)[0], 10);
            const serviceObj = service[serviceId].service;
            serviceObj.quantity = service[serviceId].quantity;
            this.items.push(serviceObj);
          });

          if (this.invoice.adhocServices) {
            this.adhocItems = [...this.invoice.adhocServices];
          }
          //console.log("hello---",this.adhocItems);
          // this.invoice.adhocServices.forEach(service => {
          //   this.adhocItems.push(service);
          // });
          this.calculateAmounts();
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
  }

  //textbox hide
  selectChange(event) {
    let selectedTypes = this.paymentTypes.find(res => {
      if (res.method == event.target.value) {
        return res;
      }
    })
    if (selectedTypes.transactionIdReq == 0) {
      this.isEnable = false;
      this.paymentForm.controls['refNumber'].clearValidators();
      this.paymentForm.controls['refNumber'].updateValueAndValidity();
    } else {
      this.isEnable = true;
      this.paymentForm.controls['refNumber'].setValidators([Validators.required]);
      this.paymentForm.controls['refNumber'].updateValueAndValidity();
    }

  }
  calculateAmounts() {
    this.subTotal = 0;
    this.tax = 0;
    this.taxLabel = [];
    this.items.forEach((service) => {
      this.subTotal +=
        (this.currentTime ? service.nightCharge : service.dayCharge) *
        service.quantity;
      this.tax +=
        (service.tax *
          (this.currentTime ? service.nightCharge : service.dayCharge) *
          service.quantity) /
        100;
      if (this.taxLabel.indexOf(service.tax) < 0) {
        this.taxLabel.push(service.tax);
      }
    });
    this.adhocItems.forEach((service) => {
      this.subTotal += service.rate * service.quantity;
      this.tax += (service.tax * service.rate * service.quantity) / 100;
      if (this.taxLabel.indexOf(service.tax) < 0) {
        this.taxLabel.push(service.tax);
      }
    });
  }

  onStatusChange(status) {
    console.log("status select ---",status);
    this.taskService.setTaskStatus(status);
  }

  onBookingTimeChange() {
    this.taskService.setBookingTimePopUp(true);
  }

  onSelectService(event: TypeaheadMatch) {
    const serviceData = event.item;
    this.selectedService = serviceData;
    serviceData.rate = this.currentTime
      ? serviceData.nightCharge
      : serviceData.dayCharge;
    this.invoiceForm.patchValue({
      name: serviceData.name,
      tax: serviceData.tax || "",
      rate: serviceData.rate || "",
      dayCharge: serviceData.dayCharge,
      nightCharge: serviceData.nightCharge,
      id: serviceData.id,
    });
    if (serviceData.tax) {
      this.invoiceForm.get("tax").disable();
    } else {
      this.invoiceForm.get("tax").enable();
    }
    if (serviceData.rate) {
      this.invoiceForm.get("rate").disable();
    } else {
      this.invoiceForm.get("rate").enable();
    }
  }

  calculateServiceAmount() {
    const quantity = this.invoiceForm.get("quantity").value;
    const tax = this.invoiceForm.get("tax").value;
    const rate = this.invoiceForm.get("rate").value;
    if (quantity && rate && tax) {
      const amount = (quantity * (rate * (1 + tax / 100))).toFixed(2);
      this.invoiceForm.patchValue({
        amount,
      });
    }
  }

  toggleTaskDetails(val: boolean, task: any) {
    // console.log(task);
    // console.log(val);
    if (val) {
      this.detailsSlider?.nativeElement.classList.add("showDetailsSlider");
      this.detailsTabs.tabs[0].active = true;
      this.task = task;
      this.taskService.setTaskPrevStatus(task.status);
      this.init();
    } else {
      if (this.locationSubscription) {
        this.locationSubscription.unsubscribe();
      }
      this.detailsSlider?.nativeElement.classList.remove("showDetailsSlider");
      this.closeDetails.emit(true);
      this.taskService.setUpdatedTasks(true);
      this.mechanicService.setRefresh(true);
      if (this.subscription) {
        this.subscription.unsubscribe();
      }
    }
  }

  submitNotesForm($ev, value: any) {
    $ev.preventDefault();
    for (const c in this.notesForm.controls) {
      if (this.notesForm.controls.hasOwnProperty(c)) {
        this.notesForm.controls[c].markAsTouched();
      }
    }
    if (this.notesForm.valid) {
      console.log("Valid!");
      const params = {
        // createdAt: new Date().toISOString(),
        // updatedAt: new Date().toISOString(),
        isActive: true,
        orderJson: this.history[0].orderJson,
        actionPerformed: "UPDATE",
        notes: this.notesForm.get("note").value,
        orderId: this.task.id,
      };
      this.taskService.addOrderNote(params).subscribe(
        (response: any) => {
          console.log(response);
          this.getTaskHistory();
          this.notesForm.reset();
          this.notesForm.patchValue({
            note_type: "Internal",
          });
          this.notesForm.markAsPristine();
          this.notesForm.markAsUntouched();
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
    console.log(value);
  }

  submitInvoiceForm($ev, value: any) {
    $ev.preventDefault();
    for (const c in this.invoiceForm.controls) {
      if (this.invoiceForm.controls.hasOwnProperty(c)) {
        this.invoiceForm.controls[c].markAsTouched();
      }
    }
    if (this.invoiceForm.valid) {
      console.log("Valid!");
      const tempService = {
        name: this.invoiceForm.get("service").value,
        rate: this.invoiceForm.get("rate").value,
        tax: this.invoiceForm.get("tax").value,
        quantity: this.invoiceForm.get("quantity").value,
        id: this.invoiceForm.get("id").value,
      };

      // const isExisting = this.items.find((el) => el.id === tempService.id);
      // if (!isExisting) {
      //   this.items.push(tempService);
      // } else {
      //   this.items.map(service => {
      //     if (service.id === tempService.id) {
      //       service.quantity = tempService.quantity;
      //     }
      //     return service;
      //   });
      // }

      if (tempService.id) {
        const params = {
          serviceId: tempService.id,
          quantity: tempService.quantity,
        };
        this.taskService.addServiceInvoice(params, this.invoice.id).subscribe(
          (response: any) => {
            // console.log(response);
            // this.calculateAmounts();
            this.getTaskInvoice();
            this.invoiceForm.get("tax").enable();
            this.invoiceForm.get("rate").enable();
            this.invoiceForm.reset();
            this.invoiceForm.markAsPristine();
            this.invoiceForm.markAsUntouched();
          },
          (error: any) => {
            console.log(error);
          }
        );
      } else {
        const params = {
          serviceName: tempService.name,
          quantity: tempService.quantity,
          tax: tempService.tax,
          rate: tempService.rate,
        };
        this.taskService
          .addAdhocServiceInvoice(params, this.invoice.id)
          .subscribe(
            (response: any) => {
              this.getTaskInvoice();
              this.invoiceForm.get("tax").enable();
              this.invoiceForm.get("rate").enable();
              this.invoiceForm.reset();
              this.invoiceForm.markAsPristine();
              this.invoiceForm.markAsUntouched();
            },
            (error: any) => {
              console.log(error);
            }
          );
      }
    }
    console.log(value);
  }

  removeItem(i) {
    const serviceDeleted = this.items[i];
    this.items.splice(i, 1);
    this.taskService
      .deleteServiceInvoice(serviceDeleted.id, this.invoice.id)
      .subscribe(
        (response: any) => {
          console.log(response);
          // this.calculateAmounts();
          this.getTaskInvoice();
        },
        (error: any) => {
          console.log(error);
        }
      );
  }

  removeAdhocItem(i) {
    const serviceDeleted = this.adhocItems[i];
    this.adhocItems.splice(i, 1);
    this.taskService
      .deleteAdhocServiceInvoice(serviceDeleted.serviceName, this.invoice.id)
      .subscribe(
        (response: any) => {
          console.log(response);
          // this.calculateAmounts();
          this.getTaskInvoice();
        },
        (error: any) => {
          console.log(error);
        }
      );
  }

  selectInvoiceItem(item) {
    if (item.id) {
      this.selectedService = item;
    } else {
      this.selectedService = this.serviceObj;
      this.selectedService.name = item.serviceName;
      this.selectedService.tax = item.tax;
      this.selectedService.nightCharge = item.rate;
      this.selectedService.dayCharge = item.rate;
    }
    this.invoiceForm.patchValue({
      name: item.name || item.serviceName,
      quantity: item.quantity,
      tax: item.tax,
      rate: (this.currentTime ? item.nightCharge : item.dayCharge) || item.rate,
      dayCharge: item.dayCharge,
      nightCharge: item.nightCharge,
      id: item.id,
    });
    this.calculateServiceAmount();
  }

  submitDiscountForm($ev, value: any) {
    $ev.preventDefault();
    for (const c in this.discountForm.controls) {
      if (this.discountForm.controls.hasOwnProperty(c)) {
        this.discountForm.controls[c].markAsTouched();
      }
    }
    if (this.discountForm.valid) {
      console.log(value);
      this.discount.coupon = this.discountForm.get("coupon").value;
      this.discount.amount = 0.5;
      this.discountForm.patchValue({
        coupon: "",
        amount: 0,
      });
      // this.calculateAmounts();
      this.finalAmount = this.invoice.amount - this.discount.amount;
      this.due = this.finalAmount - this.paid;
    }
  }

  deleteDiscount() {
    this.discount = {
      coupon: "",
      amount: 0,
    };
    this.discountForm.patchValue({
      coupon: "",
      amount: 0,
    });
    // this.calculateAmounts();
    this.finalAmount = this.invoice.amount - this.discount.amount;
    this.due = this.finalAmount - this.paid;
  }

  submitPaymentForm($ev, value: any) {
    $ev.preventDefault();
    for (const c in this.paymentForm.controls) {
      if (this.paymentForm.controls.hasOwnProperty(c)) {
        this.paymentForm.controls[c].markAsTouched();
      }
    }
    if (this.paymentForm.valid) {
      console.log(this.paymentForm.get("amount").value);
      console.log(1 * this.paymentForm.get("amount").value);
      console.log(this.due);
      if (this.paymentForm.get("amount").value > this.due) {
        this.main.showToast(
          "warning",
          "Amount can't be greater than Due Amount"
        );
        return false;
      }
      console.log("Valid!");
      const params = {
        invoiceId: this.invoice.id,
        paid: parseFloat(this.paymentForm.get("amount").value),
        mode: this.paymentForm.get("mode").value,
        transactionRefNo: this.paymentForm.get("refNumber").value != null ? this.paymentForm.get("refNumber").value : "",

      };

      this.taskService.manualTransaction(params).subscribe(
        (response: any) => {
          console.log(response);
          this.main.showToast("success", "Transaction done successfully");
          this.paymentForm.reset();
          this.paymentForm.markAsPristine();
          this.paymentForm.markAsUntouched();
          // this.calculateAmounts();
          this.getTaskInvoice();
        },
        (error: any) => {
          console.log(error);
        }
      );
    }
    console.log(value);
  }

  openAssignSlider(assignMode: number) {
    const emit: any = {
      val: true,
      task: this.task,
      assignMode,
    };
    this.toggleAssignSlider.emit(emit);
  }

  unassignMechanic() {
    this.onStatusChange(-1);
  }

  showPath(showPathStatus) {
    this.taskService.setTaskPath(showPathStatus);
  }

  downloadPDF() {
    const innerHTML = document.getElementById('A4').innerHTML;
    const html = `<!DOCTYPE html>
      <html>
      <head><link rel="stylesheet" href="/assets/pdf.css" />
        <style>
          *{
            font-family: 'ProximaNova-Bold', Helvetica, Arial, serif;
          }
        </style>
        <title>Task-Invoice-${this.task.id}</title>
      </head>
      <body>
        <div class="hideSection" style="padding: 15px;text-align: center">
          <button onclick="window.print()">Print</button>
          <button onclick="window.close()">Close</button>
        </div>
        ${innerHTML}
      </body>
      </html>`;
    var w = window.open("", "", "width=800,height=900");
    w.document.write(html);
    // setTimeout(function () {
    if (!w || w.closed || typeof w.closed == "undefined") {
      alert("Please disable your browser's pop-up blocker and try again.");
    }
    if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
      w.location.reload();
    }
    w.focus();
    //   w.print();
    //   setTimeout(function () {
    //     w.close();
    //   }, 100);
    // }, 1000);

  }
}
