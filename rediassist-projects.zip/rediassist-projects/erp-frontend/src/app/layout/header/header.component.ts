import { Component, OnInit, ViewChild, Injector, ViewEncapsulation, Input } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
const screenfull = require('screenfull');
import { SettingsService } from '../../core/settings/settings.service';
import { MenuService } from '../../core/menu/menu.service';
import { ThemesService } from 'src/app/core/themes/themes.service';
import { TranslatorService } from 'src/app/core/translator/translator.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { TaskDetailsComponent } from '../task-details/task-details.component';
import { VendorsService } from 'src/app/core/services/vendors/vendors.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
import { IDropdownSettings } from "ng-multiselect-dropdown";
import { FormGroup, FormControl, Validator, Validators } from "@angular/forms";
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

    public form: FormGroup;
    @Input() showMenu: boolean;
    @Input() mode: string;
    navCollapsed = true; // for horizontal layout
    menuItems = []; // for horizontal layout
    // router: Router;
    selectedClient: any;
    selectedLocation: any;
    isNavSearchVisible: boolean;
    currentTheme: any;
    selectedLanguage: string;
    currentUrl: string;
    clientSubscription;
    locationSubscription;
    clients: any = [];
    locations: any = [];
    dateMode = 'All';
    filter = {
        time: 4,
        client: 1,
        team: 1,
        location: 1
    };
    clientDropdownSettings : IDropdownSettings = {
        singleSelection: true,
        idField: "id",
        textField: "name",
        selectAllText: "Select All",
        unSelectAllText: "UnSelect All",
        itemsShowLimit: 5,
        allowSearchFilter: true,
        closeDropDownOnSelection: true
      }
    // @ViewChild('fsbutton', { static: true }) fsbutton;  // the fullscreen button

    constructor(
        public menu: MenuService,
        public settings: SettingsService,
        public injector: Injector,
        public themes: ThemesService,
        public translator: TranslatorService,
        private router: Router,
        private route: ActivatedRoute,
        public main: MainService,
        private auth: AuthService,
        public vendorsService: VendorsService,
        private taskService: TasksService,
        private mechanicService: MechanicsService,
    ) {
        this.router.events.subscribe((val) => {
            // scroll view to top
            if (val instanceof NavigationEnd) {
                this.currentUrl = val.url;
                if (this.currentUrl === '/create-task') {
                    this.settings.setLayoutSetting('createTask', true);
                } else {
                    this.settings.setLayoutSetting('createTask', false);
                }
            }
            window.scrollTo(0, 0);
            // close collapse menu
            this.navCollapsed = true;
        });
        // show only a few items on demo
        this.menuItems = menu.getMenu().slice(0, 9); // for horizontal layout
        this.clientSubscription = this.main.getClientList().subscribe((value: any) => {
            this.clients = value;
            this.selectedClient = this.clients[0];
        });
        this.locationSubscription = this.main.getLocationList().subscribe((value: any) => {
            this.locations = value;
            console.log("locations----",this.locations);
            if(this.locations.length > 0){
                this.locations.push({id:'All',name:'All'});            
            }
            this.selectedLocation = this.locations[0];
        });
    }

    ngOnInit() {
        // this.taskService.setTaskFilter(this.filter);
        this.form = new FormGroup({
            LocationName: new FormControl([this.selectedLocation])
        });
    }

    setTheme() {
        this.themes.setTheme(this.currentTheme);
    }

    getLangs() {
        return this.translator.getAvailableLanguages();
    }

    setLang(value) {
        this.translator.useLanguage(value);
    }

    toggleOffsidebar() {
        this.settings.toggleLayoutSetting('offsidebarOpen');
    }

    toggleCollapsedSideabar() {
        this.settings.toggleLayoutSetting('isCollapsed');
    }

    isCollapsedText() {
        return this.settings.getLayoutSetting('isCollapsedText');
    }

    toggleFullScreen(event) {
        if (screenfull.enabled) {
            screenfull.toggle();
        }
    }

    createTask() {
        this.taskService.clearCurrentTask();
        this.taskService.clearTaskDetails();
        this.taskService.setCurrentTask({});
        this.router.navigate(['create-task']);
    }

    addVendor() {
        this.vendorsService.setModalFlag(true);
    }

    dateFilter(i) {
        switch (i) {
            case 0:
                this.dateMode = 'Today';
                break;
            case 1:
                this.dateMode = 'Last 7 days';
                break;
            case 2:
                this.dateMode = 'Last 30 days';
                break;
            case 3:
                this.dateMode = 'Scheduled';
                break;
            case 4:
                this.dateMode = 'All';
                break;
            default:
                break;
        }
        this.filter = {
            ...this.filter,
            time: i
        };
        this.taskService.setTaskFilter(this.filter);
    }

    selectClient(client) {
        this.selectedClient = client;
        this.filter = {
            ...this.filter,
            client: client.id
        };
        if (client === 'All') {
            delete this.filter.client;
            this.selectedClient = {
                name: 'All'
            };
        }
        this.taskService.setTaskFilter(this.filter);
    }

    selectLocation(location) {
        console.log("location ---",location);
        this.selectedLocation = location;
        this.filter = {
            ...this.filter,
            location: location.id
        };
        if (location === 'All') {
            delete this.filter.location;
            this.selectedLocation = {
                name: 'All'
            };
        }
        console.log("filter ----",this.filter);
        this.taskService.setTaskFilter(this.filter);
    }

    refreshDashboard() {
        this.taskService.clearCurrentTask();
        this.taskService.clearTaskDetails();
        this.taskService.setCurrentTask({});
        this.taskService.setUpdatedTasks(true);
        this.taskService.setTaskFilter(this.filter);
        this.mechanicService.setRefresh(true);
    }

    logout() {
        this.auth.logoutRedirect();
    }

    onLocationSelect(items :any){        
        this.filter = {
            ...this.filter,
            location: items.id
        };
        if (items.name === 'All') {
            delete this.filter.location;            
        }        
        this.taskService.setTaskFilter(this.filter);
    }

    onLocationDeSelect(items :any){        
        delete this.filter.location;        
        this.taskService.setTaskFilter(this.filter);
    }
}
