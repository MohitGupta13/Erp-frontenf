import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChange, ElementRef } from '@angular/core';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { Task } from 'src/app/shared/interfaces/tasks.interface';
import { Observable, Observer, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { taskStatus } from 'src/constant/data';
@Component({
    selector: 'app-navsearch',
    templateUrl: './navsearch.component.html',
    styleUrls: ['./navsearch.component.scss']
})
export class NavsearchComponent implements OnInit, OnChanges {

    @Input() mode: string;
    search: string;
    searchDone: boolean;
    public orders: Task[];
    order$: Observable<any[]>;
    taskStatus = taskStatus;
    constructor(public elem: ElementRef, public taskService: TasksService) { }

    ngOnInit() {
        this.order$ = new Observable((observer: Observer<string>) => {
          observer.next(this.search);
        }).pipe(
          switchMap((query: string) => {
            if (query) {
                return this.taskService.searchClosedOrder(query).pipe(map((data: any) => {
                    data.map(item => {
                        item.name = `#${item.id}: ${item.custName}(${item.custPhoneNumber}) - ${item.vehicleIdentificationNumber}`;
                        item.statusName = taskStatus[item.status];
                        return item;
                    });
                    console.log(data);
                    this.orders = data;
                    this.searchDone = true;
                    return data;
              }));
            }
            return of([]);
          })
        );
    }

    clearSearch() {
        this.search = '';
        this.orders = [];
        this.searchDone = false;
    }

    ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
        // console.log(changes['visible'].currentValue)
        // if (changes.visible.currentValue === true) {
        //     this.elem.nativeElement.querySelector('input').focus();
        // }
    }

    handleForm() {
        console.log('Form submit: ' + this.search);
        // this.taskService.searchOrder(this.search)
        //     .subscribe((data: any) => {
        //         console.log(data);
        //         this.orders = data;
        //         this.searchDone = true;
        //     }, (error: any) => {
        //         console.log(error);
        //     });
    }

    displayTask(order) {
        console.log(order);
        this.taskService.setTaskDetails(order);
        this.clearSearch();
    }

    onSelectOrder(event: TypeaheadMatch) {
        const order = event.item;
        console.log(order);
    }
}
