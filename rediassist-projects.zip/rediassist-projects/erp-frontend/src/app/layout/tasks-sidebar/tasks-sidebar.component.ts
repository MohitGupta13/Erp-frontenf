/// <reference types="@types/googlemaps" />
import { Component, OnInit, Injector, ViewEncapsulation, ViewChild, ElementRef } from '@angular/core';
import { SettingsService } from '../../core/settings/settings.service';
import { TaskDetailsComponent } from '../task-details/task-details.component';
import { Task } from '../../shared/interfaces/tasks.interface';
import { TasksService } from 'src/app/core/services/tasks/tasks.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { forkJoin } from 'rxjs';
declare const google: any;

@Component({
  selector: 'app-tasks-sidebar',
  templateUrl: './tasks-sidebar.component.html',
  styleUrls: ['./tasks-sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class TasksSidebarComponent implements OnInit {
  // tasks: Task[];
  // task: Task;
  public tasks: Task[];
  public assignedTasks: Task[] = [];
  public unassignedTasks: Task[] = [];
  public inProgressTasks: Task[] = [];
  public closedTasks: Task[] = [];
  assignedTasksLength = 0;
  unassignedTasksLength = 0;
  inProgressTasksLength = 0;
  closedTasksLength = 0;
  public task: Task;
  interval: any;
  services: [];
  vehicles: [];
  markers: any = [];
  fetchClosed = false;
  filter = {
    time: 4,
    client: 1,
    team: 1,
    location: 1
  };
  @ViewChild(TaskDetailsComponent) taskDetails: TaskDetailsComponent;
  constructor(
    public settings: SettingsService,
    private taskService: TasksService,
    public main: MainService
  ) {
    this.taskService.clearUpdatedTasks();
    this.main.getVehicleList().subscribe((value: any) => {
      this.vehicles = value;
    });
    this.main.getAllServiceList().subscribe((value: any) => {
      this.services = value;
      // this.markers = [];
      console.log('service response');
      if (this.services.length) {
        this.updateServiceNames();
      }
    });
    this.taskService.getTaskDetails().subscribe((task: any) => {
      console.log('toggle details');
      this.toggleTaskDetails(true, task);
    });
    this.taskService.getUpdatedTasks().subscribe((task: any) => {
      console.log('updated response');
      if (task) {
        this.getTasks();
      }
    });
    this.taskService.getTaskFilter().subscribe((taskFilter: any) => {
      this.filter = { ...taskFilter };
      console.log('task filter response');
      this.getTasks();
    });
  }

  ngOnInit() {}

  getServiceName(serviceId: number) {
    if (!serviceId) {
      return false;
    }
    let serviceName;
    this.services.map((service: any) => {
      if (service.id === serviceId) {
        // console.log(service.name);
        serviceName = service.name;
      }
    });
    return serviceName;
  }

  toggleTasksSideabar() {
    this.settings.toggleLayoutSetting('isCollapsed');
  }

  toggleTaskDetails(val: boolean, task: any) {
    if (Object.keys(task).length > 0) {
      this.task = task;
      this.taskService.setCurrentTask(task);
      this.taskDetails.toggleTaskDetails(val, task);
    }
  }
  closeDetails(val) {
    if (val) {
      delete this.task;
      this.taskService.clearCurrentTask();
      this.taskService.clearTaskDetails();
    }
  }

  trackByFunction(index, item) {
    if (!item) {
      return null;
    }
    return item;
  }

  updateMarkers() {
    const unassignedMarkers = [];
    const assignedMarkers = [];
    const inProgressMarkers = [];
    const closedMarkers = [];
    // const tasks = [...this.unassignedTasks, ...this.assignedTasks, ...this.inProgressTasks];
    this.unassignedTasks.map((task) => {
      const { lat, lng } = task.taskGeopoint;
      unassignedMarkers.push({
        lat,
        lng,
        icon: './assets/img/png/yellow-marker.png',
        task
      });
    });
    this.assignedTasks.map((task) => {
      const { lat, lng } = task.taskGeopoint;
      assignedMarkers.push({
        lat,
        lng,
        icon: './assets/img/png/orange-marker.png',
        task
      });
    });
    this.inProgressTasks.map((task) => {
      const { lat, lng } = task.taskGeopoint;
      inProgressMarkers.push({
        lat,
        lng,
        icon: './assets/img/png/blue-marker.png',
        task
      });
    });
    this.closedTasks.map((task) => {
      const { lat, lng } = task.taskGeopoint;
      closedMarkers.push({
        lat,
        lng,
        icon: './assets/img/png/gray-marker.png',
        task
      });
    });
    this.markers = [
      ...assignedMarkers,
      ...unassignedMarkers,
      ...inProgressMarkers,
      ...closedMarkers
    ];
    this.main.setTaskMarkers(this.markers);
    // Cancelled tasks will have red marker
    this.updateCounters();
  }

  updateCounters() {
    console.log('count api');
    const calls = [
      this.taskService.getStatusOrderCounts(1, this.filter),
      this.taskService.getStatusOrderCounts(2, this.filter),
      this.taskService.getStatusOrderCounts(3, this.filter)
    ];
    if (this.fetchClosed) {
      calls.push(this.taskService.getStatusOrderCounts(9, this.filter));
    }
    forkJoin(calls).subscribe((data: any) => {
      console.log(data);
      this.unassignedTasksLength = data[0].count;
      this.assignedTasksLength = data[1].count;
      this.inProgressTasksLength = data[2].count;
      if (data[3]) {
        this.closedTasksLength = data[3].count;
      }
    });
  }

  updateServiceNames() {
    this.unassignedTasks.map((task) => {
      task.serviceName = this.getServiceName(task.serviceId);
    });
    this.assignedTasks.map((task) => {
      task.serviceName = this.getServiceName(task.serviceId);
    });
    this.inProgressTasks.map((task) => {
      task.serviceName = this.getServiceName(task.serviceId);
    });
    if (this.fetchClosed) {
      this.closedTasks.map((task) => {
        task.serviceName = this.getServiceName(task.serviceId);
      });
    }
  }

  getUnassignedTasks() {
    console.log('unassigned api');
    this.taskService.getStatusOrderList(1, this.filter).subscribe(
      (data: any) => {
        this.unassignedTasks = [];
        data.map((task) => {
          task.serviceName = this.getServiceName(task.serviceId);
          if (task.vehicle) {
            task.vehicleName = [task.vehicle.make, task.vehicle.model].join(' ');
          } else {
            task.vehicleName = '';
          }
          this.unassignedTasks.push(task);
        });
        // this.updateMarkers();
        if (this.unassignedTasks.length) {
          this.getAssignedMechanics(this.unassignedTasks);
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getAssignedTasks() {
    this.taskService.getStatusOrderList(2, this.filter).subscribe(
      (data: any) => {
        this.assignedTasks = [];
        data.map((task) => {
          task.serviceName = this.getServiceName(task.serviceId);
          if (task.vehicle) {
            task.vehicleName = [task.vehicle.make, task.vehicle.model].join(' ');
          } else {
            task.vehicleName = '';
          }
          this.assignedTasks.push(task);
        });
        // this.updateMarkers();
        if (this.assignedTasks.length) {
          this.getAssignedMechanics(this.assignedTasks);
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getInProgressTasks() {
    this.taskService.getStatusOrderList(3, this.filter).subscribe(
      (data: any) => {
        this.inProgressTasks = [];
        data.map((task) => {
          task.serviceName = this.getServiceName(task.serviceId);
          if (task.vehicle) {
            task.vehicleName = [task.vehicle.make, task.vehicle.model].join(' ');
          } else {
            task.vehicleName = '';
          }
          this.inProgressTasks.push(task);
        });
        // this.updateMarkers();
        if (this.inProgressTasks.length) {
          this.getAssignedMechanics(this.inProgressTasks);
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getClosedTasks() {
    this.taskService.getStatusOrderList(9, this.filter).subscribe(
      (data: any) => {
        this.closedTasks = [];
        data.map((task) => {
          task.serviceName = this.getServiceName(task.serviceId);
          if (task.vehicle) {
            task.vehicleName = [task.vehicle.make, task.vehicle.model].join(' ');
          } else {
            task.vehicleName = '';
          }
          this.closedTasks.push(task);
        });
        // this.updateMarkers();
        if (this.closedTasks.length) {
          this.getAssignedMechanics(this.closedTasks);
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  getTasks() {
    const calls = [
      this.taskService.getStatusOrderList(1, this.filter),
      this.taskService.getStatusOrderList(2, this.filter),
      this.taskService.getStatusOrderList(3, this.filter)
    ];
    if (this.fetchClosed) {
      calls.push(this.taskService.getStatusOrderList(9, this.filter));
    }
    forkJoin(calls).subscribe((data: any) => {
      data[0].map((task) => {
        task.serviceName = this.getServiceName(task.serviceId);
      });
      data[1].map((task) => {
        task.serviceName = this.getServiceName(task.serviceId);
      });
      data[2].map((task) => {
        task.serviceName = this.getServiceName(task.serviceId);
      });
      if (data[3]) {
        data[3].map((task) => {
          task.serviceName = this.getServiceName(task.serviceId);
        });
        this.closedTasks = data[3];
      }
      this.unassignedTasks = data[0];
      this.assignedTasks = data[1];
      this.inProgressTasks = data[2];
      if (this.unassignedTasks.length) {
        this.getAssignedMechanics(this.unassignedTasks);
      }
      if (this.assignedTasks.length) {
        this.getAssignedMechanics(this.assignedTasks);
      }
      if (this.inProgressTasks.length) {
        this.getAssignedMechanics(this.inProgressTasks);
      }
      if (this.closedTasks.length) {
        this.getAssignedMechanics(this.closedTasks);
      }
      this.updateMarkers();
    });
  }

  getAssignedMechanics(tasks) {
    const orderIds = tasks.map(({ id }) => id);
    this.taskService.getOrderAssignDetails(orderIds).subscribe(
      (data: any) => {
        data.forEach(item => {
          const obj = tasks.find(o => o.id === item.orderId);
          const index = tasks.indexOf(obj);
          // tasks.fill(obj.vendor = item.vendor, index, index++);
          tasks[index] = {
            ...tasks[index],
            vendor: item.vendor
          };
        });
        switch (tasks[0].status) {
          case 1:
            this.unassignedTasks = tasks;
            break;
          case 2:
            this.assignedTasks = tasks;
            break;
          case 9:
          case 10:
          case 11:
          case 12:
            this.closedTasks = tasks;
            break;
          default:
            this.inProgressTasks = tasks;
            break;
        }
        this.updateMarkers();
      },
      (error: any) => {
        console.log(error);
      });
  }

  toggleAssignSlider(val, task, assignMode) {
    const status = {
      show: val,
      mode: 1,
      task,
      assignMode
    };
    this.main.setAssignSliderStatus(status);
  }

  handleDetailsEmitter(emit) {
    this.toggleTaskDetails(emit.val, emit.task);
  }

  handleAssignEmitter(emit) {
    this.toggleAssignSlider(emit.val, emit.task, emit.assignMode);
  }

  fetchClosedTasks(value: any) {
    console.log(value);
    this.fetchClosed = value.target.checked ? true : false;
    if (!this.fetchClosed) {
      this.closedTasks = [];
      this.updateMarkers();
    } else {
      this.getClosedTasks();
    }
  }
}
