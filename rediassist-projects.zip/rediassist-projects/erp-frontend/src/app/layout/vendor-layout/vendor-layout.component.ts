import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-layout',
  templateUrl: './vendor-layout.component.html',
  styleUrls: ['./vendor-layout.component.scss']
})
export class VendorLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
