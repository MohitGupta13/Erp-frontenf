import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { MechanicsService } from 'src/app/core/services/mechanics/mechanics.service';
import { MainService } from 'src/app/core/services/main/main.service';
import { Mechanic } from 'src/app/shared/interfaces/mechanics.interface';
import * as moment from 'moment';
@Component({
  selector: 'app-mechanic-sidebar',
  templateUrl: './mechanic-sidebar.component.html',
  styleUrls: ['./mechanic-sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MechanicSidebarComponent implements OnInit {

  public freeMechanics: Mechanic[] = [];
  public busyMechanics: Mechanic[] = [];
  public onBreakMechanics: Mechanic[] = [];
  markers: any = [];
  constructor(public settings: SettingsService, public main: MainService, private mechanicsService: MechanicsService) {
    this.mechanicsService.getRefresh().subscribe((refresh: any) => {
      // console.log(refresh);
      if (refresh) {
        this.getMechanics();
      }
    });
  }

  ngOnInit(): void {
    this.getMechanics();
  }

  toggleMechanicSideBar() {
    this.settings.toggleLayoutSetting('offsidebarOpen');
  }


  updateMarkers() {
    this.freeMechanics.map(mechanic => {
      const { latlon, id, name, mobile, profilePic1 } = mechanic;
      var data = latlon.split(",");
      this.markers.push({
        lat: +data[0],
        lng: +data[1],
        // lat: mechanic.mechanic_lat,
        // lng: mechanic.mechanic_long,
        icon: './assets/img/png/green_circle.png',
        details: { id, name, mobile, profilePic1 }
      });
    });
    this.busyMechanics.map(mechanic => {
      const { latlon, id, name, mobile, profilePic1 } = mechanic;
      var data = latlon.split(",");
      this.markers.push({
        lat: +data[0],
        lng: +data[1],
        // lat: mechanic.mechanic_lat,
        // lng: mechanic.mechanic_long,
        icon: './assets/img/png/orange_circle.png',
        details: { id, name, mobile, profilePic1 }
      });
    });
    this.onBreakMechanics.map(mechanic => {
      const { latlon, id, name, mobile, profilePic1 } = mechanic;
      var data = latlon.split(",");
      this.markers.push({
        lat: +data[0],
        lng: +data[1],
        // lat: mechanic.mechanic_lat,
        // lng: mechanic.mechanic_long,
        icon: './assets/img/png/red_circle.png',
        details: { id, name, mobile, profilePic1 }
      });
    });
    this.main.setMechanicMarkers(this.markers);
    // Cancelled mechanics will have red marker
  }
  searchVendor(event) {
    console.log("search mechanics -----", event.target.value);
    this.freeMechanics.find(x => {
      // console.log("find ---",x.mobile)
    })
  }

  getMechanics() {
    console.log('calling mechanics');
    this.freeMechanics = [];
    this.busyMechanics = [];
    this.onBreakMechanics = [];
    this.mechanicsService.getMechanicList().subscribe(
      (data: any) => {
        console.log("Mechanics ----", data)


        // const vendorIds = data.map(({ id }) => id);

        data.map(item => {
          console.log("Status :---", item.status)
          switch (item.status) {
            case 0:
              this.freeMechanics.push(item);
              break;
            case 1:
            case 2:
              this.busyMechanics.push(item);
              break;
            case 3:
              this.onBreakMechanics.push(item);
              break;
            default:
              break;
          }
        });
        this.updateMarkers();

        // this.main.firebaseDB.collection('vendor')
        // .get()
        // .then((querySnapshot) => {
        //   const vendorLocations = [];
        //   querySnapshot.forEach((doc) => {
        //       // doc.data() is never undefined for query doc snapshots
        //     // console.log(doc.id, doc.data());
        //     vendorLocations.push({ id: parseInt(doc.id, 10), data: doc.data() });
        //   });
        //   // console.log(vendorLocations);
        //   data.map(item => {
        //     const temp = vendorLocations.find(element => {
        //       return element.id === item.id;
        //     });
        //     if (temp) {
        //       if (temp.data.oid) {
        //         item.oid = temp.data.oid;
        //       }
        //       if (temp.data.mrodt) {
        //         item.mrodt = temp.data.mrodt;
        //       }
        //       if (temp.data.ts) {
        //         item.ts = temp.data.ts;
        //         const tsdate = item.ts.toDate();
        //         const ts = moment.utc(new Date(tsdate));
        //         const cts = moment.utc(new Date());
        //         item.duration = cts.diff(ts, 'minutes');
        //         // console.log(item.duration);
        //         item.duration > 5 ? item.stale = true : item.stale = false;
        //       }
        //       if (temp.data.vs) {
        //         item.vs = temp.data.vs;
        //       }
        //       if (temp.data.VendorStatus) {
        //         item.vs = temp.data.VendorStatus;
        //       }
        //       switch (item.vs) {
        //         case 'ON DUTY':
        //           this.freeMechanics.push(item);
        //           break;
        //         case 'Busy':
        //         case 'Transit':
        //           this.busyMechanics.push(item);
        //           break;
        //         case 'On Break':
        //           this.onBreakMechanics.push(item);
        //           break;
        //         default:
        //           break;
        //       }
        //     }
        //   });
        // })
        // .catch((error) => {
        //     console.log('Error getting documents: ', error);
        // });
      },
      (error: any) => {
        console.log(error);
      });
  }

  trackByFunction(index, item) {
    if (!item) {
      return null;
    }
    return item;
  }

}
