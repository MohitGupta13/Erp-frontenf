import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MechanicSidebarComponent } from './mechanic-sidebar.component';

describe('MechanicSidebarComponent', () => {
  let component: MechanicSidebarComponent;
  let fixture: ComponentFixture<MechanicSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MechanicSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MechanicSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
