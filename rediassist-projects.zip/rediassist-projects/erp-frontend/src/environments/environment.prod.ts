export const environment = {
  production: true,
  baseUrl: 'http://app.readyassist.net/api',
  mapApi: 'AIzaSyCr17JyBUkudCa6BTxniFNWPeADAGPXcIo',
  firebaseConfig: {
    apiKey: 'AIzaSyDWLN1cEn8X6c0sm9uwyRmxx57JkEbFd1E',
    authDomain: 'ra-prod-mechapp.firebaseapp.com',
    databaseURL: 'https://ra-prod-mechapp.firebaseio.com',
    projectId: 'ra-prod-mechapp',
    storageBucket: 'ra-prod-mechapp.appspot.com',
    messagingSenderId: '202319718454',
    appId: '1:202319718454:web:4f8b817c9b0da716ca1097',
    measurementId: 'G-H703WVRPCW'
  }
};
