// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //  baseUrl: 'http://localhost:3000/api',
  baseUrl: 'http://dev.readyassist.net/api',
  // mapApi: 'AIzaSyC0KYKIjJ4jlHK7Vyo-yYSdffnvvx05vw4',
  // firebaseConfig: {
  //   apiKey: 'AIzaSyD2wUYozI49wr8-LFjSuUqRmHs8XevAyPY',
  //   authDomain: 'ra-dev-mechapp.firebaseapp.com',
  //   databaseURL: 'https://ra-dev-mechapp.firebaseio.com',
  //   projectId: 'ra-dev-mechapp',
  //   storageBucket: 'ra-dev-mechapp.appspot.com',
  //   messagingSenderId: '884474802913',
  //   appId: '1:884474802913:web:fcec2ab9dc5bdd7cb63da0',
  //   measurementId: 'G-GG8NJZ09GK'
  // }
  //baseUrl: 'http://app.readyassist.net/api',
  mapApi: 'AIzaSyCr17JyBUkudCa6BTxniFNWPeADAGPXcIo',
  firebaseConfig: {
    // apiKey: 'AIzaSyCleyN7GxtVpLEumu6Ugsg_bZKsxYcTzg4',
    apiKey : 'AIzaSyAHTXAPjhC3SrEiuj3fcCuTwisC6c17e-8',
    authDomain: 'ra-dev-vendorapp.firebaseapp.com',
    databaseURL: 'https://ra-dev-vendorapp.firebaseio.com',
    projectId: 'ra-dev-vendorapp',
    storageBucket: 'ra-dev-vendorapp.appspot.com',
    messagingSenderId: '607554426381',
    appId: '1:607554426381:android:d83bd83f2ee4982fb86744',
    measurementId: 'G-GG8NJZ09GK'
  }
  // baseUrl: 'http://app.readyassist.net/api',
  // mapApi: 'AIzaSyCr17JyBUkudCa6BTxniFNWPeADAGPXcIo',
  // firebaseConfig: {
  //   apiKey: 'AIzaSyDWLN1cEn8X6c0sm9uwyRmxx57JkEbFd1E',
  //   authDomain: 'ra-prod-mechapp.firebaseapp.com',
  //   databaseURL: 'https://ra-prod-mechapp.firebaseio.com',
  //   projectId: 'ra-prod-mechapp',
  //   storageBucket: 'ra-prod-mechapp.appspot.com',
  //   messagingSenderId: '202319718454',
  //   appId: '1:202319718454:web:4f8b817c9b0da716ca1097',
  //   measurementId: 'G-H703WVRPCW'
  // }
};
