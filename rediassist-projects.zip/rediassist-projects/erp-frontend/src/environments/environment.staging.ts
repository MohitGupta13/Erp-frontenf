export const environment = {
  production: true,
  // baseUrl: 'http://3.7.167.253:8000/api',
  baseUrl: 'http://dev.readyassist.net/api',
//   baseUrl: 'http://localhost:3000/api',
  mapApi: 'AIzaSyC0KYKIjJ4jlHK7Vyo-yYSdffnvvx05vw4',
  firebaseConfig: {
    apiKey: 'AIzaSyD2wUYozI49wr8-LFjSuUqRmHs8XevAyPY',
    authDomain: 'ra-dev-mechapp.firebaseapp.com',
    databaseURL: 'https://ra-dev-mechapp.firebaseio.com',
    projectId: 'ra-dev-mechapp',
    storageBucket: 'ra-dev-mechapp.appspot.com',
    messagingSenderId: '884474802913',
    appId: '1:884474802913:web:fcec2ab9dc5bdd7cb63da0',
    measurementId: 'G-GG8NJZ09GK'
  }
};
